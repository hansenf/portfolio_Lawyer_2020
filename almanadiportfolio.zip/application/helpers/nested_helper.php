<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('nested_list')) {
   function nested_list($data) {
      $str = "";
      foreach ($data as $list) {
         $str .= '<li class="dd-item" data-id="' . $list['id_menu'] . '">';
         $str .= '<div class="dd-handle">' . strtoupper($list['nama']) . '</div>';
         $subchild = nested_list($list['child']);
         if ($subchild != '') {
            $str .= '<ol class="dd-list">' . $subchild . '</ol>';
         } else {
            $str .= '</li>';
         }
      }
      return $str;
   }

   function nested_list2($data) {
      $str = "";
      foreach ($data as $list) {
         $str .= '<li><a href="'.$list['url'].'"> '.strtoupper($list['nama']).' </a>';
         $subchild = nested_list2($list['child']);
         if ($subchild != '') {
            $str .= '<ul class="dropdown-menu">' . $subchild . '</ul>';  
         } else {
            $str .= '</li>';
         }
      }
      return $str;
   }
}

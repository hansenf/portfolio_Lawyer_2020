<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin_model extends CI_Model {

	public function get_count_pesan() {
		$hasil  = "";
		$q = $this->db->query("SELECT count(baca) AS count_baca FROM pesan_admin WHERE baca='N';");
		foreach($q->result() as $h) {
			$hasil .= $h->count_baca;
		}
		return $hasil;
	}

	public function get_file_user($id_param) {
		$q = $this->db->query("SELECT * FROM upload WHERE id_user ='$id_param' ORDER BY id DESC");
		return $q;
	}
	
	public function get_jenis_izin() {
		$q = $this->db->query("SELECT * FROM jenis_izin ORDER BY id_jenis_izin DESC");
		return $q;
	}
	
	public function get_perizinan($id_param) {
		$q = $this->db->query("SELECT * FROM jenis_izin
	    							INNER JOIN perizinan
	        						ON (jenis_izin.id_jenis_izin = perizinan.id_jenis_izin) 
        						WHERE perizinan.id_user ='$id_param' ORDER BY perizinan.id DESC");
		return $q;
	}

        public function get_portal() {
		$q = $this->db->query("SELECT * FROM portal ORDER BY id DESC");
		return $q;
	}

        public function get_popup() {
		$q = $this->db->query("SELECT * FROM popup");
		return $q;
	}

        public function get_admin() {
		$q = $this->db->query("SELECT * FROM admin ORDER BY id DESC");
		return $q;
	}


	public function get_user() {
		$q = $this->db->query("SELECT * FROM user ORDER BY id DESC");
		return $q;
	}

        public function get_user_by_id($id) {
		$q = $this->db->query("SELECT * FROM user WHERE id = '$id'");
		return $q;
	}
	

	public function get_upload() {
		$q = $this->db->query("SELECT * FROM upload ORDER BY id DESC");
		return $q;
	}
	
	public function get_upload_by_id($id) {
		$q = $this->db->query("SELECT * FROM upload WHERE id_user = '$id' ORDER BY id DESC");
		return $q;
	}

	public function get_agenda() {
		$q = $this->db->query("SELECT * FROM agenda ORDER BY id DESC");
		return $q;
	}

	public function get_banner() {
		$q = $this->db->query("SELECT * FROM banner ORDER BY id DESC");
		return $q;
	}

	public function get_link() {
		$q = $this->db->query("SELECT * FROM link ORDER BY id DESC");
		return $q;
	}


	public function get_kategori_file() {
		$q = $this->db->query("SELECT * FROM kategori_file ORDER BY id_kategori DESC");
		return $q;
	}

	public function get_file() {
		$q = $this->db->query("SELECT * FROM kategori_file
	    							INNER JOIN file 
	        						ON (kategori_file.id_kategori = file.id_kategori) 
        						ORDER BY file.id DESC");
		return $q;
	}

	public function get_post() {
		$q = $this->db->query("SELECT * FROM kategori_post
	    							INNER JOIN post 
	        						ON (kategori_post.id_kategori = post.id_kategori) 
        						ORDER BY post.id DESC");
		return $q;
	}

	public function get_kategori_post() {
		$q = $this->db->query("SELECT * FROM kategori_post ORDER BY id_kategori DESC");
		return $q;
	}


	public function get_informasi() {
		$q = $this->db->query("SELECT * FROM kategori_informasi
	    							INNER JOIN informasi 
	        						ON (kategori_informasi.id_kategori = informasi.id_kategori) 
        						ORDER BY informasi.id DESC");
		return $q;
	}
	
	public function get_visimisi() {
		$q = $this->db->query("SELECT * FROM visimisi")->row();
		return $q;
	}
	
	public function edit_visimisi($data){
	    $this->db->set($data);
	    $this->db->update('visimisi');
	}
	
	
	
	public function edit_struktur($data){
	    $this->db->set($data);
	    $this->db->update('struktur');
	}

	public function get_kategori_informasi() {
		$q = $this->db->query("SELECT * FROM kategori_informasi ORDER BY id_kategori DESC");
		return $q;
	}

	public function get_page() {
		$q = $this->db->query("SELECT * FROM page ORDER BY id DESC");
		return $q;
	}

	public function get_menu() {
		$q = $this->db->query("SELECT * FROM menu ORDER BY nama ASC");
		return $q;
	}

	public function get_photo() {
		$q = $this->db->query("SELECT * FROM album
	    							INNER JOIN photo 
	        						ON (album.id_album = photo.id_album) 
        						ORDER BY photo.id DESC");
		return $q;
	}

	public function get_album() {
		$q = $this->db->query("SELECT * FROM album ORDER BY id_album DESC");
		return $q;
	}

	public function get_slideshow() {
		$q = $this->db->query("SELECT * FROM slideshow ORDER BY id DESC");
		return $q;
	}

	public function get_video() {
		$q = $this->db->query("SELECT * FROM video ORDER BY id DESC");
		return $q;
	}

	public function get_about() {
		$q = $this->db->query("SELECT * FROM about");
		return $q;
	}

	public function get_organisasi() {
		$q = $this->db->query("SELECT * FROM organisasi ORDER BY id DESC");
		return $q;
	}

	public function get_staff() {
		$q = $this->db->query("SELECT * FROM staff ORDER BY id DESC");
		return $q;
	}

	public function get_pesan_admin() {
		$q = $this->db->query("SELECT * FROM pesan_admin ORDER BY id DESC");
		return $q;
	}

    public function get_pengaduan() {
		$q = $this->db->query("SELECT * FROM pengaduan ORDER BY id DESC");
		return $q;
	}
	public function get_struktur() 
	{
		$output = "";
	    $q = $this->db->query("SELECT * FROM struktur");
	    foreach($q->result() as $h) 
	    {
	        $output .= '    <center>
	                            <div class="struktur">
	  								<img src="'.base_url().'/asset/images/struktur/'.$h->gambar.'" width="620" height="700">
	  						</div>';
		}
		return $output;
	}
	public function gambar_struktur()
	{
	    $query = $this->db->query("SELECT gambar FROM struktur LIMIT 1")->row();
	    return $query->gambar;
	}
	public function get_tupoksi()
	{
	    $query = $this->db->query("SELECT ptupoksi FROM tupoksi LIMIT 1")->row();
	    return $query->ptupoksi;
	}
	
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class login_m extends CI_Model {

	public function cekLogin($data) {
		$username = $this->db->escape_str($data['username']);
		$password = md5($data['password']);

		$q_cek_login = $this->db->query("SELECT * FROM admin WHERE username='$username' AND password='$password' AND level='admin' AND aktif='Y'");
		if($q_cek_login->num_rows()>0) {
			foreach ($q_cek_login->result() as $qad) {
				$sess_data['logged_in'] = 'WhoaaGuaaLogin';
				$sess_data['nama'] = $qad->nama;
				$sess_data['username'] = $qad->username;
				$sess_data['id'] = $qad->id;
				$sess_data['level'] = $qad->level;
				
				$this->session->set_userdata($sess_data);
			}
			redirect("Xyzpb/dashboard");
		}else {
			 $this->session->set_flashdata("msg_loginx","User dan Password Salah");
			 redirect("Xyzpb");
			
		}
	}
	
	public function cekLoginUser($data) {
		$username = $this->db->escape_str($data['username']);
		$password = base64_encode($data['password']);

		$q_cek_login = $this->db->query("SELECT * FROM user WHERE username='$username' AND password='$password' AND level='user' AND aktif='Y'");
		if($q_cek_login->num_rows()>0) {
			foreach ($q_cek_login->result() as $qad) {
				$sess_data['logged_in'] = 'WhoaaGuaaLoginUser';
				$sess_data['nama'] = $qad->nama_pj;
				$sess_data['nama_perusahaan'] = $qad->nama_perusahaan;
				$sess_data['username'] = $qad->username;
				$sess_data['id'] = $qad->id;
				$sess_data['level'] = $qad->level;

				$this->session->set_userdata($sess_data);
			}
			redirect("Member/dashboard");

		}else {
			$this->session->set_flashdata("msg_loginx","User dan Password Salah");
			 redirect(base_url());


		}
	}
}
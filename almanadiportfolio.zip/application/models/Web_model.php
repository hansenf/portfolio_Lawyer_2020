<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class web_model extends CI_Model {

	public function get_about_detail() {
		$output = "";	
		$q = $this->db->query("SELECT tentang FROM about");	
		foreach($q->result() as $h) {
			$output .= '<h3 class="post-title">Tentang Kami</h3>  						
  						<div class="row">
  							<div style="text-align:right;margin-bottom:10px;" class="col-md-12">
  								<script>var pfHeaderImgUrl = "";var pfHeaderTagline = "";var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = "right";var pfDisablePDF = 0;var pfDisableEmail = 1;var pfDisablePrint = 0;var pfCustomCSS = "";var pfBtVersion="1";(function(){var js, pf;pf = document.createElement("script");pf.type = "text/javascript";if ("https:" === document.location.protocol){js="https://pf-cdn.printfriendly.com/ssl/main.js"}else{js="http://cdn.printfriendly.com/printfriendly.js"}pf.src=js;document.getElementsByTagName("head")[0].appendChild(pf)})();</script><a href="#" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
  							</div>
  						</div>  						
  						<div class="post-desc">
							'.$h->tentang.'
						</div>';

	   	}	
		return $output;
	}

	
	public function get_album($limit,$offset) {

		$page=$offset;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;

		$tot_hal = $this->db->query("SELECT * FROM album");	


		$config['base_url'] = base_url() . 'Web/gallery/index/';
		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$this->pagination->initialize($config);

		$output = "";
		$q = $this->db->query("SELECT * FROM album LIMIT $offset,$limit");		
		foreach($q->result() as $h) {
			$output .= '<div class="album">
	  							<div class="col-md-4">
	  								<img src="'.base_url().'/asset/images/album/'.$h->gambar.'">
	  							</div>
	  							<div class="col-md-8">
	  								<h5><a href="'.base_url().'Web/gallery/photo/'.$h->id_album.'">'.$h->nama.'</a></h5>
	  								<p class="post-desc">'.$h->keterangan.'</a></p>
	  							</div>
	  						</div>';
		}
		$output .= '</div></div><div class="paging">'.$this->pagination->create_links().'</div>';

		return $output;
	}

	public function get_album_title($id_param) {
		$output = "";
		$q = $this->db->query("SELECT nama FROM album WHERE id_album ='$id_param'");		
		foreach($q->result() as $h) {
			$output .= '<h3 class="post-title">'.strtoupper($h->nama).'</h3>';
		}
		return $output;
	}

	public function get_banner($limit) {
		$output = "";
		$count = "";
		$q = $this->db->query("SELECT keterangan,url,gambar FROM banner WHERE aktif='Y' LIMIT $limit");		
		foreach($q->result() as $h) {
			$count++;
			if($count == 1) {
				$class = 'active';
			} else {
				$class = "";
			}
			$output .= '<div class="item '.$class.'">
							<img style="height:400px;width:100%;" src="'.base_url().'asset/images/banner/'.$h->gambar.'">					
						</div>';
		}
		return $output;
	}


	public function get_berita_col1($offset,$limit) {
		$output = "";
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM post ORDER BY id DESC LIMIT $offset,$limit");	
		$count = 0;
		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));	
				$output .= '<div class="col-md-6">
								<div style="margin-bottom:0;" class="thumbnail">
									<img style="height:344px;width:100%" src="'.base_url().'asset/images/post/'.$h->gambar.'" alt="'.$h->judul.'">
									<div class="caption">
										<h3><a href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>	
										<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span> '.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>            
										<div class="post-desc">
											'.strip_tags(substr($h->isi,0,250)).'...<a class="more" href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">Selengkapnya &rarr;</a>
										</div>
									</div>
								</div>
							</div>';
	   	}	
		return $output;
	}

	public function get_berita_col2($offset,$limit) {
		$output = "";
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM post ORDER BY id DESC LIMIT $offset,$limit");	
		$count = 0;
		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));	
				$output .= '<div class="col-md-6">
								<div style="margin-bottom:0;" class="thumbnail">
									<img style="height:344px;width:100%" src="'.base_url().'asset/images/post/'.$h->gambar.'" alt="'.$h->judul.'">
									<div class="caption">
										<h3><a href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>	
										<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span> '.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>            
										<div class="post-desc">
											'.strip_tags(substr($h->isi,0,250)).'...<a class="more" href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">Selengkapnya &rarr;</a>
										</div>
									</div>
								</div>
							</div>';
	   	}	
		return $output;
	}

	public function get_berita_all($limit,$offset) {

		$page=$offset;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;

		$tot_hal = $this->db->query("SELECT * FROM post");	


		$config['base_url'] = base_url() . 'Web/berita/index/';
		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$this->pagination->initialize($config);


		$output = "";
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM post ORDER BY id DESC LIMIT $offset,$limit");	
		


		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));
			$output .= '<div class="media">
  							<h3 class="post-title"><a href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>
							<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span>'.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>            
  							<div class="col-md-4 nopadding">
	  							<div class="media-left">
	  								<a href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">
	  									<img class="media-objectx" src="'.base_url().'asset/images/post/'.$h->gambar.'" alt="'.$h->judul.'">
	  								</a>
	  							</div>
	  						</div>
	  						<div class="col-md-8 nopadding">
	  							<div class="media-body">  								
	  								<div class="post-desc">
										'.strip_tags(substr($h->isi,0,500)).'...<a class="more" href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">Selengkapnya &rarr;</a>
									</div>
	  							</div>
  							</div>
  						</div> ';
		}
		$output .= '</div><div class="paging">'.$this->pagination->create_links().'</div>';
		return $output;
	}

	public function get_berita_recent() {
		$output = "";
		$q = $this->db->query("SELECT id,judul FROM post ORDER BY id DESC LIMIT 5");		
		foreach($q->result() as $h) {
			$output .= '<li>
							<a href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a>
						</li>';
		}
		return $output;
	}

	public function get_berita_detail_recent($limit) {
		$output = "";
		$count = 1;		
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM post ORDER BY id DESC LIMIT $limit");	
		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));

			
			if($count == 1 ) {
				$output .= '<div class="row">';
			} 

			if ($count > 1 && $count % 2 != 0) {
				$output .= '<div class="row">';
			} 			
			
			$output .= '	<div class="col-sm-6">					  	
								<div class="thumbnail">
									<img src="'.base_url().'asset/images/post/'.$h->gambar.'" alt="'.$h->judul.'">
									<div class="caption">
										<h3><a href="'.base_url().'Web/berita/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>	
										<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span> '.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>            
									</div>
								</div>
							</div>';	

			if($count % 2 == 0) {
				$output .= '</div>';
			} 

			$count++;

	   	}	
		return $output;
	}

	public function get_berita_with_kategori($limit,$id_kategori) {
		$output = "";
		$count ="";
		$q = $this->db->query("SELECT id,judul,isi,tgl_posting,gambar FROM post WHERE id_kategori=$id_kategori LIMIT $limit");	
		foreach($q->result() as $h) {
			$count++;
			if($count % 2 == 0) {
				$class = 'first';
			} else {
				$class = "";
			}
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));
			$output .= '<div class="column dt-sc-one-half '.$class.'">
                            <article class="blog-entry">
                                <div class="blog-entry-inner">
                                    <div class="entry-meta">                                       
                                        <div class="date">
                                            <span> '.$tanggal[0].' </span> 
                                        	<p> '.$tanggal[1].' <br> '.$tanggal[2].' </p> 
                                        </div>
                                        <a href="#" class="comments">
                                            12 <span class="fa fa-comment"> </span>
                                        </a>
                                        <a href="'.base_url().'web/blog/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'" class="entry_format"><span class="fa fa-picture-o"></span></a>	
                                    </div>		
                                    <div class="entry-thumb">
                                        <a href="#"><img src="'.base_url().'asset/images/post/'.$h->gambar.'" alt="'.$h->judul.'" title="'.$h->judul.'"></a>
                                    </div>		
                                    <div class="entry-details">	
                                        <div class="entry-title">
                                            <h3><a href="'.base_url().'web/blog/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'"> '.$h->judul.' </a></h3>
                                        </div>			
                                        <!--entry-metadata ends-->	
                                        <div class="entry-body">
                                            '.substr($h->isi,0,150).'
                                        </div>	 		
                                        <a href="'.base_url().'web/blog/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'" class="dt-sc-button small"> Read More <span class="fa fa-chevron-circle-right"> </span></a>		
                                    </div>	
                                </div>
                            </article>
                        </div>';

	   	}	
		return $output;
	}

	public function get_berita_detail($id_param) {
		$output = "";	
		$q = $this->db->query("SELECT id,judul,author,isi,tgl_posting,gambar,visited FROM post WHERE id = $id_param");
		$this->db->query("UPDATE post SET visited = visited + 1 WHERE id = $id_param");	
		foreach($q->result() as $h) {			
			$tgl = explode("-",generate_tanggal($h->tgl_posting));
			$output .= '<h3 class="post-title">'.$h->judul.'</h3>
  						<p class="post-meta"> <span class="glyphicon glyphicon-user"></span> '.$h->author.' , <span class="glyphicon glyphicon-calendar"></span> '.$tgl[1].' '.$tgl[0].', '.$tgl[2].'</p>
  						<div class="row">
  							<div class="col-xs-6">
  								<p class="post-conf"><span class="glyphicon glyphicon-eye-open"></span> Post Views : '.$h->visited.'</p>
  							</div>
  							<div style="text-align:right;" class="col-xs-6">
  								<script>var pfHeaderImgUrl = "";var pfHeaderTagline = "";var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = "left";var pfDisablePDF = 0;var pfDisableEmail = 1;var pfDisablePrint = 0;var pfCustomCSS = "";var pfBtVersion="1";(function(){var js, pf;pf = document.createElement("script");pf.type = "text/javascript";if ("https:" === document.location.protocol){js="https://pf-cdn.printfriendly.com/ssl/main.js"}else{js="http://cdn.printfriendly.com/printfriendly.js"}pf.src=js;document.getElementsByTagName("head")[0].appendChild(pf)})();</script><a href="#" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
					
  							</div>
  						</div>  						
  						<div class="post-desc">
							'.$h->isi.'
						</div>';

	   	}	
		return $output;
	}

	public function get_download_detail($id_param) {
		$output = "";
		$count ="";
		$get_judul = $this->db->query("SELECT
						    kategori_file.kategori_file
						FROM
						    file
						    INNER JOIN kategori_file 
						        ON (file.id_kategori = kategori_file.id_kategori)")->row();
		$q = $this->db->query("SELECT * FROM file WHERE id_kategori = $id_param");
		$output .= '<h3 class="post-title">'.$get_judul->kategori_file.'</h3>
						<table class="table">
	                        <thead>
	                            <tr>
		                            <th>Nama File</th>
		                            <th>Keterangan</th>
		                            <th>Tanggal Upload</th>
		                            <th>Download</th>
	                            </tr>
	                        </thead>
	                        <tbody>';
		foreach($q->result() as $h) {
			$output .= '<tr>
							<td>'.$h->nama.'</td>
							<td>'.$h->keterangan.'</td>
							<td style="width:15%;">'.$h->tgl_upload.'</td>
							<td><a href="'. base_url().'Web/download/get/'.$h->id.'" target="_blank">Download</a></td>
						</tr>';

	   	}	
	   	$output .= '</table>';
		return $output;
	}
	
	public function get_foot_about() {
		$output = "";
		$q = $this->db->query("SELECT tentang FROM about");		
		foreach($q->result() as $h) {
			$output .= '<p>'.strip_tags(substr($h->tentang,0,150)).' ... <a class="more" href="'.base_url().'Web/about/">Selengkapnya &rarr;</a></p>';
		}
		return $output;
	}

	public function get_foot_kontak() {
		$output = "";
		$q = $this->db->query("SELECT alamat,email,telpon,bbm FROM about");		
		foreach($q->result() as $h) {
			$output .= '<li><span class="glyphicon glyphicon-map-marker"></span> '.$h->alamat.'</li>
            			<li><span class="glyphicon glyphicon-envelope"></span> '.$h->email.'</li>
            			<li><span class="glyphicon glyphicon-earphone"></span> '.$h->telpon.'</li>
            			<li><span class="glyphicon glyphicon-globe"></span> '.$h->bbm.'</li>';
		
		}
		return $output;
	}

	public function get_foot_album($limit) {
		$output = "";
		$q = $this->db->query("SELECT * FROM album ORDER BY id_album DESC LIMIT $limit");		
		foreach($q->result() as $h) {
			$output .= '<div class="col-xs-6">
		                	<a href="'.base_url().'Web/gallery/photo/'.$h->id_album.'"><img src="'.base_url().'asset/images/album/'.$h->gambar.'"></a>
		              	</div>';
		
		}
		return $output;
	}
	
	public function get_foot_video($limit) {
		$output = "";
		$q = $this->db->query("SELECT * FROM video ORDER BY id DESC LIMIT $limit");		
		foreach($q->result() as $h) {
			$output .= '<div style="height:260px;" class="embed-responsive embed-responsive-16by9">
				            <iframe class="embed-responsive-item" allowfullscreen="allowfullscreen" src="http://www.youtube.com/embed/'.$h->url.'?autoplay=0"></iframe>
				          </div>';
		
		}
		return $output;
	}
	
	public function get_foot_map() {
		$output = "";
		$q = $this->db->query("SELECT map FROM about")->row();		
		
		return $q->map;
	}
	
	public function get_fanspage() {
		$output = "";
		$q = $this->db->query("SELECT fanspage FROM about")->row();		
		$fanspage = '<iframe src="http://www.facebook.com/plugins/likebox.php?href='.$q->fanspage.'&width=300&height=250&colorscheme=light&show_faces=true&header=false&stream=false&show_border=false" scrolling="no" style="border:none; overflow:hidden; width:300px; height:250px;" allowtransparency="true" frameborder="0"></iframe>';
		return $fanspage ;
	}

	public function get_photo_main($id_param) {
		$output = "";
		$count = 0;
		$q = $this->db->query("SELECT * FROM photo WHERE id_album ='$id_param'");		
		foreach($q->result() as $h) {
			$output .= '<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 mbr-gallery-item">
                                  <a href="#lb-gallery2-0" data-slide-to="'.$count.'" data-toggle="modal">
                                      <img class="img-responsive" alt="'.$h->keterangan.'" src="'.base_url().'asset/images/photo/'.$h->gambar.'">
                                      <span class="icon glyphicon glyphicon-zoom-in"></span>
                                  </a>
                        </div>';
			$count++;
		}
		return $output;
	}

	public function get_photo_bullet($id_param) {
		$output = "";
		$count = 0;
		$q = $this->db->query("SELECT count(id_album) AS count FROM photo WHERE id_album='$id_param';")->row();
		
		for ($i=0; $i < $q->count; $i++) { 
			$output .= '<li data-app-prevent-settings="" data-target="#lb-gallery2-0" data-slide-to="'.$i.'"></li>';
		}
		return $output;
	}
	
	public function get_visi() 
	{
		$output = "";
		$q = $this->db->query("SELECT * FROM visimisi");		
		foreach($q->result() as $h) {
			$output .= '<p class="post-conf"></span> '.$h->visi.'</p>';
		}
		return $output;
	}
    
    public function get_misi() 
	{
		$output = "";
		$q = $this->db->query("SELECT * FROM visimisi");		
		foreach($q->result() as $h) {
			$output .= '<p class="post-conf"></span> '.$h->misi.'</p>';
		}
		return $output;
	}
	
	public function get_struktur() 
	{
		$output = "";
	    $q = $this->db->query("SELECT * FROM struktur");
	    foreach($q->result() as $h) 
	    {
	        $output .= '    <center>
	                            <div class="struktur">
	  								<img src="'.base_url().'/asset/images/struktur/'.$h->gambar.'" width="620" height="700">
	  						</div>';
		}
		return $output;
	}
	
	public function get_photo_modal($id_param) {
		$output = "";
		$count = "";
		$q = $this->db->query("SELECT * FROM photo WHERE id_album ='$id_param'");		
		foreach($q->result() as $h) {
			$count++;
			if($count == 1) {
				$class = 'active';
			} else {
				$class = "";
			}
			$output .= '<div class="item '.$class.'">
                            <img alt="'.$h->keterangan.'" src="'.base_url().'asset/images/photo/'.$h->gambar.'">
                        </div>
';
		}
		return $output;
	}

	public function get_informasi($limit) {
		$output = "";
		$count = 0;		
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM informasi ORDER BY id DESC LIMIT $limit");	
		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));

			
			if($count < 1) {
				$output .= '<div class="col-md-6">
  								<div class="thumbnail">
									<img style="height:344px;width:100%;" src="'.base_url().'asset/images/informasi/'.$h->gambar.'" alt="'.$h->judul.'">
									<div class="caption">
										<h3><a href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>	
										<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span>'.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>         
										<div class="post-desc">'.strip_tags(substr($h->isi,0,550)).'..</div>
										<a style="font-size:12px;" class="more" href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">Selengkapnya &rarr;</a>
									</div>
								</div>
  							</div>';
			} else {	 		
			
			$output .= '<div class="col-md-6">';

			$output .= '<div class="media">
							<div class="media-left">
								<a href="'.base_url().'web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">
								<img class="media-object" src="'.base_url().'asset/images/informasi/'.$h->gambar.'" alt="'.$h->judul.'">
								</a>
							</div>
							<div class="media-body">
								<h3 class="media-heading"><a href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>
								<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span> '.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>         
							</div>
						</div>';	

			
			$output .= '</div>';
			}

			$count++;

	   	}	
		return $output;
	}


	public function get_informasi_all($limit,$offset) {
		$page=$offset;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;

		$tot_hal = $this->db->query("SELECT * FROM post");	


		$config['base_url'] = base_url() . 'Web/berita/index/';
		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$this->pagination->initialize($config);

		$output = "";
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM informasi ORDER BY id DESC LIMIT $offset,$limit");	
		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));
			$output .= '<div class="media">
  							<h3 class="post-title"><a href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>
							<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span>'.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>        
  							<div class="col-md-4 nopadding-left">
	  							<div class="media-left">
	  								<a href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">
	  									<img class="media-objectx" src="'.base_url().'asset/images/informasi/'.$h->gambar.'" alt="'.$h->judul.'">
	  								</a>
	  							</div>
	  						</div>
	  						<div class="col-md-8">
	  							<div class="media-body">  								
	  								<div class="post-desc">
										'.strip_tags(substr($h->isi,0,500)).'...<a class="more" href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">Selengkapnya &rarr;</a>
									</div>
	  							</div>
  							</div>
  						</div> ';
		}
		$output .= '</div><div class="paging">'.$this->pagination->create_links().'</div>';
		return $output;
	}

	public function get_informasi_detail($id_param) {
		$output = "";	
		$q = $this->db->query("SELECT id,judul,author,isi,tgl_posting,gambar,visited FROM informasi WHERE id = $id_param");
		$this->db->query("UPDATE informasi SET visited = visited + 1 WHERE id = $id_param");	
		foreach($q->result() as $h) {			
			$tgl = explode("-",generate_tanggal($h->tgl_posting));
			$output .= '<h3 class="post-title">'.$h->judul.'</h3>
  						<p class="post-meta"> <span class="glyphicon glyphicon-user"></span> '.$h->author.' , <span class="glyphicon glyphicon-calendar"></span> '.$tgl[1].' '.$tgl[0].', '.$tgl[2].'</p>
  						<div class="row">
  							<div class="col-xs-6">
  								<p class="post-conf"><span class="glyphicon glyphicon-eye-open"></span> Informasi Views : '.$h->visited.'</p>
  							</div>
  							<div style="text-align:right;" class="col-xs-6">
  								<script>var pfHeaderImgUrl = "";var pfHeaderTagline = "";var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = "left";var pfDisablePDF = 0;var pfDisableEmail = 1;var pfDisablePrint = 0;var pfCustomCSS = "";var pfBtVersion="1";(function(){var js, pf;pf = document.createElement("script");pf.type = "text/javascript";if ("https:" === document.location.protocol){js="https://pf-cdn.printfriendly.com/ssl/main.js"}else{js="http://cdn.printfriendly.com/printfriendly.js"}pf.src=js;document.getElementsByTagName("head")[0].appendChild(pf)})();</script><a href="#" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
  							</div>
  						</div>  						
  						<div class="post-desc">
							'.$h->isi.'
						</div>';

	   	}	
		return $output;
	}

	public function get_informasi_detail_recent($limit) {
		$output = "";
		$count = 1;		
		$q = $this->db->query("SELECT author,id,judul,isi,tgl_posting,gambar FROM informasi ORDER BY id DESC LIMIT $limit");	
		foreach($q->result() as $h) {
			$tanggal = explode("-",generate_tanggal($h->tgl_posting));

			
			if($count == 1 ) {
				$output .= '<div class="row">';
			} 

			if ($count > 1 && $count % 2 != 0) {
				$output .= '<div class="row">';
			} 			
			
			$output .= '	<div class="col-sm-6">					  	
								<div class="thumbnail">
									<img src="'.base_url().'asset/images/informasi/'.$h->gambar.'" alt="'.$h->judul.'">
									<div class="caption">
										<h3><a href="'.base_url().'Web/informasi/detail/'.$h->id.'/'.url_title($h->judul,'-',TRUE).'">'.$h->judul.'</a></h3>	
										<p class="date"><span class="glyphicon glyphicon-user"></span> '.$h->author.'  ,  <span class="glyphicon glyphicon-calendar"></span> '.$tanggal[1].' '.$tanggal[0].','.$tanggal[2].'</p>            
									</div>
								</div>
							</div>';	

			if($count % 2 == 0) {
				$output .= '</div>';
			} 

			$count++;

	   	}		
		return $output;
	}


	public function get_kontak() {
		$output = "";
		$q = $this->db->query("SELECT * FROM about");		
		foreach($q->result() as $h) {
			$output .= '<p class="post-conf"><span class="glyphicon glyphicon-map-marker"></span> '.$h->alamat.'</p> 
			<p class="post-conf"><span class="glyphicon glyphicon-earphone"></span> '.$h->telpon.'</p> 
			<p class="post-conf"><span class="glyphicon glyphicon-envelope"></span> '.$h->email.'</p>';
		}
		return $output;
	}
	
	public function get_team()
	{
	    $output = "";
	    $q = $this->db->query("SELECT * FROM staff");
	    foreach($q->result() as $h) 
	    {
	        $output .= '<div class="album">
	  							<div class="col-md-4">
	  								<img src="'.base_url().'/asset/images/staff/'.$h->gambar.'">
	  							</div>
	  							<br>
	  							<div class="col-md-8">
	  								<h5><a href="'.base_url().'asset/images/staff/'.$h->gambar.'">'.$h->nama.'</a></h5>
	  								<br>
	  								<p class="post-desc">'.$h->nip.'</a></p>
	  							</div>
	  						</div>';
		}
		return $output;
	}

	public function get_logo() {
		$output = "";
		$q = $this->db->query("SELECT author,gambar FROM about");		
		foreach($q->result() as $h) {
			$output .= '<a href="'.base_url().'" title="'.$h->author.'"><img class="logo" src="'.base_url().'asset/images/banner/'.$h->gambar.'" alt="'.$h->author.'" title="'.$h->author.'"></a>';
		}
		return $output;
	}

	public function get_link($limit) {
		$output = "";
		$q = $this->db->query("SELECT keterangan,url,gambar FROM link WHERE aktif='Y' LIMIT $limit");		
		foreach($q->result() as $h) {
			$output .= '<a href="'.$h->url.'" target="_blank"><img class="img-responsive" src="'.base_url().'asset/images/link/'.$h->gambar.'" alt="'.$h->keterangan.'" title="'.$h->keterangan.'"></a>';
		}
		return $output;
	}


	public function get_navbar($parent = 0) {
		$data = [];
	    //$this->db->where('id_parent', $parent);
	    //$this->db->order_by('posisi', 'ASC');
	    //$result = $this->db->get('menu');
              $result = $this->db->query("SELECT * FROM menu WHERE id_parent='$parent ' AND aktif ='Y' ORDER BY posisi ASC");
	      foreach ($result->result() as $row) {
	         $data[] = [
	            'id_menu' => $row->id_menu,
	            'nama' => $row->nama,
	            'url' => $row->url,
	            'child' => $this->get_navbar($row->id_menu),
	         ];
      }

      return $data;
	}	


	public function get_sambutan() {
		$output = "";
		$q = $this->db->query("SELECT * FROM kepsek");		
		foreach($q->result() as $h) {
			$output .= '<div class="media">
							<div class="media-left">
								<a href="'.base_url().'">
								<img style="width:100px;height:120px;" class="media-object" src="'.base_url().'asset/images/staff/'.$h->gambar.'" alt="'.$h->nama.'">
								</a>
							</div>
							<div class="media-body">
								<h3 class="media-heading"><a href="'.base_url().'">'.$h->nama.'</a></h3>
								<div style="text-align:left;">'.strip_tags(substr($h->sambutan,0,100)).'...<a class="more" href="'.base_url().'Web/sambutan">Selengkapnya &rarr;</a></div>
							</div>
						</div>';
		}
		return $output;
	}
	
	public function get_sambutan_detail() {
		$output = "";
		$q = $this->db->query("SELECT * FROM kepsek");		
		foreach($q->result() as $h) {
			$output .= '<h3 class="post-title">Sambutan Kepala Badan</h3>
  						<p class="post-meta"> posted by: '.$h->nama.'</p>
  						<div class="row">
  							<div style="margin-bottom:10px; text-align:right;" class="col-xs-12">
  								<script>var pfHeaderImgUrl = "";var pfHeaderTagline = "";var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = "right";var pfDisablePDF = 0;var pfDisableEmail = 1;var pfDisablePrint = 0;var pfCustomCSS = "";var pfBtVersion="1";(function(){var js, pf;pf = document.createElement("script");pf.type = "text/javascript";if ("https:" === document.location.protocol){js="https://pf-cdn.printfriendly.com/ssl/main.js"}else{js="http://cdn.printfriendly.com/printfriendly.js"}pf.src=js;document.getElementsByTagName("head")[0].appendChild(pf)})();</script><a href="#" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
  							</div>
  						</div>  						
  						<div class="post-desc">
							'.$h->sambutan.'
						</div>';
		}
		return $output;
	}
    
    public function get_tupoksi() {
		$output = "";
		$q = $this->db->query("SELECT * FROM tupoksi");		
		foreach($q->result() as $h) {
			$output .= '
  						<div class="row">
  							<div style="margin-bottom:10px; text-align:right;" class="col-xs-12">
  								<script>var pfHeaderImgUrl = "";var pfHeaderTagline = "";var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = "right";var pfDisablePDF = 0;var pfDisableEmail = 1;var pfDisablePrint = 0;var pfCustomCSS = "";var pfBtVersion="1";(function(){var js, pf;pf = document.createElement("script");pf.type = "text/javascript";if ("https:" === document.location.protocol){js="https://pf-cdn.printfriendly.com/ssl/main.js"}else{js="http://cdn.printfriendly.com/printfriendly.js"}pf.src=js;document.getElementsByTagName("head")[0].appendChild(pf)})();</script><a href="#" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
  							</div>
  						</div>  						
  						<div class="post-desc">
							'.$h->ptupoksi.'
						</div>';
		}
		return $output;
	}
	public function get_sambutan_poto() {
		$output = "";
		$q = $this->db->query("SELECT * FROM kepsek");		
		foreach($q->result() as $h) {
			$output .= '<img style="margin-bottom:10px;width:150px;height:200px;border:1px solid #DDD;" src="'.base_url().'asset/images/staff/'.$h->gambar.'" alt="'.$h->nama.'">
						<p>'.$h->nama.'</p>
						<p>'.$h->jabatan.'</p>';
		}
		return $output;
	}

	public function get_social() {
		$output = "";
		$q = $this->db->query("SELECT * FROM about");		
		foreach($q->result() as $h) {
			$output .= '<a class="resp-sharing-button__link" href="'.$h->facebook.'" target="_blank" aria-label="Share on Facebook">
					  <div class="resp-sharing-button resp-sharing-button--facebook resp-sharing-button--medium">On Facebook</div>
					</a>

					<!-- Sharingbutton Twitter -->
					<a class="resp-sharing-button__link" href="'.$h->twitter.'" target="_blank" aria-label="Share on Twitter">
					  <div class="resp-sharing-button resp-sharing-button--twitter resp-sharing-button--medium">On Twitter</div>
					</a>

					<!-- Sharingbutton Google+ -->
					<a class="resp-sharing-button__link" href="'.$h->google.'" target="_blank" aria-label="Share on Google+">
					  <div class="resp-sharing-button resp-sharing-button--google resp-sharing-button--medium">On Google+</div>
					</a>';
		}
		return $output;
	}

	public function get_slideshow($limit) {
		$output = "";
		$count = "";
		$q = $this->db->query("SELECT * FROM slideshow ORDER BY id DESC LIMIT $limit");		
		foreach($q->result() as $h) {
			$count++;
			if($count == 1) {
				$class = 'active';
			} else {
				$class = "";
			}
			$output .= '<div class="item '.$class.'">
							<img src="'.base_url().'asset/images/slideshow/'.$h->gambar.'">	
							<p>'.$h->keterangan.'</p>				
						</div>';
		}
		return $output;
	}


	public function get_top_informasi() {
		$output = "";
		$q = $this->db->query("SELECT pesan_pembuka FROM about");		
		foreach($q->result() as $h) {
						$output .= '&nbsp;&nbsp;&nbsp;&nbsp;'.$h->pesan_pembuka .'&nbsp;&nbsp;&nbsp;&nbsp;';

		}
		return $output;
	}	

	public function get_page_detail($id_param) {
		$output = "";	
		$q = $this->db->query("SELECT * FROM page WHERE id = $id_param");	
		foreach($q->result() as $h) {			
			$tgl = explode("-",generate_tanggal($h->tgl_posting));
			$output .= '<h3 class="post-title">'.$h->judul.'</h3>
  						<p class="post-meta"> <span class="glyphicon glyphicon-user"></span> '.$h->author.' , <span class="glyphicon glyphicon-calendar"></span> '.$tgl[1].' '.$tgl[0].', '.$tgl[2].'</p>
  						<div class="row">
  							<div class="col-xs-6">
  								<script>var pfHeaderImgUrl = "";var pfHeaderTagline = "";var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = "left";var pfDisablePDF = 0;var pfDisableEmail = 1;var pfDisablePrint = 0;var pfCustomCSS = "";var pfBtVersion="1";(function(){var js, pf;pf = document.createElement("script");pf.type = "text/javascript";if ("https:" === document.location.protocol){js="https://pf-cdn.printfriendly.com/ssl/main.js"}else{js="http://cdn.printfriendly.com/printfriendly.js"}pf.src=js;document.getElementsByTagName("head")[0].appendChild(pf)})();</script><a href="#" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Printer Friendly and PDF"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="http://cdn.printfriendly.com/button-print-grnw20.png" alt="Print Friendly and PDF"/></a>
  							</div>
  						</div>  						
  						<div class="post-desc">
							'.$h->isi.'
						</div>';

                   if(!empty($h->keterangan_file) || !empty($h->file)) {
                       $output .= '<div class="post-desc">
                                    <center><p>'.$h->keterangan_file.'</p></center>
			            <center><a href="'.base_url().'Web/page/download/'.$h->id.'">Download</a></p></center>
			           </div>';
                   }
                                                

	   	}	
		return $output;
	}

	public function get_staff($limit,$offset) {
		$page=$offset;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;

		$tot_hal = $this->db->query("SELECT * FROM staff");	


		$config['base_url'] = base_url() . 'Web/staff/index/';
		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$this->pagination->initialize($config);
		$output = "";
		$q = $this->db->query("SELECT * FROM staff LIMIT $offset,$limit");		
		foreach($q->result() as $h) {
			$output .= '<div class="album">
	  							<div class="col-md-4">
	  								<img style="height:200px; width:100%;" src="'.base_url().'asset/images/staff/'.$h->gambar.'">
	  							</div>
	  							<div class="col-md-8">
	  								<h5><a href="'.base_url().'">'.$h->nama.'</a></h5>
	  								<h6 class="post-desc">'.$h->jabatan.'</a></h6>
	  								<p class="post-desc">'.$h->keterangan.'</a></p>
	  							</div>
	  						</div>';
		}
		$output .= '</div></div><div class="paging">'.$this->pagination->create_links().'</div>';

		return $output;
	}
	
	public function get_video($limit,$offset) {

		$page=$offset;
		if(!$page):
		$offset = 0;
		else:
		$offset = $page;
		endif;

		$tot_hal = $this->db->query("SELECT * FROM video");	


		$config['base_url'] = base_url() . 'Web/gallery/video/';
		$config['total_rows'] = $tot_hal->num_rows();
		$config['per_page'] = $limit;
		$config['uri_segment'] = 4;
		$config['first_link'] = 'First';
		$config['last_link'] = 'Last';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Prev';
		$this->pagination->initialize($config);

		$output = "";
		$q = $this->db->query("SELECT * FROM video LIMIT $offset,$limit");		
		foreach($q->result() as $h) {
			$output .= '<div class="album">
	  							<div class="col-md-6">
	  								<div class="embed-responsive embed-responsive-16by9">
							            <iframe class="embed-responsive-item" src="http://www.youtube.com/embed/'.$h->url.'?autoplay=0"></iframe>
							         </div>
	  							</div>
	  							<div class="col-md-6">
	  								<h5><a href="https://www.youtube.com/'.$h->url.'" target="_blank">'.$h->judul.'</a></h5>
	  							</div>
	  						</div>';
		}
		$output .= '</div></div><div class="paging">'.$this->pagination->create_links().'</div>';

		return $output;
	}
}
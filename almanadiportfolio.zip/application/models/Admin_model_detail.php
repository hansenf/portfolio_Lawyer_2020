<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin_model_detail extends CI_Model {

	public function get_combo_kategori_file($id_param="") {
		$hasil = "";
		$q = $this->db->query("SELECT * FROM kategori_file WHERE kategori_file NOT IN ('default')");
		$hasil .= '<select  style="width: 30%;" class="form-control" id="kategori" name="kategori" required>';
		$hasil .= '<option selected="selected" value>-Pilih Kategori-</option>';
		foreach($q->result() as $h) {
			if($id_param == $h->id_kategori) {
				$hasil .= '<option value="'.$h->id_kategori.'" selected="selected">'.$h->kategori_file.'</option>';
			} else {
				$hasil .= '<option value="'.$h->id_kategori.'">'.$h->kategori_file.'</option>';
			}
		}
		$hasil .= '</select>';
		return $hasil;
	}
	
	public function get_combo_jenis_izin($id_param="") {
		$hasil = "";
		$q = $this->db->query("SELECT * FROM jenis_izin WHERE id_jenis_izin NOT IN ('default')");
		$hasil .= '<select  style="width: 30%;" class="form-control" name="jenis_izin" required>';
		$hasil .= '<option selected="selected" value>-Pilih Jenis Izin-</option>';
		foreach($q->result() as $h) {
			if($id_param == $h->id_jenis_izin) {
				$hasil .= '<option value="'.$h->id_jenis_izin.'" selected="selected">'.$h->keterangan.'</option>';
			} else {
				$hasil .= '<option value="'.$h->id_jenis_izin.'">'.$h->keterangan.'</option>';
			}
		}
		$hasil .= '</select>';
		return $hasil;
	}

	public function get_combo_album($id_param="") {
		$hasil = "";
		$q = $this->db->query("SELECT id_album,nama FROM album");
		$hasil .= '<select  style="width: 30%;" class="form-control" id="album" name="album" required>';
		$hasil .= '<option selected="selected" value>-Pilih Album-</option>';
		foreach($q->result() as $h) {
			if($id_param == $h->id_album) {
				$hasil .= '<option value="'.$h->id_album.'" selected="selected">'.$h->nama.'</option>';
			} else {
				$hasil .= '<option value="'.$h->id_album.'">'.$h->nama.'</option>';
			}
		}
		$hasil .= '</select>';
		return $hasil;
	}

	public function get_combo_kategori_post($id_param="") {
		$hasil = "";
		$q = $this->db->get("kategori_post");
		$hasil .= '<select  style="width: 30%;" class="form-control" id="kategori" name="kategori" required>';
		$hasil .= '<option selected="selected" value>-Pilih Kategori-</option>';
		foreach($q->result() as $h) {
			if($id_param == $h->id_kategori) {
				$hasil .= '<option value="'.$h->id_kategori.'" selected="selected">'.$h->kategori_post.'</option>';
			} else {
				$hasil .= '<option value="'.$h->id_kategori.'">'.$h->kategori_post.'</option>';
			}
		}
		$hasil .= '</select>';
		return $hasil;
	}

	public function get_combo_kategori_informasi($id_param="") {
		$hasil = "";
		$q = $this->db->get("kategori_informasi");
		$hasil .= '<select  style="width: 30%;" class="form-control" id="kategori" name="kategori" required>';
		$hasil .= '<option selected="selected" value>-Pilih Kategori-</option>';
		foreach($q->result() as $h) {
			if($id_param == $h->id_kategori) {
				$hasil .= '<option value="'.$h->id_kategori.'" selected="selected">'.$h->kategori_informasi.'</option>';
			} else {
				$hasil .= '<option value="'.$h->id_kategori.'">'.$h->kategori_informasi.'</option>';
			}
		}
		$hasil .= '</select>';
		return $hasil;
	}

	public function get_combo_page($id_param="") {
		$hasil = "";
		$q = $this->db->get("page");
		$hasil .= '<select class="form-control" id="page" name="page" required>';
		$hasil .= '<option selected="selected" value>-Pilih Page-</option>';
		foreach($q->result() as $h) {
			$hasil .= '<option value="'.$h->id.'">'.$h->judul.'</option>';

		}
		$hasil .= '</select>';
		return $hasil;
	}

}
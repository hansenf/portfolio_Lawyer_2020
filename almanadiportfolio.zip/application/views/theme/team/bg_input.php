<div class="row">
  			<div class="col-md-12">
				<div class="content">  
  					<div class="contentdetail-box">
  						
  						<h3 class="post-title">Team Lawyer</h3>
  							<div class="row">
  			<div class="col-md-8">
				<div class="content">  
  					<div class="contentdetail-box">
  						<h3 class="post-title">Lawyer</h3>
  						<div class="row">

  							<?php echo $team; ?>
  							
  					
				</div>

  			</div>
				</div>

				<div class="share">
	  				<span class="share-light">Find Us !</span>
	  				<!-- Sharingbutton Facebook -->
					
					<?php echo $social; ?>

				</div>

  			</div>
 </div> <!--end row home -->
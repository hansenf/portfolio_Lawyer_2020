  		<div class="row">
  			<div class="col-md-8">
				<div class="content">  
  					<div class="contentdetail-box">
  						<h3 class="post-title">GALLERY PHOTO</h3>
  						<div class="row">

  							<?php echo $album; ?>
  							
  					
				</div>

  			</div>
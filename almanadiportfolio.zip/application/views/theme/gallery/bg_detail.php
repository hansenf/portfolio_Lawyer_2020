  		<div class="row">
  			<div class="col-md-8">
  				<div class="content">  
    					<div class="contentdetail-box">
    						<?php echo $album_title; ?>
                
    						<div class="row">

    							<section style="padding:15px;" class="mbr-gallery mbr-section mbr-section--no-padding" id="gallery2-0">
                  <!-- Gallery -->                      
                          <div class="row mbr-gallery-row no-gutter">       
                              
                              <?php echo $photo_main; ?>
                              
           
                          </div>
                 
                      <div class="clearfix"></div>
                 
                      <!-- Lightbox -->
                     <div data-app-prevent-settings="" class="mbr-slider modal fade carousel slide" tabindex="-1" data-keyboard="true" data-interval="false" id="lb-gallery2-0">
                      <div class="modal-dialog">
                          <div class="modal-content">
                              <div class="modal-body">
                                  <ol class="carousel-indicators">
                                    
                                    <?php echo $photo_bullet; ?>

                                  </ol>
                                  <div class="carousel-inner">
               
                                    <?php echo $photo_modal; ?>                                
              
                                  </div>
                                  <a class="left carousel-control" role="button" data-slide="prev" href="#lb-gallery2-0">
                                      <span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span>
                                      <span class="sr-only">Previous</span>
                                  </a>
                                  <a class="right carousel-control" role="button" data-slide="next" href="#lb-gallery2-0">
                                      <span class="glyphicon glyphicon glyphicon-arrow-right" aria-hidden="true"></span>
                                      <span class="sr-only">Next</span>
                                  </a>

                                  <a class="close" href="#" role="button" data-dismiss="modal">
                                      <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                                      <span class="sr-only">Close</span>
                                  </a>
                              </div>
                          </div>
                      </div>
                  </div>
                </section>
    							
    					</div>
  					</div>
  				</div>

  			</div>
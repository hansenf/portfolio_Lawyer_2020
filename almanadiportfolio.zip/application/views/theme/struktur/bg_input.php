<div class="row">
  			<div class="col-md-12">
				<div class="content">  
  					<div class="contentdetail-box">
  						
  						<h3 class="post-title"><p align="center"></center>Struktur Organisasi</h3>
  						<div class="row">
  							        <?= $struktur ?>	
  								</center>

  							</div>
  							 						
  	

					</div>
				</div>

				<div class="share">
	  				<span class="share-light">Find Us !</span>
	  				<!-- Sharingbutton Facebook -->
					
					<?php echo $social; ?>

				</div>

  			</div>
 </div> <!--end row home -->
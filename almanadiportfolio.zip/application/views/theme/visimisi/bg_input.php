<div class="row">
  			<div class="col-md-12">
				
  					<div class="contentdetail-box">
  						
  						<h3><p class="-" align="center">Visi</h3>
  					        <center>
  					        <?= $visi ?>
  							
					    
					    <h3><p class="-" align="center">Misi</h3>
  							<center>
                                <?= $misi ?>
  							
					  
				</div>

				<div class="share">
	  				<span class="share-light">Find Us !</span>
	  				<!-- Sharingbutton Facebook -->
					
					<?php echo $social; ?>

				</div>

  			</div>
 </div> <!--end row home -->
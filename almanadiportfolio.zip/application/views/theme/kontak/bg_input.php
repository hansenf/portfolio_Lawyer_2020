<div class="row">
  			<div class="col-md-12">
				<div class="content">  
  					<div class="contentdetail-box">
  						
  						<h3 class="post-title">Kontak Kami</h3>
  						<div class="row">
  							<div class="col-md-6">
  								
  								<?php echo $kontak; ?>

  							</div>
  							<div class="col-md-6">
  								<h4>Kirim Pesan</h4>
  								<?php echo form_open("Web/kontak/kirim"); ?>
								<div class="form-group">									
									<input style="" type="text" class="form-control" id="nama" name="nama" placeholder="nama anda .." requried>
								</div>
								<div class="form-group">									
									<input style="" type="email" class="form-control" id="email" name="email" placeholder="email anda .." requried>
								</div>
								<div class="form-group">									
									<input style="" type="text" class="form-control" id="subjek" name="subjek" placeholder="judul pesan.." requried>
								</div>
								<div class="form-group">	
									<textarea style="height:100px;"class="form-control" id="tentang" name="message" placeholder="isi pesan .." requried></textarea>
								</div> 
								<div style="text-align:right" class="form-group">									
									<button style="font-weight:bold;font-size:16;width:150px; height:40px;" type="submit" class="btn btn-primary">Kirim</button>
								</div>  
								<?php echo form_close(); ?> 							
							</div>
  						</div>  						
  	

					</div>
				</div>

				<div class="share">
	  				<span class="share-light">Find Us !</span>
	  				<!-- Sharingbutton Facebook -->
					
					<?php echo $social; ?>

				</div>

  			</div>
 </div> <!--end row home -->
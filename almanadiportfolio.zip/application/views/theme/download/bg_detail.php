<div class="row">
  			<div class="col-md-8">
				<div class="content">  
  					<div class="contentdetail-box">
  						
  						<?php echo $download_detail; ?>

					</div>
				</div>

				<div class="share">
	  				<span class="share-light">SHARE !</span>
	  				<!-- Sharingbutton Facebook -->
					<a class="resp-sharing-button__link" href="https://facebook.com/sharer/sharer.php?u=<?php echo current_url(); ?>" target="_blank" aria-label="Share on Facebook">
					  <div class="resp-sharing-button resp-sharing-button--facebook resp-sharing-button--medium">Share on Facebook</div>
					</a>

					<!-- Sharingbutton Twitter -->
					<a class="resp-sharing-button__link" href="https://twitter.com/intent/tweet/?text=Super%20fast%20and%20easy%20Social%20Media%20Sharing%20Buttons.%20No%20JavaScript.%20No%20tracking.&amp;url=<?php echo current_url(); ?>" target="_blank" aria-label="Share on Twitter">
					  <div class="resp-sharing-button resp-sharing-button--twitter resp-sharing-button--medium">Share on Twitter</div>
					</a>

					<!-- Sharingbutton Google+ -->
					<a class="resp-sharing-button__link" href="https://plus.google.com/share?url=<?php echo current_url(); ?>" target="_blank" aria-label="Share on Google+">
					  <div class="resp-sharing-button resp-sharing-button--google resp-sharing-button--medium">Share on Google+</div>
					</a>

				</div>

				<div class="content">
  					<div class="widget-title">
  						<h4>BACA JUGA</h4>
  						<div class="widget-line"></div>
  					</div>
  					<div class="content-box">
						
  						<?php echo $berita_recent_detail; ?>

					</div>
				</div>
  			</div>
<?php if ($this->session->flashdata('msg_pengaduan')): ?>
	<script>
	swal({
	title: "Pengaduan Terkirim",
	text: "<?php echo $this->session->flashdata('msg_pengaduan'); ?>",
	timer: 2000,
	showConfirmButton: false,
	type: 'success'
	});
	</script>
   <?php endif; ?>
<div class="row">
  			<div class="col-md-12">
				<div class="content">  
  					<div class="contentdetail-box">
  						
  						<h3 class="post-title">Form Konsultasi Bantuan Hukum</h3>
  						<div class="row">
  							<div class="col-md-12">
  								<?php echo form_open_multipart("Web/pengaduan/kirim"); ?>
								<div class="form-group">									
									<input style="" type="text" class="form-control" id="nik_ktp" name="nik_ktp" placeholder="Ketikan NIK/KTP .." requried>
								</div>
								<div class="form-group">									
									<input style="" type="text" class="form-control" id="nama" name="nama" placeholder="Ketikan Nama Lengkap / Instansi / Perusahaan .." requried>
								</div>
								<div class="form-group">	
									<textarea style="height:100px;"class="form-control" id="alamat" name="alamat" placeholder="Ketikan Alamat Lengkap .." requried></textarea>
								</div> 
								<div class="form-group">									
									<input style="" type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Ketikan No.Telpon .." requried>
								</div>
								<div class="form-group">	
									<textarea style="height:150px;"class="form-control" id="pesan" name="pesan" placeholder="isi pesan .." requried></textarea>
								</div> 
								<div class="form-group">
			                                           <label>Lampiran File/Gambar</label>									
									<input style="" type="file" class="form-control" id="gambar_pengaduan" name="gambar_pengaduan">
								</div>
								<div style="text-align:right" class="form-group">									
									<button style="font-weight:bold;font-size:16;width:150px; height:40px;" type="submit" class="btn btn-primary">Kirim</button>
								</div>  
								<?php echo form_close(); ?> 							
							</div>
  						</div>  						
  	

					</div>
				</div>
<div class="share">
	  				<span class="share-light">Find Us !</span>
	  				<!-- Sharingbutton Facebook -->
					
					<?php echo $social; ?>

				</div>

  			</div>
 </div> <!--end row home -->
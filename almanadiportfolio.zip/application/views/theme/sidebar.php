	<div class="col-md-4">
  				
  				
  				<div class="widget">
  					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-blackboard"></i> SAMBUTAN </h4></font>
  						<div class="widget-line"></div>
  					</div>
  					<div class="widget-box">
  						<?php echo $sambutan; ?>
  					</div>
  				</div>

  				
  				<div class="widget">
  					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-user"></i> PROFIL ADVOKAT & KONSULTAN </h4></font>
  						<div class="widget-line"></div>
  					</div>
  					 <div class="widget-box">
  					   <div id="slideshow">
        						<?php
        						$gambar ="";
      	  					$get_staff = $this->db->query("SELECT * FROM staff ORDER BY id ASC");		
      						  foreach($get_staff->result() as $h) {
      						  if(!empty($h->gambar)) {
      						    $gambar = '<img style="border:4px solid #d2d6de;float:left;height:170px;width:135px;padding:0;" src="'.base_url().'asset/images/staff/'.$h->gambar.'" />';
      						    } else {
      						    $gambar = '<img style="border:4px solid #d2d6de;float:left;height:170px;width:135px;padding:0;" src="'.base_url().'asset/images/akun/no-image.jpg" />';
      						    }
      							     echo  '<div>
      											'.$gambar.'
      							                <div class="slideshow-detail">
      							                    <p>'.$h->nama.'</p>
      							                    <p>'.$h->nip.'</p>
      							                    <p>'.$h->pangkat_golongan.'</p>
      							                    <p>'.$h->jabatan.'</p>
      							                </div>
      						                </div> ';
          						}
          						?>
					       </div>
	
  					   </div>
  				</div>
  				

  				<div class="widget">
  					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-th-list"></i> LIST BERITA TERBARU </h4></font>
  						<div class="widget-line"></div>
  					</div>
  					<div class="widget-box">
  						<ul>
							<?php echo $berita_recent; ?>
							
						</ul>
  					</div>
  				</div>

  				<div class="widget">
  					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-picture"></i> BANNER </h4></font>
  						<div class="widget-line"></div>
  					</div>
  					<div class="widget-box">
  						
  						<div style="margin:10px auto;width:300px;" id="carousel-banner" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner" role="listbox">

								<?php echo $banner; ?>
                aaa

							</div><!-- /.carousel-inner -->

							<!-- Controls -->
							<a class="left carousel-control" onclick="$(this).closest('.carousel').carousel('prev');"
							role="button" data-slide="prev">
							<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" onclick="$(this).closest('.carousel').carousel('next');"
							role="button" data-slide="next">
							<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
							</a>
						</div><!-- /.carousel -->
						
  					</div>
  				</div>

            

  				<div class="widget">
  					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-link"></i> LINK TERKAIT </h4></font>
  						<div class="widget-line"></div>
  					</div>
  					<div class="widget-box">
  						
  						<?php echo $link_terkait; ?>

  					</div>
  				</div>
              
	<!-- Widgets Content -->

	

<!--
  				<div class="widget">
  					<div class="widget-box">
  						<ul class="nav nav-tabs">
						  <li class="active"><a data-toggle="tab" href="#popular">Popular</a></li>
						  <li><a data-toggle="tab" href="#recent">Recent</a></li>
						  <li><a data-toggle="tab" href="#comments">Comments</a></li>
						</ul>

						<div class="tab-content">
						  <div id="popular" class="tab-pane fade in active">			    
						    <p>Some content.</p>
						  </div>
						  <div id="recent" class="tab-pane fade">				   
						    <p>Some content in menu 1.</p>
						  </div>
						  <div id="comments" class="tab-pane fade">					    
						    <p>Some content in menu 2.</p>
						  </div>
						</div>
  					</div>
  				</div>
-->
			</div>
			
		</div> <!--end row home -->
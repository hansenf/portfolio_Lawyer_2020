  		<div class="row"> <!--start row home -->
  			<div class="col-md-8">
  				<div id="carousel" class="carousel slide" data-ride="carousel">


					<!-- Indicators
					<ol class="carousel-indicators">
						<li data-target="#carousel" data-slide-to="0" class="active">
						</li>
						<li data-target="#carousel" data-slide-to="1"></li>
						<li data-target="#carousel" data-slide-to="2"></li>
					</ol>  -->

					<!-- Wrapper for slides -->
					<div class="carousel-inner" role="listbox">

						<?php echo $slideshow; ?>

					</div><!-- /.carousel-inner -->

					<!-- Controls -->
					<a class="left carousel-control" onclick="$(this).closest('.carousel').carousel('prev');"
					role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
					</a>
					<a class="right carousel-control" onclick="$(this).closest('.carousel').carousel('next');"
					role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
					</a>
				</div><!-- /.carousel -->


				<div class="content">
  					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-bullhorn"></i> BERITA TERBARU</h4></font>
  						<div class="widget-line"></div>
  					</div>
  					<div class="content-box">		
  						<div style="margin-bottom:20px;" class="row">
  							<?php echo $berita_col1; ?>				
						</div>
						<div style="margin-bottom:20px;" class="row">
  							<?php echo $berita_col2; ?>				
						</div>
					</div>
				</div>

				<div class="content">
					<div class="widget-title">
  						<font color="#4080ff"><h4><i class="glyphicon glyphicon-bookmark"></i> INFORMASI TERBARU</h4></font>
  						<div class="widget-line"></div>
  					</div>
  					<div class="content-box">
  						<div class="row">
  							
  							<?php echo $informasi; ?>
  							
  						</div>
  					</div>
				</div>

<!--
				<div class="content">
  					<div style="padding:50px; 0;text-align:center;">
  						<div class="row">
  							<p style="font-weight:bold;color:#e67e22;">Find US !</p>
  							<ul class="soc">
						    <li><a class="soc-twitter" href="#"></a></li>
						    <li><a class="soc-facebook" href="#"></a></li>
						    <li><a class="soc-instagram soc-icon-last" href="#"></a></li>
							</ul>
  							
  						</div>
  					</div>
				</div>		 -->		
  			</div>
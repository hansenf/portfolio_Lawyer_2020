<div class="row">
  			<div class="col-md-8">

				<div class="content">
					<div class="widget-title">
  						<h4>SEMUA INFORMASI</h4>
  						<div class="widget-line"></div>
  					</div>
  					<div class="contentdetail-box">
  						
  						<?php echo $informasi_all; ?>

  			
				</div>
  			</div>
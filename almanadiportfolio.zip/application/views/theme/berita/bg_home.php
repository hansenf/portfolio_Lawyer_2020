<div class="row">
  			<div class="col-md-8">

				<div class="content">
					<div class="widget-title">
  						<h4>SEMUA BERITA</h4>
  						<div class="widget-line"></div>
  					</div>
  					<div class="contentdetail-box">
  						
  						<?php echo $berita_all; ?>

  					
				</div>
  			</div>
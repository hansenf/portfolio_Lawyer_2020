<div class="row">
        <div class="col-md-9">
          <div class="content">  
              <div class="contentdetail-box">
                
                <?php echo $sambutan_detail; ?>

            </div>
          </div>
        </div>
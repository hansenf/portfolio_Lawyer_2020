  <div class="col-md-3">
          <div class="widget">
          	<div class="widget-title">
  						<h4>KEPALA BADAN</h4>
  						<div class="widget-line"></div>
  					</div>
            <div style="text-align:center;" class="widget-box">
              <?php echo $sambutan_poto; ?>
            </div>
          </div>
  </div>
</div>
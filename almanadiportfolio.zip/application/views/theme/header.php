<?php $get_meta = $this->db->query("SELECT nama,favicon,author,judul_web,meta_deskripsi,meta_keyword FROM about")->row(); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $get_meta->judul_web; ?></title>
     <meta name="robots" content="index, follow">

    <meta name="description" content="<?php echo $get_meta->meta_deskripsi; ?>">
    <meta name="keywords" content="<?php echo $get_meta->meta_keyword; ?>">
    <meta name="author" content="<?php echo $get_meta->author; ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/css/sweetalert.css">
    <script type="text/javascript" src="<?php echo base_url(); ?>asset/js/sweetalert.min.js"></script>
    <link href="<?php echo base_url(); ?>asset/theme/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>asset/theme/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url(); ?>asset/theme/css/animate.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>asset/theme/js/mobirise/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>asset/theme/js/mobirise-gallery/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>asset/theme/js/mobirise-slider/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>asset/theme/js/mobirise/css/mbr-additional.css" type="text/css">
    
    <link rel="shortcut icon" href="<?php echo base_url().'asset/images/banner/'.$get_meta->favicon; ?>">

  </head>
  <body>
  <?php if ($this->session->flashdata('msg_loginx')): ?>
	<script>
	swal({
	title: "Gagal Login",
	text: "<?php echo $this->session->flashdata('msg_loginx'); ?>",
	timer: 2000,
	showConfirmButton: false,
	type: 'error'
	});
	</script>
   <?php endif; ?>
    <div id="fb-root"></div>
      <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.5";
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      </script> 

  	<div class="container">
  		<div class="row">
  			<div class="col-md-12">
  				<?php echo $logo_website; ?>
  			</div>
  		</div>

  		<div class="row">
  			<div class="col-md-12">
  				<nav id="nav_bar" class="navbar navbar-default">				    
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>		    

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">

            <?php             
              echo '<li class="active"><a href="'.base_url().'">Home</a>';
              foreach ($navbar as $nav) {         
                 
                $sub_nav = nested_list2($nav['child']);
                if($sub_nav != '') {
                  echo '<li class="dropdown" ><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" href="'.$nav['url'].'">'.strtoupper($nav['nama']).'<span class="caret"></span></a>';
                } else {
                 echo '<li class=""><a href="'.$nav['url'].'">'.strtoupper($nav['nama']).'</a>';
                }                         

               if ($sub_nav != '') {
                echo '<ul class="dropdown-menu">';                       
                echo nested_list2($nav['child']);                                         
                echo '</ul>'; 
                }

                echo '</li>';
              }
            ?>
  
						</ul>

					</div><!-- /.navbar-collapse -->
				</nav>
  			</div>
  		</div>

  		<div class="row">
  			<div class="col-xs-12">
  				<div style="padding:0;" class="col-md-2">
              <div class="info-light">
              <!--ini icon rumah <i class="glyphicon glyphicon-list-alt"></i> --> INFORMASI
              </div>
            </div>
            <div style="padding:0;" class="col-md-10">
              <div class="info">
		  <marquee onmouseover="this.setAttribute('scrollamount', 0, 0);" onmouseout="this.setAttribute('scrollamount', 6, 0);"><font color="#4080ff"><b><?php echo $top_informasi; ?></b></font></marquee>

              </div>
				    </div>
  			</div>
  		</div>
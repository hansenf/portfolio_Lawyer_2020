	<?php $get_metax = $this->db->query("SELECT judul_web FROM about")->row(); ?>
	 </div>
  <div class="container nopadding">
    <div class="footer">
      <div class="row">
        <div class="col-md-3">
          <h4>Tentang Kami</h4>          
          <ul>
            <?php echo $foot_kontak; ?>
            
          </ul>
        </div>
        <div class="col-md-3">
          <h4>Map</h4>
          <?php echo $foot_map; ?>
        </div>   
        <div class="col-md-3">
            <h4>Photo</h4>
            <div class="row">
              
             <?php echo $foot_album; ?>

            </div>
        </div>
        <div class="col-md-3">
          <h4>Video</h4>
           <?php echo $foot_video; ?>
        </div> 
      </div>        
    </div>
    <div class="copyright">
      <div class="row">
        <div class="col-xs-6">
          <p class="credit">Copyright 2020 | <?php echo $get_metax->judul_web; ?></p>
        </div>
       <div style="text-align:right;" class="col-xs-6">
          <p class="credit">Developed By  <a href="http://md-solusindo.com" target="_blank"><strong>MDS</strong></a></p>
        </div>
      </div>
    </div>
  </div>
  
<?php 
$q_m = $this->db->query("SELECT * FROM popup WHERE aktif ='Y'")->row(); 
if(!empty($q_m)) { ?>
  
  <div style="margin:150px 0;" id="myModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
<?php 	
    	if(!empty($q_m->gambar)) { ?>    	
    	<img style="width:100%;" src="<?php echo base_url().'asset/images/popup/'.$q_m->gambar; ?>">
<?php } else { ?>
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><?php echo $q_m->judul; ?></h4>
      </div>
      <div class="modal-body">
        <p><?php echo $q_m->isi; ?></p>
      </div>
<?php } ?>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php } ?>


    <script src="<?php echo base_url(); ?>asset/theme/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/scripts.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/custom.js"></script>
     <script src="<?php echo base_url(); ?>asset/theme/js/smooth-scroll/SmoothScroll.js"></script>
  <script src="<?php echo base_url(); ?>asset/theme/js/masonry/masonry.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/theme/js/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/theme/js/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/mobirise/js/script.js"></script>
  	<script src="<?php echo base_url(); ?>asset/theme/js/mobirise-gallery/script.js"></script>
<script src="<?php echo base_url(); ?>asset/theme/js/slideshow.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
  
  $(window).scroll(function () {
      //if you hard code, then use console
      //.log to determine when you want the 
      //nav bar to stick.  
      console.log($(window).scrollTop())
    if ($(window).scrollTop() > 250) {
      $('#nav_bar').addClass('navbar-fixed-top container');
    }
    if ($(window).scrollTop() < 251) {
      $('#nav_bar').removeClass('navbar-fixed-top container');
    }
  });
});
  </script>
  
  <script>
    	$('#myModal').modal('show');
    </script>
    <script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}</script>
<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="glyphicon glyphicon-triangle-top"></i></button>

  </body>
</html>
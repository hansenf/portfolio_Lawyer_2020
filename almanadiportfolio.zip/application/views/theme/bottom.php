
	 <?php $get_metax = $this->db->query("SELECT judul_web FROM about")->row(); ?>
	 </div>
	 <div class="container nopadding">
	   <div class="footer">
	  		<div class="row">
	  			<div class="col-xs-6">
	  				<p style="margin:0;" class="credit">Copyright 2020 | <?php echo $get_metax->judul_web; ?></p>
	  			</div>
	  			<div class="col-xs-6">
          			<p style="text-align:right;">Developed By  <a href="#" target="_blank"><strong>MDS</strong></a></p>
        			</div>
	  		</div>
		</div>
	 </div>
    
    
    <script src="<?php echo base_url(); ?>asset/theme/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/scripts.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/custom.js"></script>
     <script src="<?php echo base_url(); ?>asset/theme/js/smooth-scroll/SmoothScroll.js"></script>
  <script src="<?php echo base_url(); ?>asset/theme/js/masonry/masonry.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/theme/js/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/theme/js/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
    <script src="<?php echo base_url(); ?>asset/theme/js/mobirise/js/script.js"></script>
  	<script src="<?php echo base_url(); ?>asset/theme/js/mobirise-gallery/script.js"></script>
<script src="<?php echo base_url(); ?>asset/theme/js/slideshow.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
  
  $(window).scroll(function () {
      //if you hard code, then use console
      //.log to determine when you want the 
      //nav bar to stick.  
      console.log($(window).scrollTop())
    if ($(window).scrollTop() > 250) {
      $('#nav_bar').addClass('navbar-fixed-top container');
    }
    if ($(window).scrollTop() < 251) {
      $('#nav_bar').removeClass('navbar-fixed-top container');
    }
  });
});
  </script>
  <script>
      $('#myModal').modal('show');
    </script>
    <script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}</script>
<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="glyphicon glyphicon-triangle-top"></i></button>
  </body>
</html>
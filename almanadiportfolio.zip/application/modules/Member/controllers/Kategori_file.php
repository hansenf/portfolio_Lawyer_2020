<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kategori_file extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('kategori_file','/');
			$d['kategori_file'] = $this->Admin_model->get_kategori_file();
			$d['judul'] = 'kategori_file';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_file/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('kategori_file',base_url().'Member/kategori_file');
			$this->breadcrumb->append_crumb('Add kategori_file','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New kategori_file';
			$d['active'] = 'active';
			$d['back'] = base_url().'Member/kategori_file';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['kategori_file'] = '';
			$this->load->view('top');	
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_file/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('kategori_file',base_url().'Member/kategori_file');
			$this->breadcrumb->append_crumb('Edit kategori_file','/');

			$where['id_kategori'] = $id_param;
			$get_id = $this->db->get_where("kategori_file",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit kategori_file';
			$d['active'] = 'active';
			$d['back'] = base_url().'Member/kategori_file';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id_kategori;
			$d['kategori_file'] = $get_id->kategori_file;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_file/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Member");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$tipe = $this->input->post("tipe");			
			$id['id_kategori'] = $this->input->post("id_param");
			$idx = $this->input->post("id_param");
			$idm['nama'] = $this->input->post("nama");	
			$in['kategori_file'] = $this->input->post('kategori_file');
			$im['nama'] = $this->input->post('kategori_file');
			$im['posisi'] = '0';
			$im['id_parent'] = '6';	
			if($tipe == "add") {	
				$get_id = $this->db->query("SELECT MAX(id_kategori) AS max FROM kategori_file")->row();
				$id_down = $get_id->max + 1;
				
						
				$im['url'] = base_url().'Web/download/detail/'.$id_down.'/'.url_title($this->input->post('kategori_file'));
				$this->db->insert("kategori_file",$in);	
				$this->db->insert("menu",$im);		
				redirect("Member/kategori_file");
			} elseif($tipe = 'edit') {
				$this->db->update("kategori_file",$in,$id);
				redirect("Member/kategori_file");
			}
		} else {
			redirect("Member");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				
				if($x != 18) {
					$get_id = $this->db->get_where("file",array('id_kategori' => $x))->row();
					$get_name = $this->db->get_where("kategori_file",array('id_kategori' => $x))->row();
					$nama_menu = $get_name->kategori_file;
					$path = "./asset/file/".$get_id->lokasi."";
					unlink($path);		
					$this->db->delete("file",array('id_kategori' => $x));
					$this->db->delete("menu",array('nama' => $nama_menu));		

					$this->db->delete("kategori_file",array('id_kategori' => $x));			
				}
				
			}
			redirect("Member/kategori_file");		
		
		} else {
			redirect("Member");
		}
	}
}

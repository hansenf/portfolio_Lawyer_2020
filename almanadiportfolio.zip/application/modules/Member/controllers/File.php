<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class file extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "user") {
			$id_param = $this->session->userdata('id');
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('file','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['perizinan'] = $this->Admin_model->get_perizinan($id_param);
			$d['judul'] = 'file';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/file/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('file',base_url().'Member/file');
			$this->breadcrumb->append_crumb('Add file','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New file';
			$d['active'] = 'active';
			$d['back'] = base_url().'Member/file';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['instansi_pemberi_izin'] = '';
			$d['nomor_izin'] = '';
                        $d['jenis_izin'] = '';
                        $d['tgl_perizinan'] = '';
			$d['thefile'] = '';
			$d['combo_jenis_izin'] = $this->Admin_model_detail->get_combo_jenis_izin();


			 $this->load->view('top');
 			$this->load->view('menu',$d);
			$this->load->view('module/file/bg_input');
			$this->load->view('bottom');
		}
		else {
			 redirect("Member");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('file',base_url().'Member/file');
			$this->breadcrumb->append_crumb('Edit file','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("perizinan",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit file';
			$d['active'] = 'active';
			$d['back'] = base_url().'Member/file';
			$d['tipe'] = 'edit';
			$d['nomor_izin'] = $get_id->nomor_izin;
			$d['id_param'] = $get_id->id;
			$d['instansi_pemberi_izin'] = $get_id->instansi_pemberi_izin;
			$d['jenis_izin'] = $get_id->id_jenis_izin;
                        $d['tgl_perizinan'] = $get_id->tgl_perizinan;
			$d['thefile'] = $get_id->lokasi;
			$d['combo_jenis_izin'] = $this->Admin_model_detail->get_combo_jenis_izin($d['jenis_izin']);
			
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/file/bg_input',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Member");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/file/';				
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;		
				$config['allowed_types']= '*';	
$config['max_size'] = '0';	
			

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("file_upload")) {
					$data	 	= $this->upload->data();
					

					$in['lokasi'] = $data['file_name'];
					$in['id_jenis_izin'] = $this->input->post("jenis_izin");
					$in['instansi_pemberi_izin'] = $this->input->post("instansi_pemberi_izin");
					$in['tgl_perizinan'] = $this->input->post("tgl_perizinan");
                                
					$in['nomor_izin'] = $this->input->post("nomor_izin");
                                        $in['id_user'] = $this->session->userdata('id');		
					
					
					$this->db->insert("perizinan",$in);
					redirect("Member/file");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {			
				$in['id_jenis_izin'] = $this->input->post("jenis_izin");
				$in['instansi_pemberi_izin'] = $this->input->post("instansi_pemberi_izin");
				$in['tgl_perizinan'] = $this->input->post("tgl_perizinan");
				$in['nomor_izin'] = $this->input->post("nomor_izin");
                            
				
				if(empty($_FILES['file_upload']['name'])) {
					$this->db->update("perizinan",$in,$id);
					redirect("Member/file");
				} else {
					$config['upload_path'] = './asset/file/';				
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;		
					$config['allowed_types']= '*';		

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("file_upload")) {
					$data	 	= $this->upload->data();
					

					$in['lokasi'] = $data['file_name'];

					$this->db->update("perizinan",$in,$id);
					$old_thumb	= "./asset/file/".$this->input->post("thefile")."" ;
					@unlink($old_thumb);
					
					redirect("Member/file");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			}
			}
		}else {
			redirect("Member");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("perizinan",array('id' => $x))->row();
				$path = "./asset/file/".$get_id->lokasi."";
				@unlink($path);		
				$this->db->delete("perizinan",array('id' => $x));				
			}
			redirect("Member/file");			
		}else {
			redirect("Member");
		}
	}

	public function download($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$get_file = $this->db->get_where("perizinan",array("id"=>$id_param))->row();
			$nama = $get_file->lokasi;
			$file = base_url()."asset/file/".$nama;
			$data = file_get_contents($file);
			force_download($nama,$data);
		}else {
			redirect("Member");
		}
	}
}

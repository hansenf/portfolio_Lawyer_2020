<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class dashboard extends CI_Controller {

	 
	function index()
	{
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "user")
		{
			$d['judul'] = 'Dashboard';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/dashboard/bg_home');
			$this->load->view('bottom');
		}
		else
		{
			redirect("Xyzpb");
		}
	}

        public function download($id_param) {
		$get_status = $this->db->get_where("filep",array("id_filep"=>$id_param))->row();
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user" && $this->session->userdata('id') == $get_status->id) {			
			$nama = $get_status->lokasi;
			$status = base_url()."asset/file/".$nama;
			$data = file_get_contents($status);
			force_download($nama,$data);
		} else {
			redirect("Member");			
		}
	}
}

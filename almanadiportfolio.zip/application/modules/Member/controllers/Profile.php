<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class profile extends MX_Controller {
	 

	public function index() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('Profile',base_url().'Member/profile');
			$this->breadcrumb->append_crumb('Detail Profile','/');

			$id_param = $this->session->userdata('id');
			$d['my_profile'] = $this->Admin_model->get_user_by_id($id_param);
			$d['judul'] = 'My Profile';

			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/profile/bg_detail');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}

	public function edit($id_param) {
		$where['id'] = $id_param;
		$get_id = $this->db->get_where("user",$where)->row();
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('id') == $get_id->id && $this->session->userdata('level') == "user" ) {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('Profile',base_url().'Member/profile');
			$this->breadcrumb->append_crumb('Edit Profile','/');

			
			$d['judul'] = 'Edit Profile';
			$d['active'] = 'active';
			$d['back'] = base_url().'Member/profile';
			$d['id_param'] = $get_id->id;
			$d['nama_perusahaan'] = $get_id->nama_perusahaan;
			$d['alamat_perusahaan'] = $get_id->alamat_perusahaan;
			$d['telpon_perusahaan'] = $get_id->telpon_perusahaan;
			$d['nama_pj'] = $get_id->nama_pj;
			$d['jabatan'] = $get_id->jabatan;
			$d['telpon_pj'] = $get_id->telpon_pj;
			$d['jenis_kegiatan'] = $get_id->jenis_kegiatan;
			$d['lokasi_kegiatan'] = $get_id->lokasi_kegiatan;
			$d['kordinat_kegiatan'] = $get_id->kordinat_kegiatan;
			$d['luas_kegiatan'] = $get_id->luas_kegiatan;
			$d['telpon_lokasi'] = $get_id->telpon_lokasi;
			$d['username'] = $get_id->username;
			$d['password'] = $get_id->password;					
			$d['gambar'] = $get_id->gambar;	
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/profile/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Member");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "") {			
			$id['id'] = $this->input->post("id_param");
			$in['password'] = base64_encode($this->input->post("password"));	
			$in['username'] = $this->input->post("username");
			$in['nama_perusahaan'] = $this->input->post("nama_perusahaan");
			$in['alamat_perusahaan'] = $this->input->post("alamat_perusahaan");
			$in['telpon_perusahaan'] = $this->input->post("telpon_perusahaan");
			$in['nama_pj'] = $this->input->post("nama_pj");
			$in['jabatan'] = $this->input->post("jabatan");
			$in['telpon_pj'] = $this->input->post("telpon_pj");
			$in['jenis_kegiatan'] = $this->input->post("jenis_kegiatan");
			$in['lokasi_kegiatan'] = $this->input->post("lokasi_kegiatan");
			$in['kordinat_kegiatan'] = $this->input->post("kordinat_kegiatan");
			$in['luas_kegiatan'] = $this->input->post("luas_kegiatan");
			$in['telpon_lokasi'] = $this->input->post("telpon_lokasi");
			
							
				if(empty($_FILES['gambar_user']['name'])) {
					$this->db->update("user",$in,$id);
					redirect("Member/profile");
				} else {
					$config['upload_path'] = './asset/images/akun/';
					$config['allowed_types']= '*';
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;	
					$config['max_size']     = '0';
					$config['max_width']  	= '30000';
					$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_user")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];

					$this->db->update("user",$in,$id);
					$old_thumb	= "./asset/images/akun/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Member/Profile");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			}
			
		} else {
			redirect("Member");
		}
	}
	
	public function download($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$get_upload = $this->db->get_where("user",array("id"=>$id_param))->row();
			$nama = $get_upload->surat_izin;
			$upload = base_url()."asset/images/akun/".$nama;
			$data = file_get_contents($upload);
			force_download($nama,$data);
		}
	}

}

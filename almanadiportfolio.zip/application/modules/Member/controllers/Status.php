<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class status extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "user") {
			$id = $this->session->userdata('id');
			$in['baca'] = '1';
			$this->db->update("upload",$in,array("id_user"=>$id));	
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member/status');
			$this->breadcrumb->append_crumb('Status','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['status'] = $this->Admin_model->get_upload_by_id($id);
			$d['judul'] = 'Status Upload';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/status/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}

	
	public function download($id_param) {
		$get_status = $this->db->get_where("upload_detail",array("id_upload_detail"=>$id_param))->row();
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user" && $this->session->userdata('id') == $get_status->id_user) {			
			$nama = $get_status->file;
			$status = base_url()."asset/upload/".$nama;
			$data = file_get_contents($status);
			force_download($nama,$data);
		} else {
			redirect("Member");			
		}
	}
}

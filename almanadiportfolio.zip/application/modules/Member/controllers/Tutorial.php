<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class tutorial extends CI_Controller {

	 
	function index()
	{
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "user")
		{
			$d['judul'] = 'Tutorial Penggunaan Web Pelaporan';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/tutorial/bg_view');
			$this->load->view('bottom');
		}
		else
		{
			redirect("Member");
		}
	}
 
}

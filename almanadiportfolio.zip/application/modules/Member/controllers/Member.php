<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

	public function index() {
		if($this->session->userdata('logged_in') == "" || $this->session->userdata('level') != "user") {
			$this->load->view('login-u.php');
		} else {			
			redirect('Member/dashboard');
		}
	}

	public function login() {
		$d['username'] = $this->input->post("username");
		$d['password'] = $this->input->post("password");

		$this->Login_m->cekLoginUser($d);
	}

	public function logout() {
		$this->session->sess_destroy();
		redirect(base_url());
	}
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class upload extends MX_Controller {
	 
	
	public function index() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('Upload',base_url().'Member/upload');
			$this->breadcrumb->append_crumb('Add Upload','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New Upload';
			$d['active'] = 'active';
			$d['back'] = base_url().'User/upload';
			$d['tipe'] = 'add';
                        $d['id_param'] = '';
                        $d['nama'] = '';
			$d['thefile'] = '';
		        $d['jenis_izin'] = '';
		        $d['semester'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/upload/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}
        


        public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('Upload',base_url().'Member/upload');
			$this->breadcrumb->append_crumb('Add Upload','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New Upload';
			$d['active'] = 'active';
			$d['back'] = base_url().'User/upload';
			$d['tipe'] = 'add';
                        $d['id_param'] = '';
                        $d['nama'] = '';
			$d['thefile'] = '';
			$d['semester'] = '';
			 $d['jenis_izin'] = '';			
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/upload/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}
	
	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Member');
			$this->breadcrumb->append_crumb('Upload',base_url().'Member/upload');
			$this->breadcrumb->append_crumb('Add Upload','/');
			
			$where['id'] = $id_param;
			$get_id = $this->db->get_where("upload",$where)->row();
			
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit Upload';
			$d['active'] = 'active';
			$d['back'] = base_url().'User/upload';
			$d['tipe'] = 'edit';
                        $d['id_param'] = $get_id->id;
                        $d['nama'] = $get_id->nama;
                        $d['jenis_izin'] = $get_id->jenis_izin;
                        $d['semester'] = $get_id->semester;
			$d['thefile'] = $get_id->file;			
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/upload/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Member");
		}
	}



	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "user") {
			$tipe = $this->input->post("tipe");
                       $id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/upload/';				
				$config['encrypt_name']	= FALSE;
				$config['remove_spaces']	= TRUE;		
				$config['allowed_types']= '*';	
				$config['max_size'] = '0';	
				$config['overwrite']     = FALSE;
				
				
			

				$this->load->library('upload');
				
				$files = $_FILES;
				$cpt = count($_FILES['upload_upload']['name']);
				
				$idx['id'] = $this->session->userdata('id');
				$iny['tgl_tempo'] = '1';
				$this->db->update("user",$iny,$idx);
				
				
				$in['nama_perusahaan'] = $this->session->userdata('nama_perusahaan');
				$in['id_user'] = $this->session->userdata('id');
				$in['nama'] = $this->input->post("nama");
				$in['jenis_izin'] = $this->input->post("jenis_izin");
				$in['semester'] = $this->input->post("semester");
				$in['status'] = 'Proses';
				$in['keterangan'] = '-';
				$in['tgl_upload'] = date('Y-m-d');			
						
				$this->db->insert("upload",$in);				
				
												
				$inx['id'] = $this->db->insert_id();	
				
				for($i=0; $i<$cpt; $i++) {         
				
					$_FILES['upload_upload']['name']= time().'-'.$files["upload_upload"]['name'][$i];
				        $_FILES['upload_upload']['type']= $files['upload_upload']['type'][$i];
				        $_FILES['upload_upload']['tmp_name']= $files['upload_upload']['tmp_name'][$i];
				        $_FILES['upload_upload']['error']= $files['upload_upload']['error'][$i];
				        $_FILES['upload_upload']['size']= $files['upload_upload']['size'][$i];    
				
				        $this->upload->initialize($config);
				        
				        if($this->upload->do_upload('upload_upload')) {	
				        			       	
					        //echo time().'-'.$files["upload_upload"]['name'][$i];
					        $inx['id_user'] = $this->session->userdata('id');
					        $inx['file'] = time().'-'.$files["upload_upload"]['name'][$i];			
						$this->db->insert("upload_detail",$inx);
					} else {
						echo $this->upload->display_errors('<p>','</p>');
					}				           
				       
				}	
				redirect("Member/status");
			} elseif($tipe = 'edit') {			
				$config['upload_path'] = './asset/upload/';				
				$config['encrypt_name']	= FALSE;
				$config['remove_spaces']	= TRUE;		
				$config['allowed_types']= '*';	
				$config['max_size'] = '0';	
				$config['overwrite']     = FALSE;
				
				
			

				$this->load->library('upload');
				
				$files = $_FILES;
				$cpt = count($_FILES['upload_upload']['name']);
				
				$idx['id'] = $this->session->userdata('id');
				$iny['tgl_tempo'] = '1';
				$this->db->update("user",$iny,$idx);
				
				
				$in['nama_perusahaan'] = $this->session->userdata('nama_perusahaan');
				$in['id_user'] = $this->session->userdata('id');
				$in['nama'] = $this->input->post("nama");
				$in['jenis_izin'] = $this->input->post("jenis_izin");
				$in['semester'] = $this->input->post("semester");
				$in['status'] = 'Proses';
				$in['keterangan'] = '-';
				$in['tgl_upload'] = date('Y-m-d');			
						
				$this->db->update("upload",$in,$id);				
				
												
				$inx['id'] = $this->input->post("id_param");
				
				$get_idud = $this->db->get_where("upload_detail",$inx);					
				foreach($get_idud ->result_array() as $y) {
					$path = "./asset/upload/".$y['file']."";
					unlink($path);
						//echo $y['file'];	
				}						
				$this->db->delete("upload_detail",$inx);	
				
				for($i=0; $i<$cpt; $i++) {         
				
					$_FILES['upload_upload']['name']= time().'-'.$files["upload_upload"]['name'][$i];
				        $_FILES['upload_upload']['type']= $files['upload_upload']['type'][$i];
				        $_FILES['upload_upload']['tmp_name']= $files['upload_upload']['tmp_name'][$i];
				        $_FILES['upload_upload']['error']= $files['upload_upload']['error'][$i];
				        $_FILES['upload_upload']['size']= $files['upload_upload']['size'][$i];    
				
				        $this->upload->initialize($config);
				        
				        if($this->upload->do_upload('upload_upload')) {	
				        			       	
					        //echo time().'-'.$files["upload_upload"]['name'][$i];
					        $inx['id_user'] = $this->session->userdata('id');
					        $inx['file'] = time().'-'.$files["upload_upload"]['name'][$i];			
						$this->db->insert("upload_detail",$inx);
					} else {
						echo $this->upload->display_errors('<p>','</p>');
					}				           
				       
				}	
				redirect("Member/status");
			}

		}
	}

}

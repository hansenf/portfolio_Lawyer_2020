<?php 
$id = $this->session->userdata('id');
$get_author = $this->db->query("SELECT * FROM user WHERE id = '$id'")->row(); 
?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
     <div class="user-panel">
            <div class="pull-left image">
              <?php 
                    if(!empty($get_author->gambar)) {
                    echo '<img class="img-circle" src="'.base_url().'asset/images/akun/'.$get_author->gambar.'">';      
                    } else {
                    echo '<img class="img-circle" src="'.base_url().'asset/images/akun/userakun.jpg">';
                    }            
                ?>
            </div>
            <div class="pull-left info">
              <p><?php echo $get_author->nama_pj; ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
     </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="treeview"><a href="<?php echo base_url(); ?>" target="_blank">
          <i class="glyphicon glyphicon-globe"></i>
          <span>VIEW WEBSITE</span>          
        </a> 
      </li>
      <li class="header">MAIN NAVIGATION</li>
      <li class="active treeview">
        <a href="<?php echo base_url(); ?>Member/dashboard">
          <i class="fa fa-dashboard"></i> <span>DASHBOARD</span>
        </a>
      </li>
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Member/profile">
          <i class="fa fa-user"></i> <span>MY PROFILE</span>
        </a>
      </li>

      <li class="treeview">
        <a href="<?php echo base_url(); ?>Member/file">
          <i class="fa fa-clone"></i>
          <span>PERIZINAN</span>
        </a> 
      </li>     
       <li class="treeview">
        <a href="<?php echo base_url(); ?>Member/status">
          <i class="fa fa-bullhorn"></i> <span>PELAPORAN</span>
          <small class="label pull-right bg-red">
            <?php 
              $q = $this->db->query("SELECT count(baca) AS count_baca FROM upload WHERE id_user = '$id' AND baca='0'")->row();
              echo $q->count_baca;
            ?>
          </small>
        </a>
      </li>     
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Member/upload/add">
          <i class="fa fa-upload"></i> <span>UPLOAD PELAPORAN</span>
        </a>
      </li>    
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo $judul; ?>
    </h1>
    <?php   echo $this->breadcrumb->output(); ?>
  </section>
  <section class="content">
    <div class="row">

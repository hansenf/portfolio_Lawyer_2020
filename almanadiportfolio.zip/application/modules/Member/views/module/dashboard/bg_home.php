	<div class="col-md-12">
	    <?php
	    	$id_member = $this->session->userdata('id');
	    	//$peringatan = $this->db->query("SELECT * FROM upload WHERE id_user = '$id_member' AND status='Proses' OR status='Direvisi' ORDER BY id DESC")->row();
	    	$member = $this->db->query("SELECT tgl_tempo,jenis_izin_pelaporan,keterangan FROM user WHERE id = '$id_member'")->row();
	    	
	    	$file= $this->db->query("SELECT * FROM filep WHERE id = '$id_member'")->row();
		
		if($member->tgl_tempo != "0" && $member->tgl_tempo != "1") {
		       	$date1 = $member->tgl_tempo;
		       	$date2 = date('Y-m-d');
		    	$selisih = (((strtotime ($date1) - strtotime ($date2)))/(60*60*24));
		    	if($selisih < 0) {
		    	echo '<div style="text-align:center;" class="alert alert-danger" role="alert"><h3>Batas Pengiriman Data '.$member->jenis_izin_pelaporan.' , Telah Lewat.</h3> <h3><strong>Segera lakukan pengiriman data</strong></h3></div>';
			echo '<div class="col-md-8 col-md-offset-2"><div style="text-align:center;" class="alert alert-warning" role="alert"><h4>'.$file->keterangan.'</h4><p><a href="'.base_url().'Member/dashboard/download/'.$file->id_filep.'">Download</a></p></div></div>';
		    	} else {
		    	echo '<div style="text-align:center;" class="alert alert-danger" role="alert"><h3>Batas Pengiriman Data '.$member->jenis_izin_pelaporan.' , adalah <strong>'.$selisih.'</strong>  Hari Lagi</h3></div>';
		    	echo '<div class="col-md-8 col-md-offset-2"><div style="text-align:center;" class="alert alert-warning" role="alert"><h4>'.$member->keterangan.'</h4></div></div>';
		    	}
	    	} else if($member->tgl_tempo == "1") {
                     echo '<div style="text-align:center;" class="alert alert-warning" role="alert"><h3>Pengiriman Berkas Berhasil. Berkas Pelaporan Data Sedang diperiksa oleh admin</h3></div>';
                }
	    	
	    ?>
	</div>    


    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3>My Profile</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-user"></i>
        </div>
        <a href="<?php echo base_url(); ?>Member/profile" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
<div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-purple">
        <div class="inner">
          <h3>Perizinan</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-clone"></i>
        </div>
        <a href="<?php echo base_url(); ?>Member/file" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
          <h3>Pelaporan</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-newspaper-o"></i>
        </div>
        <a href="<?php echo base_url(); ?>Member/status" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3>Kirim Data</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-plus"></i>
        </div>
        <a href="<?php echo base_url(); ?>Member/upload" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->  
   
   
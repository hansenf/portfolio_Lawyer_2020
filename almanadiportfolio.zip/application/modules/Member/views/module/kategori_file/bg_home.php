<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Member/kategori_file/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <a style="margin-left:0;" class="btn btn-app" href="<?php echo base_url().'Member/kategori_file/add'; ?>"><i class="fa fa-plus-square"></i> New</a>
      <button class="btn btn-app"><i class="fa fa-trash"></i>Delete</button>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>Kategori</th>  
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($kategori_file->result_array() as $data) { ?>
          <?php if($data['id_kategori'] != 18) { ?>
          <tr>            
            <td class="ceklist"><input type="checkbox" name="id[]" id="selectAll" value="<?php echo $data['id_kategori']; ?>"/></td>
            <td><?php echo $data['kategori_file']; ?></td>
            <td style="text-align:center;"><a href="<?php echo base_url().'Member/kategori_file/edit/'.$data['id_kategori']; ?>"><i class="glyphicon glyphicon-edit"></i></a></td>
          </tr>
          <?php } ?>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
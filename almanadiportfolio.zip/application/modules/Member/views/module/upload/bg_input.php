<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Member/upload/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <input type="hidden" name="thefile" value="<?php echo $thefile; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="jenis_izin">Jenis Izin</label>
          <select style="width: 60%;" class="form-control" name="jenis_izin"required>
          	<option value="">Pilih Jenis Izin</option>
          	<option value="Izin Lingkungan" <?php if($jenis_izin == 'Izin Lingkungan') { echo 'selected'; } ?>>Izin Lingkungan</option>
          	<option value="Izin Pembuangan Limbah Cair" <?php if($jenis_izin == 'Izin Pembuangan Limbah Cair') { echo 'selected'; } ?>>Izin Pembuangan Limbah Cair</option>
          	<option value="Izin Penyimpanan Sementara Limbah B3" <?php if($jenis_izin == 'Izin Penyimpanan Sementara Limbah B3') { echo 'selected'; } ?>>Izin Penyimpanan Sementara Limbah B3</option>
          </select>
        </div>
        <div class="form-group">
          <label for="semeseter">Periode Laporan</label>
          <select style="width: 60%;" class="form-control" name="semester" required>
          	<option value="">Pilih Periode Laporan</option>
          	<option value="Semester 1" <?php if($semester == 'Semester 1') { echo 'selected'; } ?>>Semester 1</option>
          	<option value="Semester 2" <?php if($semester == 'Semester 2') { echo 'selected'; } ?>>Semester 2</option>
                <option value="Triwulan 1" <?php if($semester == 'Triwulan 1') { echo 'selected'; } ?>>Triwulan 1</option>
          	<option value="Triwulan 2" <?php if($semester == 'Triwulan 2') { echo 'selected'; } ?>>Triwulan 2</option>
                <option value="Triwulan 3" <?php if($semester == 'Triwulan 3') { echo 'selected'; } ?>>Triwulan 3</option>
          	<option value="Triwulan 4" <?php if($semester == 'Triwulan 4') { echo 'selected'; } ?>>Triwulan 4</option>
          </select>
        </div>
       <div class="form-group">
          <label for="nama">Nama File</label>
          <input style="width: 60%;" type="text" class="form-control" id="nama" name="nama" placeholder="Ketikan nama file"  value="<?php echo $nama; ?>" required>
        </div>  
        <div class="form-group">
          <label for="status_upload">File Upload</label>
          <input type="file" id="upload_upload" name="upload_upload[]" multiple>
          <p style="color:red">Upload Lebih Dari Satu , gunakan tombol <strong>CTRL</strong> pada keyboard</p>
          <p style="color:red">Pastikan Koneksi Internet Stabil Pada Saat Upload Data</p>
        </div>  
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
<div class="col-xs-12">
  <div class="box">      
    <div class="box-header with-border">
      <a style="margin-left:0;" class="btn btn-app" href="<?php echo base_url().'Member/upload'; ?>"><i class="fa fa-plus-square"></i> New</a>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>No</th>
            <th>Jenis Izin</th>
            <th>Nama File</th>
            <th>Semester</th>
            <th>Tgl Upload</th>
            <th>Status</th>    
            <th>Keterangan</th>
            <th>Revisi</th>
            <th>Download</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($status->result_array() as $data) { ?>
          <tr>
           <td><?php echo $no++; ?></td>
            <td><?php echo $data['jenis_izin']; ?></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['semester']; ?></td>
            <td><?php echo $data['tgl_upload']; ?></td>
             <td style="text-align:center;">
                <?php 
                  if($data['status'] == 'Diterima') { 
                    echo '<small class="label bg-green">'.$data['status'].'</small>';
                  } elseif($data['status'] == 'Revisi') {
                    echo '<small class="label bg-red">'.$data['status'].'</small>';
                  } else {
                    echo '<small class="label bg-blue">'.$data['status'].'</small>';
                  }
                ?>       
           </td>
            <td><?php echo $data['keterangan']; ?></td>
            <td style="text-align:center;">
<?php if($data['status'] == 'Revisi') { ?>
	       <a href="<?php echo base_url().'Member/upload/edit/'.$data['id']; ?>"><i class="glyphicon glyphicon-edit"> </i> Revisi</a> 
<?php	} else { echo 'revisi belum ada'; } ?>              
            </td>
            <td><?php
           	$x = 1;
           	$get_download = $this->db->query("SELECT * FROM upload_detail WHERE id = '$data[id]'");
           	foreach($get_download ->result_array() as $datax) { ?>
              		<a href="<?php echo base_url().'Member/status/download/'.$datax['id_upload_detail']; ?>" target="_blank"><i class="glyphicon glyphicon-download-alt"> </i> Download File <?php echo $x++; ?></a></br>
          <?php	} ?>
           </td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
  </div><!-- /.box -->
</div>
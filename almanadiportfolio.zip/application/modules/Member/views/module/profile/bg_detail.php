<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
    </div><!-- /.box-header -->
      <div class="box-body">
       
<?php foreach($my_profile->result_array() as $data) { 
      $edit = '<a style="margin-top:10px;width:100%;" href="'.base_url().'Member/profile/edit/'.$data['id'].'" class="btn btn-danger">Edit</a>
';
      if(!empty($data['gambar'])) {
      $gambar = '<img style="height:220px;width:100%;" src="'.base_url().'asset/images/akun/'.$data['gambar'].'">';
      } else {
      $gambar = '<img style="height:220px;width:100%;" src="'.base_url().'asset/images/akun/userakun.jpg">';
      }

      $nama_perusahaan = '<td>'.$data['nama_perusahaan'].'</td>';
      $alamat_perusahaan = '<td>'.$data['alamat_perusahaan'].'</td>';  
      $telpon_perusahaan = '<td>'.$data['telpon_perusahaan'].'</td>';  
      $nama_pj = '<td>'.$data['nama_pj'].'<td>';
      $jabatan = '<td>'.$data['jabatan'].'<td>';
      $telpon_pj = '<td>'.$data['telpon_pj'].'<td>';
      $jenis_kegiatan = '<td>'.$data['jenis_kegiatan'].'<td>';
      $lokasi_kegiatan = '<td>'.$data['lokasi_kegiatan'].'<td>';
      $kordinat_kegiatan = '<td>'.$data['kordinat_kegiatan'].'<td>';
      $luas_kegiatan = '<td>'.$data['luas_kegiatan'].'<td>';
      $telpon_lokasi = '<td>'.$data['telpon_lokasi'].'<td>';

      $username= '<td>'.$data['username'].'</td>'; 
      $password= '<td>'.base64_decode($data['password']).'</td>';
      
      } 

echo    '<div class="col-md-2">
          '.$gambar.'
          '.$edit.'
        </div>
        <div class="col-md-10">
          <table class="table table-bordered">
            <tbody>
              <tr>
                <td style="width:30%;">Nama Perusahaan</td>'.$nama_perusahaan.'
              </tr>
              <tr>
                <td style="width:30%;">Alamat Perusahaan</td>'.$alamat_perusahaan.'
              </tr>
              <tr>
                <td style="width:30%;">Telpon Perusahaan</td>'.$telpon_perusahaan.'
              </tr>
              <tr>
                <td style="width:30%;">Nama Penganggung Jawab</td>'.$nama_pj.'
              </tr>
              <tr>
                <td style="width:30%;">Jabatan</td>'.$jabatan.'
              </tr>
              <tr>
                <td style="width:30%;">No Telpon/Hp Penanggung Jawab</td>'.$telpon_pj.'
              </tr>
              <tr>
                <td style="width:30%;">Jenis Kegiatan</td>'.$jenis_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">Lokasi Kegiatan</td>'.$lokasi_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">Kordinat Kegiatan</td>'.$kordinat_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">Luas Kegiatan</td>'.$luas_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">No Telpon Lokasi Kegiatan</td>'.$telpon_lokasi.'
              </tr>
              <tr>
                <td style="width:30%;">Username</td>'.$username.'
              </tr> 
              <tr>
                <td style="width:30%;">Password</td>'.$password.'
              </tr>                              
            </tbody>         
        </table>
      </div>';
?>

      </div><!-- /.box-body -->
      <div class="box-footer">
      </div>
  </div><!-- /.box -->
</div>
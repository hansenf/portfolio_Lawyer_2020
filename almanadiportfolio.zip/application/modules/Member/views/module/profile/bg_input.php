<div class="col-md-8 col-md-offset-2">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Member/profile/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
      <div class="box-body"> 
      	  <div class="form-group">
            <label>Nama Perusahaan</label>
            <input type="text" class="form-control" name="nama_perusahaan" value="<?php echo $nama_perusahaan; ?>">
          </div>   
          <div class="form-group">
            <label>Alamat Perusahaan</label>
            <input type="text" class="form-control" name="alamat_perusahaan" value="<?php echo $alamat_perusahaan; ?>">
          </div>
          <div class="form-group">
            <label>No Telpon Perusahaan</label>
            <input type="text" class="form-control" name="telpon_perusahaan" value="<?php echo $telpon_perusahaan; ?>">
          </div>    
          <div class="form-group">
            <label>Nama Penganggung Jawab</label>
            <input type="text" class="form-control" name="nama_pj" value="<?php echo $nama_pj; ?>">
          </div>
          <div class="form-group">
            <label>Jabatan</label>
            <input type="text" class="form-control" name="jabatan" value="<?php echo $jabatan; ?>">
          </div>          
          <div class="form-group">
            <label>No Telpon/Hp Penganggung Jawab</label>
            <input type="text" class="form-control" name="telpon_pj" value="<?php echo $telpon_pj; ?>">
          </div>
          <div class="form-group">
            <label>Jenis Kegiatan</label>
            <input type="text" class="form-control" name="jenis_kegiatan" value="<?php echo $jenis_kegiatan; ?>">
          </div>
          <div class="form-group">
            <label>Lokasi Kegiatan</label>
            <input type="text" class="form-control" name="lokasi_kegiatan" value="<?php echo $lokasi_kegiatan; ?>">
          </div>
          <div class="form-group">
            <label>Kordinat Lokasi Kegiatan</label>
            <input type="text" class="form-control" name="kordinat_kegiatan" value="<?php echo $kordinat_kegiatan; ?>">
          </div>
          <div class="form-group">
            <label>Luas Kegiatan</label>
            <input type="text" class="form-control" name="luas_kegiatan" value="<?php echo $luas_kegiatan; ?>">
          </div>
          <div class="form-group">
            <label>No Telpon Lokasi Kegiatan</label>
            <input type="text" class="form-control" name="telpon_lokasi" value="<?php echo $telpon_lokasi; ?>">
          </div>

          <div class="form-group">
            <label>Username</label>
            <input type="text" class="form-control" name="username" value="<?php echo $username; ?>">
          </div>             
          <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password" value="<?php echo base64_decode($password); ?>">
          </div> 
           <?php if($gambar != "") { ?>  
          <div class="form-group">
            <img style="height:120px;width:100px;" src="<?php echo base_url().'asset/images/akun/'.$gambar; ?>">
          </div>   
      <?php } ?>
          <div class="form-group">
            <label>Foto Anda</label>
            <input type="file" id="gambar_user" name="gambar_user">
          </div>        
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
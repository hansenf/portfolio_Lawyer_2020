<div class="col-md-12">

<object data="<?php echo base_url().'asset/Member.pdf'; ?>" type="application/pdf" width="100%" height="800">
      <!-- support older browsers -->
      <embed src="<?php echo base_url().'asset/Member.pdf'; ?>" type="application/pdf" width="100%" height="800"/>
      <p>Panduan Penggunaan Web Pelaporan Member </p>
</object> 

</div>
<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Member/file/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <input type="hidden" name="thefile" value="<?php echo $thefile; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="kategori">Jenis Izin</label>
            <?php echo $combo_jenis_izin; ?>              
        </div>
        <div class="form-group">
          <label>Nomor Izin</label>
          <input style="width: 60%;" type="text" class="form-control" name="nomor_izin" placeholder="Ketikan Nomor Izin" value="<?php echo $nomor_izin; ?>" required>
        </div>  
        <div class="form-group">
          <label>Instansi Pemberi Izin</label>
          <input style="width: 60%;" type="text" class="form-control" name="instansi_pemberi_izin" placeholder="Ketikan Instansi Pemberi Izin" value="<?php echo $instansi_pemberi_izin; ?>" required>
        </div>         
        <div class="form-group">
          <label>Tanggal Perizinan</label>
          <input style="width: 60%;" type="text" class="form-control" id="tgl_perizinan" name="tgl_perizinan" placeholder="Ketikan Tanggal Perizinan" value="<?php echo $tgl_perizinan; ?>" required>
        </div>
        <div class="form-group">
          <label for="file_upload">File Upload</label>
          <input type="file" id="file_upload" name="file_upload">
        </div>  
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
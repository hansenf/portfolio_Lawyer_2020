  </section>
  </div>
  </div>
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <strong>Developed By <a href="md-solusindo.com">MDS</a></strong>
        </div>
        <strong>Copyright &copy; 2020 <a href="#">Law Firm Alman Adi</a></strong>
      </footer>
     
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url(); ?>asset/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo base_url(); ?>asset/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url(); ?>asset/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="<?php echo base_url(); ?>asset/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- Morris.js charts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="<?php echo base_url(); ?>asset/plugins/morris/morris.min.js"></script>
    <!-- Sparkline -->
    <script src="<?php echo base_url(); ?>asset/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!-- jvectormap -->
    <script src="<?php echo base_url(); ?>asset/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="<?php echo base_url(); ?>asset/plugins/knob/jquery.knob.js"></script>
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>asset/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="<?php echo base_url(); ?>asset/plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- CK Editor -->
    <script src="<?php echo base_url(); ?>asset/plugins/ckeditor/ckeditor.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="<?php echo base_url(); ?>asset/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="<?php echo base_url(); ?>asset/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>asset/plugins/fastclick/fastclick.min.js"></script>  
    <!-- AdminLTE App --> 
    <script src="<?php echo base_url(); ?>asset/js/app.min.js"></script>

    <script src="<?php echo base_url(); ?>asset/jquery-nestable/jquery.nestable.js"></script>

    <script type="text/javascript">
      $(document).ready(function() {
          var result;
          var updateOutput = function(e) {
              var list   = e.length ? e : $(e.target),
                  output = list.data('output');
              if (window.JSON) {
                  result = window.JSON.stringify(list.nestable('serialize'));
              }
          };
          $('#nestable').nestable().on('change', updateOutput);
          $('#save-form').click(function() {
          $.post("<?php echo base_url(); ?>Xyzpb/menu/save_position", {"page":result}, function(response) {
            alert('Data sudah tersimpan!');           
            
         });
        });
    
      });
      </script>
<script>
	$('#tgl').datepicker();
</script>

    <script>
      $(function () {
        $('#data-table').DataTable({
          "paging": true,
          "lengthChange": true,
          "searching": true,
          "ordering": true,
          "info": false,
          "autoWidth": false
        });
      });
    </script>
    <script>
      $('#reservation').daterangepicker();
    </script>
    <script>
      $('#selectAll').click(function(event) {   
          if(this.checked) {
              $(':checkbox').each(function() {
                  this.checked = true;                        
              });
          }
          else {
             $(':checkbox').each(function() {
                  this.checked = false;                        
              });
          }
        });
    </script>

    <script>
      $(function () {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.config.extraPlugins = 'justify';
        CKEDITOR.replace('isi',{          
          filebrowserBrowseUrl : '<?php echo base_url(); ?>asset/plugins/kcfinder/browse.php', 
          height:"300", width:"1000",
        });
        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
       
      });
    </script>

    
  </body>
</html>

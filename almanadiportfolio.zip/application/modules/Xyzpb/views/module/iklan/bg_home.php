<div class="col-xs-12">
  <div class="box box-success">
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="module/mod_gallery/aksi-gallery.php?act=delete" method="post"> 
    <div class="box-header with-border">
      <div style="padding:0;" class="col-xs-2">
        <a class="btn btn-block btn-primary" href="admin.php?module=Tambah-Gallery"><i style="margin-right:5px;" class="fa fa-plus-square"></i>New Gallery</a>
      </div>
      <div class="col-xs-2">
        <button class="btn btn-block btn-danger"><i style="margin-right:5px;" class="fa fa-trash"></i>Delete</button>
      </div>
    </div><!-- /.box-header -->
    <div class="box-body">  
      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>No.</th>
            <th>Gambar</th>
            <th>Judul</th>
            <th>Tampil</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
   
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Xyzpb/popup/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <p class="label bg-orange">Aktifkan salah satu PopUp , Tipe Gambar atau Text</p>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Gambar</th>
            <th>Judul</th> 
            <th>isi</th>
            <th>Aktif</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php 
  
  foreach($popup->result_array() as $data) { ?>
          <tr>
            <td>
            	<?php if(!empty($data['gambar'])) { ?>
            		<img style="width:300px;height:250px;" src="<?php echo base_url().'asset/images/popup/'.$data['gambar']; ?>">
            	<?php } ?>
            </td>
            <td><?php echo $data['judul']; ?></td>
            <td><?php echo $data['isi']; ?></td>
            <td style="text-align:center;"><?php 
                  if($data['aktif'] == 'Y') { 
                    echo '<small class="label bg-green">'.$data['aktif'].'</small>';
                  } else {
                    echo '<small class="label bg-red">'.$data['aktif'].'</small>';
                  }
                ?>       
           </td>
            <td style="text-align:center;"><a href="<?php echo base_url().'Xyzpb/popup/edit/'.$data['id']; ?>"><i class="glyphicon glyphicon-edit"></i></a></td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
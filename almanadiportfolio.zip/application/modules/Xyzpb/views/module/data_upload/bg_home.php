<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Xyzpb/data_upload/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <button class="btn btn-app"><i class="fa fa-trash"></i>Delete</button>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>Nama Perusahaan</th>
            <th>Jenis Izin</th>
            <th>Nama File</th>
            <th>Semester</th>
            <th>Tgl Upload</th>    
            <th>Status</th> 
            <th>Keterangan</th>
            <th>Aksi</th>
            <th>Download</th>       
          </tr>
        </thead>
        <tbody>
<?php 
  foreach($data_upload->result_array() as $data) { ?>
          <tr>
            <td class="ceklist"><input type="checkbox" name="id[]" id="selectAll" value="<?php echo $data['id']; ?>"/></td>
            <td><?php echo $data['nama_perusahaan']; ?></td>
            <td><?php echo $data['jenis_izin']; ?></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['semester']; ?></td>
            <td><?php echo $data['tgl_upload']; ?></td>
             <td style="text-align:center;">
                <?php 
                  if($data['status'] == 'Diterima') { 
                    echo '<small class="label bg-green">'.$data['status'].'</small>';
                  } elseif($data['status'] == 'Revisi') {
                    echo '<small class="label bg-red">'.$data['status'].'</small>';
                  } else {
                    echo '<small class="label bg-blue">'.$data['status'].'</small>';
                  }
                ?>       
           </td>
            <td><?php echo $data['keterangan']; ?></td>
            <td style="width:10%;text-align:center;"> <a href="<?php echo base_url().'Xyzpb/data_upload/edit/'.$data['id']; ?>"><i class="glyphicon glyphicon-edit"> </i> Proses</a> </br>  
              <a href="<?php echo base_url().'Xyzpb/user/detail/'.$data['id_user']; ?>"><i class="glyphicon glyphicon-search"> </i> View</a>
            </td>
            <td style="width:15%;text-align:center;"><?php
           	$x = 1;
           	$get_download = $this->db->query("SELECT * FROM upload_detail WHERE id = '$data[id]'");
           	foreach($get_download ->result_array() as $datax) {   ?>
  
              		<a href="<?php echo base_url().'Xyzpb/data_upload/download/'.$datax['id_upload_detail']; ?>" target="_blank"><i class="glyphicon glyphicon-download-alt"> </i> Download File <?php echo $x++; ?></a></br>                   
          <?php	} ?>
           </td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
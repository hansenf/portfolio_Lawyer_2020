<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open("Xyzpb/data_upload/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label>Status</label>
          <select  style="width: 30%;" class="form-control" id="status" name="status" required>
            <option selected="selected" value>-Pilih Status-</option>
            <option value="Diterima">Diterima</option>
            <option value="Revisi">Revisi</option>
          </select>
         </div>
        <div class="form-group">
          <label>Keterangan</label>
          <textarea style="width: 60%;" class="form-control" name="keterangan" placeholder="Ketikan Keterangan Status" required><?php echo $keterangan; ?></textarea>
        </div>
    
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
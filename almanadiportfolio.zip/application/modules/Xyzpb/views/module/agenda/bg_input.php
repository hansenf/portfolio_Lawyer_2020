<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Xyzpb/agenda/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="judul">Judul</label>
          <input style="width: 60%;" type="text" class="form-control" id="judul" name="judul" placeholder="Ketikan judul" value="<?php echo $judulx; ?>" required>
        </div>
        <div class="form-group">
          <label for="keterangan">Keterangan</label>
          <textarea style="width: 60%;height:80px;"class="form-control" id="keterangan" name="keterangan" placeholder="Ketikan keterangan"><?php echo $keterangan; ?></textarea>
        </div>
        <div class="form-group">
          <label for="icon">Icon</label>
          <input style="width: 40%;" type="text" class="form-control" id="icon" name="icon" placeholder="css class icon" value="<?php echo $icon; ?>">
        </div>
        <div class="form-group">
          <label for="tgl_mulai">Tanggal Mulai</label>
          <input style="width: 60%;" type="date" class="form-control" id="tgl_mulai" name="tgl_mulai" placeholder="Ketikan Tgl Mulai" value="<?php echo $tgl_mulai; ?>">
        </div>  
        <?php if($gambar != "") { ?>  
        <div class="form-group">
          <img style="width:150px;height:50px;" src="<?php echo base_url().'asset/images/agenda/'.$gambar; ?>">
        </div>   
    <?php } ?>
        <div class="form-group">
          <label for="exampleInputFile">Gambar</label>
          <input type="file" id="gambar_agenda" name="gambar_agenda">
        </div>  
        <p>Best Picture 465x345 Pixels</p> 
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
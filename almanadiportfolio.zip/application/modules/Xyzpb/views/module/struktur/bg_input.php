<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Xyzpb/struktur/save"); ?>
      <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
      <div class="box-body">
    <?php if($gambar != "") { ?>  
        <div class="form-group">
          <img style="width:450px;height:300px;" src="<?php echo base_url().'asset/images/struktur/'.$gambar; ?>">
        </div>   
    <?php } ?>
        <div class="form-group">
          <label for="exampleInputFile">Gambar</label>
          <input type="file" id="gambar_photo" name="gambar_photo">
        </div>
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Edit</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
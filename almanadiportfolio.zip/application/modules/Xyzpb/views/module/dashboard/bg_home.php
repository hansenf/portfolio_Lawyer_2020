    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3>Berita</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-newspaper-o"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/post" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
          <h3>Informasi</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-calendar-check-o"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/informasi" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-yellow">
        <div class="inner">
          <h3>Video</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-video-camera"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/video" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-red">
        <div class="inner">
          <h3>Upload</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-upload"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/file" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-red">
        <div class="inner">
          <h3>Page</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-clone"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/page" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
     <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-yellow">
        <div class="inner">
          <h3>Gallery</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="glyphicon glyphicon-th"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/album" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-green">
        <div class="inner">
          <h3>Users</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-users"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/user" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
    <div class="col-lg-3 col-xs-6">
      <!-- small box -->
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3>Banner</h3>
          <p><i class="fa fa-bookmark"></i></p>
        </div>
        <div class="icon">
          <i class="fa fa-file-image-o"></i>
        </div>
        <a href="<?php echo base_url(); ?>Xyzpb/banner" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
      </div>
    </div><!-- ./col -->
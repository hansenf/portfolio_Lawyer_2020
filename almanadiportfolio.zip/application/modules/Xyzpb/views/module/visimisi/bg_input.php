<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
    </div><!-- /.box-header -->
    <?php echo form_open("Xyzpb/visimisi/edit"); ?>
      <div class="box-body">
        <div class="form-group">
          <label for="visi">Visi</label>
          <input style="width: 60%;" type="text" class="form-control" id="visi" name="visi" value="<?php echo $visimisi->visi;?>" required>
        </div>
        <div class="form-group">
          <label for="misi">Misi</label>
          <input style="width: 60%;" type="text" class="form-control" id="misi" name="misi" value="<?php echo $visimisi->misi;?>" required>
        </div>
    
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Edit</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
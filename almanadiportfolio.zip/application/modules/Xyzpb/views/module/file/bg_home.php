<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Xyzpb/file/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <a style="margin-left:0;" class="btn btn-app" href="<?php echo base_url().'Xyzpb/file/add'; ?>"><i class="fa fa-plus-square"></i> New</a>
      <button class="btn btn-app"><i class="fa fa-trash"></i>Delete</button>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>Nama File</th>
            <th>Keterangan</th>
            <th>Kategori</th>    
            <th>Tgl Upload</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($file->result_array() as $data) { ?>
          <tr>
            <td class="ceklist"><input type="checkbox" name="id[]" id="selectAll" value="<?php echo $data['id']; ?>"/></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['keterangan']; ?></td>
            <td><?php echo $data['kategori_file']; ?></td>
            <td><?php echo $data['tgl_upload']; ?></td>
            <td style="text-align:center;">
              <a href="<?php echo base_url().'Xyzpb/file/edit/'.$data['id']; ?>"><i class="glyphicon glyphicon-edit"></i></a> | 
              <a href="<?php echo base_url().'Xyzpb/file/download/'.$data['id']; ?>" target="_blank"><i class="glyphicon glyphicon-download-alt"></i></a>
            </td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
  <div class="col-xs-12">
      <div class="box box-danger">
        <div class="box-header with-border">
          <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
        </div><!-- /.box-header -->
<?php echo form_open_multipart("Xyzpb/about/save"); ?>
        <div class="box-body">
          <div class="form-group">
            <label for="author">Author</label>
            <input style="" type="text" class="form-control" id="author" name="author" placeholder="Ketikan author website" value="<?php echo $author; ?>" >
          </div>
          <div class="form-group">
            <label for="judul_website">Nama Website</label>
            <input style="" type="text" class="form-control" id="judul_website" name="judul_website" placeholder="Ketikan nama website" value="<?php echo $judul_website; ?>" >
          </div>
          <div class="form-group">
            <label for="meta_deskripsi">Meta Deskripsi</label>
            <input style="" type="text" class="form-control" id="meta_deskripsi" name="meta_deskripsi" placeholder="Ketikan meta deskripsi website" value="<?php echo $meta_deskripsi; ?>" >
          </div>
          <div class="form-group">
            <label for="meta_keyword">Meta Keyword</label>
            <input style="" type="text" class="form-control" id="meta_keyword" name="meta_keyword" placeholder="Ketikan meta keyword website" value="<?php echo $meta_keyword; ?>" >
          </div>
          <div class="form-group">
            <label for="nama">Nama Pimpinan</label>
            <input style="" type="text" class="form-control" id="nama" name="nama" placeholder="Ketikan nama website" value="<?php echo $nama; ?>" >
          </div>
          <div class="form-group">
            <label for="pesan_pembuka">Pesan Pembuka</label>
            <input style="" type="text" class="form-control" id="pesan_pembuka" name="pesan_pembuka" placeholder="Ketikan pesan pembuka .." value="<?php echo $pesan_pembuka; ?>" >
          </div>
          <div class="form-group">
            <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
             <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
            <label for="tentang">Tentang Website</label>
            <textarea style="height:100px;"class="form-control" id="isi" name="tentang" placeholder="Ketikan tentang website"><?php echo $tentang; ?></textarea>
          </div>        
          <div class="form-group">
            <label for="alamat">Alamat</label>
            <textarea style="height:80px;"class="form-control" id="alamat" name="alamat" placeholder="Ketikan alamat"><?php echo $alamat; ?></textarea>
          </div> 
          <div class="form-group">
            <label for="Telpon">Telpon</label>
            <input style="" type="text" class="form-control" id="telpon" name="telpon" placeholder="Ketikan Telpon" value="<?php echo $telpon; ?>" >
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input style="" type="text" class="form-control" id="email" name="email" placeholder="Ketikan email" value="<?php echo $email; ?>" >
          </div>
          <div class="form-group">
            <label for="facebook">Facebook</label>
            <input style="" type="text" class="form-control" id="facebook" name="facebook" placeholder="Ketikan alamat facebook website" value="<?php echo $facebook; ?>" >
          </div> 
          <div class="form-group">
            <label for="twitter">Twitter</label>
            <input style="" type="text" class="form-control" id="twitter" name="twitter" placeholder="Ketikan alamat twitter website" value="<?php echo $twitter; ?>" >
          </div> 
          <div class="form-group">
            <label for="google">Google Plus</label>
            <input style="" type="text" class="form-control" id="google" name="google" placeholder="Ketikan alamat google website" value="<?php echo $google; ?>" >
          </div> 
          <div class="form-group">
            <label for="youtube">Youtube</label>
            <input style="" type="text" class="form-control" id="youtube" name="youtube" placeholder="Ketikan alamat youtube website" value="<?php echo $youtube; ?>" >
          </div>  
          <div class="form-group">
            <label for="instagram">Instagram</label>
            <input style="" type="text" class="form-control" id="instagram" name="instagram" placeholder="Ketikan alamat instagram" value="<?php echo $instagram; ?>" >
          </div> 
          <div class="form-group">
            <label for="wa">Watshapp</label>
            <input style="" type="text" class="form-control" id="wa" name="wa" placeholder="Ketikan Watshapp" value="<?php echo $wa; ?>" >
          </div> 
          <div class="form-group">
            <label for="bbm">BBM</label>
            <input style="" type="text" class="form-control" id="bbm" name="bbm" placeholder="Ketikan bbm" value="<?php echo $bbm; ?>" >
          </div> 
          <div class="form-group">
            <label for="line">Line</label>
            <input style="" type="text" class="form-control" id="line" name="line" placeholder="Ketikan line" value="<?php echo $line; ?>" >
          </div> 
          <div class="form-group">
            <label for="fanspage">Facebook Fanspage</label>
            <input style="" type="text" class="form-control" id="fanspage" name="fanspage" placeholder="Ketikan URL Fanspage" value="<?php echo $fanspage; ?>">
          </div>   
          <div class="form-group">
            <label for="map">Map</label>
            <textarea style="height:100px;"class="form-control" id="map" name="map" placeholder="Ketikan iframe google map"><?php echo $map; ?></textarea>
          </div> 
          
          
          <?php if($gambar != "") { ?>  
          <div class="form-group">
            <img style="width:175px;height:175px;" src="<?php echo base_url().'asset/images/banner/'.$favicon; ?>">
          </div>   
  <?php } ?>
          <div class="form-group">
            <label for="exampleInputFile">Ganti Favicon</label>
            <input type="file" id="gambar_favicon" name="gambar_favicon" >
          </div>
          
          
  <?php if($gambar != "") { ?>  
          <div class="form-group">
            <img style="width:100%;height:170px;" src="<?php echo base_url().'asset/images/banner/'.$gambar; ?>">
          </div>   
  <?php } ?>
          <div class="form-group">
            <label for="exampleInputFile">Ganti Logo</label>
            <input type="file" id="gambar_banner" name="gambar_banner" >
            <p class="help-block">gambar akan menjadi logo website.</p>
          </div>
        </div>
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
<?php echo form_close(); ?>
  </div><!-- /.box -->
</div>

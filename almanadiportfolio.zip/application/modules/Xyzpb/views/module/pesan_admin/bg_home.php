<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Xyzpb/pesan_admin/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <button class="btn btn-app"><i class="fa fa-trash"></i>Delete</button>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>Nama</th>
            <th>Email</th>
            <th>Subjek</th>    
            <th>Message</th> 
            <th>Tgl Kirim</th>       
          </tr>
        </thead>
        <tbody>
<?php 
  foreach($pesan_admin->result_array() as $data) { ?>
          <tr>
            <td class="ceklist"><input type="checkbox" name="id[]" id="selectAll" value="<?php echo $data['id']; ?>"/></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['email']; ?></td>
            <td><?php echo $data['subjek']; ?></td>
            <td><?php echo $data['message']; ?></td>
            <td><?php echo $data['tgl_kirim']; ?></td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
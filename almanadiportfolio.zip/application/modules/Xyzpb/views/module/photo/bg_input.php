<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Xyzpb/photo/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="kategori">Nama Album</label>
            <?php echo $combo_album; ?>
          <a class="bg-red" href="<?php echo base_url().'Xyzpb/album'; ?>" target="_blank">Tambah Album Photo</a>      
        </div>
        <div class="form-group">
          <label for="keterangan">Keterangan</label>
          <textarea style="height:100px;width: 60%;" class="form-control" id="keterangan" name="keterangan" placeholder="Ketikan keterangan"><?php echo $keterangan; ?></textarea>
        </div>
    <?php if($gambar != "") { ?>  
        <div class="form-group">
          <img style="width:150px;height:50px;" src="<?php echo base_url().'asset/images/photo/'.$gambar; ?>">
        </div>   
    <?php } ?>
        <div class="form-group">
          <label for="exampleInputFile">Gambar</label>
          <input type="file" id="gambar_photo" name="gambar_photo">
        </div>
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
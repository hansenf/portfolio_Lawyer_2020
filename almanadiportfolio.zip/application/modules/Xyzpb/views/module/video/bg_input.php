<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Xyzpb/video/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="judul">Judul</label>
          <input style="width: 60%;" type="text" class="form-control" id="judul" name="judul" placeholder="Ketikan judul" value="<?php echo $judulx; ?>" required>
        </div>
        <div class="form-group">
          <label for="url">ID Youtube</label>
          <input style="width: 60%;" type="text" class="form-control" id="url" name="url" placeholder="contoh: d7l8F6pSTck" value="<?php echo $url; ?>" required>
        </div> 
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
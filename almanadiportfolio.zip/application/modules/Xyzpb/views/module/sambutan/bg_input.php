  <div class="col-xs-12">
      <div class="box box-danger">
        <div class="box-header with-border">
          <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
        </div><!-- /.box-header -->
<?php echo form_open_multipart("Xyzpb/sambutan/save"); ?>
        <div class="box-body">
          <div class="form-group">
            <label for="nama">Nama Pimpinan</label>
            <input style="" type="text" class="form-control" id="nama" name="nama" placeholder="Ketikan nama kepala sekolah" value="<?php echo $nama; ?>" >
          </div>
          <div class="form-group">
            <label for="jabatan">Jabatan</label>
            <input style="" type="text" class="form-control" id="jabatan" name="jabatan" placeholder="Ketikan jabatan" value="<?php echo $jabatan; ?>" >
          </div>
          <div class="form-group">
            <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
            <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
            <label for="sambutan">Sambutan Pimpinan</label>
            <textarea style="height:100px;" class="form-control" id="isi" name="sambutan" placeholder="Ketikan sambutan website"><?php echo $sambutan; ?></textarea>
          </div>              
  <?php if($gambar != "") { ?>  
          <div class="form-group">
            <img style="height:100px;width:100px;" src="<?php echo base_url().'asset/images/staff/'.$gambar; ?>">
          </div>   
  <?php } ?>
          <div class="form-group">
            <label for="exampleInputFile">Ganti Foto</label>
            <input type="file" id="gambar_kepsek" name="gambar_kepsek" >
          </div>
        </div>
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
<?php echo form_close(); ?>
  </div><!-- /.box -->
</div>

<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Xyzpb/user/save_file"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />      
      <input type="hidden" name="thefile" value="<?php echo $thefile; ?>" />
      <div class="box-body">  
        <div class="form-group">
          <label for="keterangan">Keterangan</label>
          <textarea style="height:80px;width: 60%;" class="form-control" id="keterangan" name="keterangan" placeholder="Ketikan keterangan" required><?php echo $keterangan; ?></textarea>
        </div> 
        <div class="form-group">
          <label for="file_upload">File Upload</label>
          <input type="file" id="file_upload" name="file_upload">
        </div>  
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
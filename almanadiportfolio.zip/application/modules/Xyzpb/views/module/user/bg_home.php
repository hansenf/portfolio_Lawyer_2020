<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Xyzpb/user/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <a style="margin-left:0;" class="btn btn-app" href="<?php echo base_url().'Xyzpb/user/add'; ?>"><i class="fa fa-plus-square"></i> New</a>
      <button class="btn btn-app"><i class="fa fa-trash"></i>Delete</button>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>Gambar</th>
            <th>Nama Perusahaan</th>  
            <th>Username</th>
            <th>Password</th>
            <th>Tanggal Tempo</th>
            <th>Aktif</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($user->result_array() as $data) { ?>
          <tr>
            <td class="ceklist"><input type="checkbox" name="id[]" id="selectAll" value="<?php echo $data['id']; ?>"/></td>
            <td>
              <?php 
                    if(!empty($data['gambar'])) {
                    echo '<img style="width:100px;height:120px;" src="'.base_url().'asset/images/akun/'.$data['gambar'].'">';      
                    } else {
                    echo '<img style="width:100px;height:120px;" src="'.base_url().'asset/images/akun/userakun.jpg">';
                    }            
                ?>                  
            </td>
            <td>
            	<?php 
            		echo $data['nama_perusahaan']; 
            		if($data['tgl_tempo'] != "0" && $data['tgl_tempo'] != "1") {
		       	$date1 = $data['tgl_tempo'];
			       	$date2 = date('Y-m-d');
			    	$selisih = (((strtotime ($date1) - strtotime ($date2)))/(60*60*24));
			    	if($selisih < 0) {
			    		echo '<p style="color:red;">Batas Waktu Pengiriman Telah Lewat</p>';
			    		echo '<a href="'.base_url().'Xyzpb/user/filep/'.$data['id'].'"><i class="glyphicon glyphicon-share"> </i> Kirim File</a>';
			    	}
			}
            	?>
            </td>
            <td><?php echo $data['username']; ?></td>
            <td><?php echo base64_decode($data['password']); ?></td> 
            <td><?php echo $data['tgl_tempo']; ?></td>           
            <td style="text-align:center;">
                <?php 
                  if($data['aktif'] == 'Y') { 
                    echo '<small class="label bg-green">'.$data['aktif'].'</small>';
                  }  else {
                    echo '<small class="label bg-red">'.$data['aktif'].'</small>';
                  }
                ?>       
           </td>
            <td style="text-align:center;"><a href="<?php echo base_url().'Xyzpb/user/edit/'.$data['id']; ?>"><i class="glyphicon glyphicon-edit"> </i> Edit</a> |
<a href="<?php echo base_url().'Xyzpb/user/detail/'.$data['id']; ?>"><i class="glyphicon glyphicon-expand"> </i> View</a> |
<a href="<?php echo base_url().'Xyzpb/user/tgl_tempo/'.$data['id']; ?>"><i class="glyphicon glyphicon-calendar"> </i> Tgl Tempo</a></td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
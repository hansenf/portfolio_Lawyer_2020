<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
    </div><!-- /.box-header -->
      <div class="box-body">
      
<?php 
      foreach($user_detail->result_array() as $data) { 
      $idu = $data['id'];
      $edit = '<a style="margin-top:10px;width:100%;" href="'.base_url().'Xyzpb/user/edit/'.$data['id'].'" class="btn btn-danger">Edit</a>
';
      if(!empty($data['gambar'])) {
      $gambar = '<img style="height:220px;width:100%;" src="'.base_url().'asset/images/akun/'.$data['gambar'].'">';
      } else {
      $gambar = '<img style="height:220px;width:100%;" src="'.base_url().'asset/images/akun/userakun.jpg">';
      }
      $nama_perusahaan = '<td>'.$data['nama_perusahaan'].'</td>';
      $alamat_perusahaan = '<td>'.$data['alamat_perusahaan'].'</td>';  
      $telpon_perusahaan = '<td>'.$data['telpon_perusahaan'].'</td>';  
      $nama_pj = '<td>'.$data['nama_pj'].'<td>';
      $jabatan = '<td>'.$data['jabatan'].'<td>';
      $telpon_pj = '<td>'.$data['telpon_pj'].'<td>';
      $jenis_kegiatan = '<td>'.$data['jenis_kegiatan'].'<td>';
      $lokasi_kegiatan = '<td>'.$data['lokasi_kegiatan'].'<td>';
      $kordinat_kegiatan = '<td>'.$data['kordinat_kegiatan'].'<td>';
      $luas_kegiatan = '<td>'.$data['luas_kegiatan'].'<td>';
      $telpon_lokasi = '<td>'.$data['telpon_lokasi'].'<td>';
      $username= '<td>'.$data['username'].'</td>'; 
      $password= '<td>'.base64_decode($data['password']).'</td>';
      
      } 
if(!empty($idu)) {
echo    '<div class="col-md-2">
          '.$gambar.'
          '.$edit.'
        </div>
        <div class="col-md-6">
          <table class="table table-bordered">
            <tbody>
              <tr>
                <td style="width:30%;">Nama Perusahaan</td>'.$nama_perusahaan.'
              </tr>
              <tr>
                <td style="width:30%;">Alamat Perusahaan</td>'.$alamat_perusahaan.'
              </tr>
              <tr>
                <td style="width:30%;">Telpon Perusahaan</td>'.$telpon_perusahaan.'
              </tr>
              <tr>
                <td style="width:30%;">Nama Penganggung Jawab</td>'.$nama_pj.'
              </tr>
              <tr>
                <td style="width:30%;">Jabatan</td>'.$jabatan.'
              </tr>
              <tr>
                <td style="width:30%;">No Telpon/Hp Penanggung Jawab</td>'.$telpon_pj.'
              </tr>
              <tr>
                <td style="width:30%;">Jenis Kegiatan</td>'.$jenis_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">Lokasi Kegiatan</td>'.$lokasi_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">Kordinat Kegiatan</td>'.$kordinat_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">Luas Kegiatan</td>'.$luas_kegiatan.'
              </tr> 
              <tr>
                <td style="width:30%;">No Telpon Lokasi Kegiatan</td>'.$telpon_lokasi.'
              </tr>  
              <tr>
                <td style="width:30%;">Username</td>'.$username.'
              </tr> 
              <tr>
                <td style="width:30%;">Password</td>'.$password.'
              </tr>                              
            </tbody>         
        </table>
      </div>';
?>
      <div class="col-md-4">
<p style="font-size:14px" class="label bg-blue">DAFTAR PENGIRIMAN DATA:</p>
      	<table class="table table-bordered">
      		<thead>
      			<tr>
	      			<th>Tanggal</th>
	      			<th>File</th>
                                <th>Keterangan</th>
	      			<th>Download</th>
	      		</tr>
      		</thead>
      		<tbody>
<?php foreach($file_user->result_array() as $data_file) { ?>
      			<tr>
	      			<td><?php echo $data_file['tgl_upload']; ?></td>
	      			<td><?php echo $data_file['nama']; ?></td>
                                <td style="text-align:center;">
			                <?php 
			                  if($data_file['status'] == 'Diterima') { 
			                    echo '<small class="label bg-green">'.$data_file['status'].'</small>';
			                  } elseif($data_file['status'] == 'Revisi') {
			                    echo '<small class="label bg-red">'.$data_file['status'].'</small>';
			                  } else {
			                    echo '<small class="label bg-blue">'.$data_file['status'].'</small>';
			                  }
			                ?>       
			           </td>
	      			<td style="text-align:center;">
	      			<?php
					$x = 1;
					           	$get_download = $this->db->query("SELECT * FROM upload_detail WHERE id = '$data_file[id]'");
					           	foreach($get_download ->result_array() as $datax) {   ?>
					  
					              		<a href="<?php echo base_url().'Xyzpb/data_upload/download/'.$datax['id_upload_detail']; ?>" target="_blank"><i class="glyphicon glyphicon-download-alt"> </i> Download File <?php echo $x++; ?></a></br>                   
					          <?php	} ?>
				</td>
	      		</tr>
<?php } ?>
	      	</tbody>
	</table>
      </div>
      <div class="col-md-12">
     	<table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Jenis Izin</th>
            <th>No Izin</th>
            <th>Instansi Pemberi Izin</th>    
            <th>Tanggal Perizinan</th>
            <th>File</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($perizinan->result_array() as $data) { ?>
          <tr>           
            <td><?php echo $data['keterangan']; ?></td>
            <td><?php echo $data['nomor_izin']; ?></td>
            <td><?php echo $data['instansi_pemberi_izin']; ?></td>
            
            <td><?php echo $data['tgl_perizinan']; ?></td>
            <td style="text-align:center;">
              <a href="<?php echo base_url().'Xyzpb/user/download_izin/'.$data['id']; ?>" target="_blank"><i class="glyphicon glyphicon-download-alt"></i></a>
            </td>
          </tr>
<?php } ?>
        </tbody>
      </table>
      </div>
      </div><!-- /.box-body -->

<?php } else { echo 'Data Member Tidak Ditemukan'; } ?>      

      <div class="box-footer">
      </div>
  </div><!-- /.box -->
</div>
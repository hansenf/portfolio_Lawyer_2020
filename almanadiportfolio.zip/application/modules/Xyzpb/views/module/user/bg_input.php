<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open_multipart("Xyzpb/user/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <input type="hidden" name="gambar" value="<?php echo $gambar; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="instansi">Nama Perusahaan</label>
          <input style="width: 60%;" type="text" class="form-control" id="instansi" name="nama_perusahaan" placeholder="Ketikan instansi" value="<?php echo $nama_perusahaan; ?>" required>
        </div>
        <div class="form-group">
          <label for="username">Username</label>
          <input style="width: 60%;" type="text" class="form-control" id="username" name="username" placeholder="Ketikan username" value="<?php echo $username; ?>" required>
        </div> 
        <div class="form-group">
          <label for="password">Password</label>
          <input style="width: 60%;" type="text" class="form-control" id="password" name="password" placeholder="Ketikan password" value="<?php echo $password; ?>" required>
        </div>
    <?php if($gambar != "") { ?>  
        <div class="form-group">
          <img style="width:100px;height:120px;" src="<?php echo base_url().'asset/images/akun/'.$gambar; ?>">
        </div>   
    <?php } ?>
        <div class="form-group">
          <label for="exampleInputFile">Gambar</label>
          <input type="file" id="gambar_user" name="gambar_user">
          <p>Kosongkan Jika Tidak Ada</p>
        </div>
        <div class="checkbox">
          <label>
            <input type="checkbox" name="aktif" <?php if($aktif != 'N') { echo 'checked'; }  ?> > Aktif
          </label>
        </div>
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
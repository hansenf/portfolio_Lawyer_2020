<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open("Xyzpb/user/save_tgl"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <div class="box-body">
       <div class="form-group">
          <label>Jenis Izin Pelaporan</label>
          <select style="width: 60%;" class="form-control" name="jenis_izin_pelaporan"required>
          	<option value="">Pilih Jenis Izin</option>
          	<option value="Izin Lingkungan">Izin Lingkungan</option>
          	<option value="Izin Pembuangan Limbah Cair">Izin Pembuangan Limbah Cair</option>
          	<option value="Izin Penyimpanan Sementara Limbah">Izin Penyimpanan Sementara Limbah B3</option>
          </select>
        </div>
        <div class="form-group">
          <label>Tanggal Jatuh Tempo</label>
          <input id="tgl" style="width: 60%;" type="text" class="form-control" name="tgl_tempo" placeholder="Ketikan tgl_tempo" value="<?php echo $tgl_tempo; ?>" required>
        </div>
         <div class="form-group">
          <label>Keterangan Pesan</label>
          <input style="width: 60%;" type="text" class="form-control" name="keterangan" placeholder="Ketikan Keterangan Pesan" value="<?php echo $keterangan; ?>">
<p class="label bg-red">Kosongkan Bila tidak ada</p>
        </div>
    
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open("Xyzpb/menu/save_menu"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="nama">Nama Menu</label>
          <input style="width: 60%;" type="text" class="form-control" id="nama" name="nama" placeholder="Ketikan nama menu" value="<?php echo $nama; ?>" required>
        </div>
        <div class="form-group">
          <label for="url">URL</label>
          <input style="width: 60%;" type="text" class="form-control" id="url" name="url" placeholder="Ketikan url menu" value="<?php echo $url; ?>" required>
        </div>
        <div class="checkbox">
          <label>
            <input type="checkbox" name="aktif" <?php if($aktif == 'Y') { echo 'checked'; }  ?> > Aktif
          </label>
        </div>
    
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
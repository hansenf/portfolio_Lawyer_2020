<style type="text/css">
  .dd-handle {
    font-weight: bold;
  }
</style>

<div class="col-xs-4">
  <div class="box box-success">
    <div class="box-header with-border">
      <h6 class="box-title"><i style="margin-right:5px;" class="fa fa-plus-square"></i>From Link</h6>
    </div><!-- /.box-header -->

    <?php echo form_open("Xyzpb/menu/save_link"); ?>
      <div class="box-body">
        <div class="form-group">            
          <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Menu">
        </div>  
        <div class="form-group">            
          <input type="text" class="form-control" id="url" name="url" placeholder="http://example.com">
        </div>      
      </div><!-- /.box-body -->
      <div class="box-footer">
         <input type="hidden" name="cat" value="link">
         <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
        <button type="submit" class="btn btn-primary">Add</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->

   <div class="box box-danger">
    <div class="box-header with-border">
      <h6 class="box-title"><i style="margin-right:5px;" class="fa fa-plus-square"></i>From Page</h6>
    </div><!-- /.box-header -->

    <?php echo form_open("Xyzpb/menu/save_page"); ?>
      <div class="box-body">
        <div class="form-group">            
          <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Menu">
        </div>  
        <div class="form-group">            
          <?php echo $combo_page; ?>
        </div>      
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Add</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>

<div class="col-xs-8">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Layout Menu</h3>
    </div><!-- /.box-header -->
    <div class="box-body">      
        <div class="dd" id="nestable">      
            <ol class="dd-list">          
                    <?php          
                    foreach ($menu as $nav) {
                        echo '<li class="dd-item" data-id="'.$nav['id_menu'].'">';
                        echo '<div class="dd-handle">'.strtoupper($nav['nama']).'</div>';
                       
                        $sub_nav = nested_list($nav['child']);
                        if ($sub_nav != '') {
                            echo '<ol class="dd-list">';                       
                            echo nested_list($nav['child']);                                               
                            echo '</ol>';    
                        }
                        echo '</li>';
                    }
                    ?>
            </ol>
        </div>
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button id="save-form" type="submit" class="btn btn-success btn-sm"><i class="fa fa-save"></i> SAVE CHANGES</button>
      </div>
  </div><!-- /.box -->
</div>

<div class="col-xs-12">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit Menu</h3>
    </div><!-- /.box-header -->
    <div class="box-body">      
      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Nama Menu</th>   
            <th>URL</th>   
            <th>Aktif</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($menu_tabel->result_array() as $data) { ?>
          <tr>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['url']; ?></td>
            <td style="text-align:center;">                
                <?php 
                  if($data['aktif'] == 'Y') { 
                    echo '<small class="label bg-green">'.$data['aktif'].'</small>';
                  } else {
                    echo '<small class="label bg-red">'.$data['aktif'].'</small>';
                  }
                ?>                
            </td>
            <td style="text-align:center;">
              <a href="<?php echo base_url().'Xyzpb/menu/edit/'.$data['id_menu']; ?>"><i class="glyphicon glyphicon-edit"></i></a>
          <?php if($data['id_menu'] != "6" && $data['id_menu'] != "5" && $data['id_menu'] != "4" && $data['id_menu'] != "3" && $data['id_menu'] != "20" && $data['id_menu'] != "46" && $data['id_menu'] != "47") { ?>
               | <a href="<?php echo base_url().'Xyzpb/menu/delete/'.$data['id_menu']; ?>"><i class="glyphicon glyphicon-trash"></i></a>
          <?php } ?>  
            </td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
  </div><!-- /.box -->
</div>
<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open("Xyzpb/kategori_post/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="kategori_post">Kategori Post</label>
          <input style="width: 60%;" type="text" class="form-control" id="kategori_post" name="kategori_post" placeholder="Ketikan kategori_post" value="<?php echo $kategori_post; ?>" required>
        </div>
    
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
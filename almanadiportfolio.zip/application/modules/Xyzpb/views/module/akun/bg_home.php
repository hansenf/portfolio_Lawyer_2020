<div class="col-xs-12">
  <div class="box">      
    <form role="form" onsubmit="return confirm('Yakin ingin hapus data ? ');" action="<?php echo base_url().'Xyzpb/akun/delete'; ?>" method="post"> 
    <div class="box-header with-border">
      <a style="margin-left:0;" class="btn btn-app" href="<?php echo base_url().'Xyzpb/akun/add'; ?>"><i class="fa fa-plus-square"></i> New</a>
      <button class="btn btn-app"><i class="fa fa-trash"></i>Delete</button>
    </div><!-- /.box-header -->
    <div class="box-body">  

      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th class="check" style="width:20px";><input type="checkbox" name="selectAll" id="selectAll" /></th>
            <th>Gambar</th>
            <th>Nama</th> 
            <th>Username</th>
            <th>Level</th>
            <th>Aktif</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
<?php 
  $no = 1;
  foreach($akun->result_array() as $data) { ?>
          <tr>
            <td class="ceklist">
            <?php if($data['id'] != 1) { ?>
            	<input type="checkbox" name="id[]" id="selectAll" value="<?php echo $data['id']; ?>"/>
            <?php } ?>
            </td>
            <td><img style="width:100px;height:120px;" src="<?php echo base_url().'asset/images/akun/'.$data['gambar']; ?>"></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['username']; ?></td>
            <td><?php echo $data['level']; ?></td>
            <td><?php echo $data['aktif']; ?></td>
            <td style="text-align:center;"><a href="<?php echo base_url().'Xyzpb/akun/edit/'.$data['id']; ?>"><i class="glyphicon glyphicon-edit"></i></a></td>
          </tr>
<?php } ?>
        </tbody>
      </table>
    </div><!-- /.box-body -->
    </form>
  </div><!-- /.box -->
</div>
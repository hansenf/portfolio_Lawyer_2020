<div class="col-xs-12">
  <div class="box box-danger">
    <div class="box-header with-border">
      <a href="<?php echo $back; ?>"><i class="fa fa-long-arrow-left"></i> Back</a>      
    </div><!-- /.box-header -->
    <?php echo form_open("Xyzpb/jenis_izin/save"); ?>
      <input type="hidden" name="id_param" value="<?php echo $id_param; ?>" />
      <input type="hidden" name="tipe" value="<?php echo $tipe; ?>" />
      <div class="box-body">
        <div class="form-group">
          <label for="jenis_izin">Jenis Perizinan</label>
          <input style="width: 60%;" type="text" class="form-control" id="jenis_izin" name="keterangan" placeholder="Ketikan jenis izin" value="<?php echo $keterangan; ?>" required>
        </div>
    
      </div><!-- /.box-body -->
      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    <?php echo form_close(); ?>
  </div><!-- /.box -->
</div>
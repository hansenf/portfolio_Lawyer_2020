<?php 
$id = $this->session->userdata('id');
$get_author = $this->db->query("SELECT * FROM admin WHERE id = '$id'")->row(); 
?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
     <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url().'asset/images/akun/'.$get_author->gambar; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php echo $get_author->nama; ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
     </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="treeview"><a href="<?php echo base_url(); ?>" target="_blank">
          <i class="glyphicon glyphicon-globe"></i>
          <span>VIEW WEBSITE</span>          
        </a> 
      </li>
      <li class="header">MAIN NAVIGATION</li>
      <li class="<?php echo $active; ?> treeview">
        <a href="<?php echo base_url(); ?>Xyzpb/dashboard">
          <i class="fa fa-dashboard"></i> <span>DASHBOARD</span>
        </a>
      </li>  
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-user"></i>
          <span>PROFILE</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/visimisi">Visi Misi</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/struktur">Struktur Organisasi</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/tupoksi">Tugas Pokok & Fungsi</a></li>
        </ul>       
      </li>  
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-pencil"></i>
          <span>BERITA</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/post/add"><i class="glyphicon glyphicon-plus"></i> Add</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/post"><i class="glyphicon glyphicon-th-list"></i> All Post</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/kategori_post"><i class="glyphicon glyphicon-tags"></i> Kategori Post</a></li>
        </ul>       
      </li>  
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-bullhorn"></i>
          <span>INFORMASI</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/informasi/add"><i class="glyphicon glyphicon-plus"></i> Add</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/informasi"><i class="glyphicon glyphicon-th-list"></i> All Informasi</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/kategori_informasi"><i class="glyphicon glyphicon-tags"></i> Kategori Informasi</a></li>
        </ul>       
      </li> 
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-duplicate"></i>
          <span>PAGES</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/page/add"><i class="glyphicon glyphicon-plus"></i> Add</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/page"><i class="glyphicon glyphicon-th-list"></i> All Page</a></li>
        </ul>       
      </li>    
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-bookmark"></i>
          <span>MODULE</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">   
          <li><a href="<?php echo base_url(); ?>Xyzpb/banner"><i class="glyphicon glyphicon-th-large"></i> Banner</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/link"><i class="glyphicon glyphicon-tasks"></i> Link Terkait</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/staff"><i class="glyphicon glyphicon-user"></i> Kepengurusan</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/sambutan"><i class="glyphicon glyphicon-glyphicon glyphicon-bookmark"></i> Kata Sambutan</a></li>      

        </ul>       
      </li> 
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-picture"></i>
          <span>GALLERY</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/album"><i class="glyphicon glyphicon-camera"></i> Album Photo</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/photo"><i class="glyphicon glyphicon-camera"></i> Photo</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/slideshow"><i class="glyphicon glyphicon-fast-forward"></i> Slideshow</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/video"><i class="glyphicon glyphicon-facetime-video"></i> Video</a></li>
        </ul>       
      </li> 
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-cloud-upload"></i>
          <span>UPLOAD FILE</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/file"><i class="glyphicon glyphicon-open-file"></i> File</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/kategori_file"><i class="glyphicon glyphicon-tags"></i> Kategori File</a></li>
        </ul>       
      </li>     
      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-cog"></i>
          <span>PENGATURAN</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a> 
        <ul class="treeview-menu">
          <li><a href="<?php echo base_url(); ?>Xyzpb/akun"><i class="glyphicon glyphicon-user"></i> Account</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/menu"><i class="glyphicon glyphicon-tasks"></i> Menu</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/about"><i class="glyphicon glyphicon-map-marker"></i> About</a></li>
          <li><a href="<?php echo base_url(); ?>Xyzpb/popup"><i class="glyphicon glyphicon-modal-window"></i> PopUp</a></li>
        </ul>      
      </li> <!--
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Xyzpb/jenis_izin">
          <i class="fa fa-clone"></i>
          <span>JENIS PERIZINAN</span>
        </a>     
      </li>  
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Xyzpb/user">
          <i class="fa fa-users"></i>
          <span>MEMBER</span>
        </a>     
      </li>    -->
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Xyzpb/pesan_admin">
          <i class="glyphicon glyphicon-envelope"></i>
          <span>PESAN</span>
          <small class="label pull-right bg-red"><?php echo $count_pesan; ?></small>
        </a>     
      </li>
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Xyzpb/pengaduan">
          <i class="glyphicon glyphicon-folder-open"></i>
          <span>PENGADUAN</span>
          <small class="label pull-right bg-orange">
            <?php 
              $q = $this->db->query("SELECT count(baca) AS count_baca FROM pengaduan WHERE baca='N'")->row();
              echo $q->count_baca ;
            ?>
          </small>
        </a>     
      </li><!--  
      <li class="treeview">
        <a href="<?php echo base_url(); ?>Xyzpb/data_upload">
          <i class="glyphicon glyphicon-folder-open"></i>
          <span>PELAPORAN</span>
          <small class="label pull-right bg-green">
            <?php 
              $q = $this->db->query("SELECT count(status) AS count_status FROM upload WHERE status='Proses'")->row();
              echo $q->count_status;
            ?>
          </small>
        </a>     
      </li>-->
      <li class="treeview">
        <a href="<?php echo base_url().'asset/manualbook.pdf'?>">
          <i class="fa fa-file-pdf-o"></i>
          <span>TUTORIAL</span>
        </a>     
      </li>                  
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <?php echo $judul; ?>
    </h1>
    <?php   echo $this->breadcrumb->output(); ?>
  </section>
  <section class="content">
    <div class="row">



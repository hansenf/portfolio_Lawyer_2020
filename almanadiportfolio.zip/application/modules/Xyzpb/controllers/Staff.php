<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class staff extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('staff','/');
			$d['staff'] = $this->Admin_model->get_staff();
			$d['judul'] = 'staff';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/staff/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('staff',base_url().'Xyzpb/staff');
			$this->breadcrumb->append_crumb('Add staff','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New staff';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/staff';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['pangkat_golongan'] = '';
			$d['nip'] = '';
			$d['nama'] = '';
			$d['jabatan'] = '';
			$d['gambar'] = '';
			$d['aktif'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/staff/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('staff',base_url().'Xyzpb/staff');
			$this->breadcrumb->append_crumb('Edit staff','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("staff",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit staff';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/staff';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['nama'] = $get_id->nama;
			$d['nip'] = $get_id->nip;
			$d['pangkat_golongan'] = $get_id->pangkat_golongan;
			$d['jabatan'] = $get_id->jabatan;
			$d['gambar'] = $get_id->gambar;
			$d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/staff/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");	
			$in['pangkat_golongan'] = $this->input->post("pangkat_golongan");
			$in['nip'] = $this->input->post("nip");	
			$in['nama'] = $this->input->post("nama");	
			$in['jabatan'] = $this->input->post("jabatan");				
			if($this->input->post("aktif") != "") {
				$in['aktif'] = 'Y';
			} else {
				$in['aktif'] = 'N';
			}
							
			if($tipe == "add") {
				if(empty($_FILES['gambar_staff']['name'])) {
					$this->db->insert("staff",$in);
					redirect("Xyzpb/staff");
				} else {
				$config['upload_path'] = './asset/images/staff/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_staff")) {
					$data	 	= $this->upload->data();

					

					$in['gambar'] = $data['file_name'];
					
					$this->db->insert("staff",$in);
					redirect("Xyzpb/staff");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			}
			} elseif($tipe = 'edit') {
				$in['pangkat_golongan'] = $this->input->post("pangkat_golongan");
			$in['nip'] = $this->input->post("nip");	
			$in['nama'] = $this->input->post("nama");	
			$in['jabatan'] = $this->input->post("jabatan");		
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
				if(empty($_FILES['gambar_staff']['name'])) {
					$this->db->update("staff",$in,$id);
					redirect("Xyzpb/staff");
				} else {
					$config['upload_path'] = './asset/images/staff/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_staff")) {
					$data	 	= $this->upload->data();

					
					$in['gambar'] = $data['file_name'];

					$this->db->update("staff",$in,$id);
					$old_thumb	= "./asset/images/staff/".$this->input->post("gambar")."" ;
					
                                         @unlink($old_thumb);
					
                                        redirect("Xyzpb/staff");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("staff",array('id' => $x))->row();
				$path = "./asset/images/staff/".$get_id->gambar."";
				 @unlink($path);
						
				$this->db->delete("staff",array('id' => $x));				
			}
			redirect("Xyzpb/staff");			
		} else {
			redirect("Xyzpb");
		}
	}

        public function delp($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
					
				$get_id = $this->db->get_where("staff",array('id' => $id_param))->row();
				$path = "./asset/images/staff/".$get_id->gambar."";
				unlink($path);		
				$in['gambar'] ="";
				$this->db->update("staff",$in,array('id' => $id_param));			
			
			redirect("Xyzpb/staff/edit/".$id_param);			
		} else {
			redirect("Xyzpb");
		}
	}
}

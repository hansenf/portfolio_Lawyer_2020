<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class popup extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('popup','/');
			$d['popup'] = $this->Admin_model->get_popup();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'popup';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/popup/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}	

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('popup',base_url().'Xyzpb/popup');
			$this->breadcrumb->append_crumb('Edit popup','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("popup",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit popup';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/popup';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['judulx'] = $get_id->judul;
			$d['keterangan'] = $get_id->isi;
			$d['gambar'] = $get_id->gambar;
			$d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/popup/bg_input',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			
				$in['isi'] = $this->input->post("keterangan");
				$in['judul'] = $this->input->post("judul");
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
						$this->db->query("UPDATE popup SET aktif = 'N' WHERE aktif = 'Y'");
					} else {
						$in['aktif'] = 'N';
						$count_aktif = $this->db->query("SELECT count(aktif) AS count FROM popup WHERE aktif='N'")->row();
						if($count_aktif->count == 0) {
							$this->db->query("UPDATE popup SET aktif = 'Y' WHERE aktif = 'N'");
						}
					}
				if(empty($_FILES['gambar_popup']['name'])) {
					$this->db->update("popup",$in,$id);
					redirect("Xyzpb/popup");
				} else {
					$config['upload_path'] = './asset/images/popup/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '3000';
				$config['max_width']  	= '3000';
				$config['max_height']  	= '3000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_popup")) {
					$data	 	= $this->upload->data();

					/* PATH */
					$source             = "./asset/images/popup/temp/".$data['file_name'] ;
					$destination_thumb	= "./asset/images/popup/" ;			 
						// Permission Configuration
					chmod($source, 0777) ;

					/* Resizing Processing */
						// Configuration Of Image Manipulation :: Static
					$this->load->library('image_lib') ;
					$img['image_library'] = 'GD2';
					$img['create_thumb']  = TRUE;
					$img['maintain_ratio']= TRUE;

						/// Limit Width Resize
					$limit_thumb    = 640 ;

						// Size Image Limit was using (LIMIT TOP)
					$limit_use  = $data['image_width'] > $data['image_height'] ? $data['image_width'] : $data['image_height'] ;

						// Percentase Resize
					if ($limit_use > $limit_thumb) {
						$percent_thumb  = $limit_thumb/$limit_use ;
					}

						//// Making THUMBNAIL ///////
					$img['width']  = $limit_use > $limit_thumb ?  $data['image_width'] * $percent_thumb : $data['image_width'] ;
					$img['height'] = $limit_use > $limit_thumb ?  $data['image_height'] * $percent_thumb : $data['image_height'] ;

						// Configuration Of Image Manipulation :: Dynamic
					$img['thumb_marker'] = '';
					$img['quality']      = '100%' ;
					$img['source_image'] = $source ;
					$img['new_image']    = $destination_thumb ;

						// Do Resizing
					$this->image_lib->initialize($img);
					$this->image_lib->resize();
					$this->image_lib->clear() ;	

					$in['gambar'] = $data['file_name'];

					$this->db->update("popup",$in,$id);
					$old_thumb	= "./asset/images/popup/".$this->input->post("gambar")."" ;
					unlink($old_thumb);
					unlink($source);
					redirect("Xyzpb/popup");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			}
			
		}else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("popup",array('id' => $x))->row();
				$path = "./asset/images/popup/".$get_id->gambar."";
				unlink($path);		
				$this->db->delete("popup",array('id' => $x));				
			}
			redirect("Xyzpb/popup");			
		}else {
			redirect("Xyzpb");
		}
	}
}

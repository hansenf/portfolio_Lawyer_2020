<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class tupoksi extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
// 			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
// 			$this->breadcrumb->append_crumb('about','/');

			$where['id'] = "1";
			$get_id = $this->db->get_where("tupoksi",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Tugas Pokok & Fungsi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/dashboard';			
// 			$d['id_param'] = $get_id->id;
// 			$d['nama'] = $get_id->nama;
// 			$d['jabatan'] = $get_id->jabatan;
			$d['ptupoksi'] = $get_id->ptupoksi;		
// 			$d['gambar'] = $get_id->gambar;				
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/tupoksi/bg_input');
			$this->load->view('bottom');			
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
// 			$id['id'] = $this->input->post("id_param");	
// 			$in['nama'] = $this->input->post('nama');
// 			$in['jabatan'] = $this->input->post('jabatan');
			$in['ptupoksi'] = $this->input->post("ptupoksi");	
					
			
					$this->db->update("tupoksi",$in);
					redirect("Xyzpb/tupoksi");
				
			
		} else {
			redirect("Xyzpb");
		}
	} 

}

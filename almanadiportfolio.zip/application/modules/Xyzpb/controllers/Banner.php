<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class banner extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('banner','/');
			$d['banner'] = $this->Admin_model->get_banner();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'banner';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/banner/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('banner',base_url().'Xyzpb/banner');
			$this->breadcrumb->append_crumb('Add banner','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New banner';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/banner';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['keterangan'] = '';
			$d['url'] = '';
			$d['gambar'] = '';
			$d['aktif'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/banner/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('banner',base_url().'Xyzpb/banner');
			$this->breadcrumb->append_crumb('Edit banner','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("banner",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit banner';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/banner';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['keterangan'] = $get_id->keterangan;
			$d['url'] = $get_id->url;
			$d['gambar'] = $get_id->gambar;
			$d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/banner/bg_input',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/banner/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_banner")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];
					$in['keterangan'] = $this->input->post("keterangan");
					$in['url'] = $this->input->post("url");			
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
					
					$this->db->insert("banner",$in);
					redirect("Xyzpb/banner");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['keterangan'] = $this->input->post("keterangan");
				$in['url'] = $this->input->post("url");
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
				if(empty($_FILES['gambar_banner']['name'])) {
					$this->db->update("banner",$in,$id);
					redirect("Xyzpb/banner");
				} else {
					$config['upload_path'] = './asset/images/banner/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '3000';
				$config['max_width']  	= '3000';
				$config['max_height']  	= '3000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_banner")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];

					$this->db->update("banner",$in,$id);
					$old_thumb	= "./asset/images/banner/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);					
					redirect("Xyzpb/banner");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		}else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("banner",array('id' => $x))->row();
				$path = "./asset/images/banner/".$get_id->gambar."";
				@unlink($path);		
				$this->db->delete("banner",array('id' => $x));				
			}
			redirect("Xyzpb/banner");			
		}else {
			redirect("Xyzpb");
		}
	}
}

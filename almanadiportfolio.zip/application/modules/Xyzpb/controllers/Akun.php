<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class akun extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('akun','/');
			$d['akun'] = $this->Admin_model->get_admin();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'akun';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/akun/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('akun',base_url().'Xyzpb/akun');
			$this->breadcrumb->append_crumb('Add akun','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New akun';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/akun';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['nama'] = '';
			$d['username'] = '';
			$d['level'] = '';
			$d['gambar'] = '';
			$d['aktif'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/akun/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('akun',base_url().'Xyzpb/akun');
			$this->breadcrumb->append_crumb('Edit akun','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("admin",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit akun';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/akun';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['nama'] = $get_id->nama;
			$d['username'] = $get_id->username;
			$d['level'] = $get_id->level;
			$d['gambar'] = $get_id->gambar;
			$d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/akun/bg_input',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/akun/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_akun")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];
					$in['nama'] = $this->input->post("nama");
					$in['username'] = $this->input->post("username");
					$in['level'] = $this->input->post("level");	
					$in['password'] = md5($this->input->post("password"));			
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
					
					$this->db->insert("admin",$in);
					redirect("Xyzpb/akun");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['nama'] = $this->input->post("nama");
					$in['username'] = $this->input->post("username");	
					$in['password'] = md5($this->input->post("password"));	
					$in['level'] = $this->input->post("level");		
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
				if(empty($_FILES['gambar_akun']['name'])) {
					$this->db->update("admin",$in,$id);
					redirect("Xyzpb/akun");
				} else {
					$config['upload_path'] = './asset/images/akun/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_akun")) {
					$data	 	= $this->upload->data();
						

					$in['gambar'] = $data['file_name'];

					$this->db->update("admin",$in,$id);
					$old_thumb	= "./asset/images/akun/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/akun");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		}else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("admin",array('id' => $x))->row();
				$path = "./asset/images/akun/".$get_id->gambar."";
				@unlink($path);		
				$this->db->delete("admin",array('id' => $x));				
			}
			redirect("Xyzpb/akun");			
		} else {
			redirect("Xyzpb");
		}
	}
}

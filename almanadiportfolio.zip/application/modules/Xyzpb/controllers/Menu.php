<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class menu extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('menu','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();		
			$d['menu'] = $this->GetParentPages();
			$d['menu_tabel'] = $this->Admin_model->get_menu();
			$d['judul'] = 'menu';
			$d['active'] = 'active';
			$d['id_param'] = '';
			$d['nama'] = '';
			$d['url'] = '';		
			$d['combo_page'] = $this->Admin_model_detail->get_combo_page();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/menu/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	private function GetParentPages($parent = 0) {
      $data = [];
      $this->db->where('id_parent', $parent);
      $this->db->order_by('posisi', 'ASC');
      $result = $this->db->get('menu');
      foreach ($result->result() as $row) {
         $data[] = [
            'id_menu' => $row->id_menu,
            'nama' => $row->nama,
            'child' => $this->GetParentPages($row->id_menu),
         ];
      }

      return $data;
  	}

   	public function save_position() {
      if (NULL !== $this->input->post('page')) {
         $page = json_decode($this->input->post('page'), TRUE);
         $this->update_position(0, $page);
      }
      $response = [];
      $response['growl'] = 'success';
      $response['message'] = 'Your data have been saved.';
      $this->output
         ->set_content_type('application/json')
         ->set_output(json_encode($response));
   }

   	private function update_position($parent, $children) {
      $i = 1;
      foreach ($children as $key => $value) {
         $id_menu = $children[$key]['id'];
         $data['id_parent'] = $parent;
         $data['posisi'] = $i;
         $this->db->where('id_menu', $id_menu)->update('menu', $data);
         if (isset($children[$key]['children'][0])) {
            $this->update_position($id_menu, $children[$key]['children']);
         }
         $i++;
      }
   	}



	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('menu',base_url().'Xyzpb/menu');
			$this->breadcrumb->append_crumb('Edit menu','/');

			$where['id_menu'] = $id_param;
			$get_id = $this->db->get_where("menu",$where)->row();
			$d['judul'] = 'Edit menu';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/menu';
			$d['id_param'] = $get_id->id_menu;
			$d['nama'] = $get_id->nama;
			$d['url'] = $get_id->url;
                        $d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/menu/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save_link() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {			
			$in['nama'] = $this->input->post('nama');
			$in['url'] = $this->input->post("url");		
			$in['posisi'] = '0';
			$in['id_parent'] = '0';		
			$this->db->insert("menu",$in);			
			redirect("Xyzpb/menu");
			
		} else {
			redirect("Xyzpb");
		}
	}

	public function save_page() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {			
			$in['nama'] = $this->input->post('nama');
			$in['url'] = base_url()."Web/page/detail/".$this->input->post('page')."/".url_title($this->input->post('nama'),'-',TRUE);
			$in['posisi'] = '0';
			$in['id_parent'] = '0';		
			$this->db->insert("menu",$in);			
			redirect("Xyzpb/menu");
			
		} else {
			redirect("Xyzpb");
		}
	}

	public function save_menu() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {			
			$in['nama'] = $this->input->post('nama');
			$in['url'] = $this->input->post("url");	
			$id['id_menu'] = $this->input->post("id_param");
                        if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
			$this->db->update("menu",$in,$id);	
			redirect("Xyzpb/menu");
			
		} else {
			redirect("Xyzpb");
		}
	}


	public function delete($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$in['id_parent'] = "0";
			$id['id_parent'] = $id_param;
			$this->db->update("menu",$in,$id);	
			$this->db->delete("menu",array('id_menu' => $id_param));	
			
			redirect("Xyzpb/menu");			
		} else {
			redirect("Xyzpb");
		}
	}   
}

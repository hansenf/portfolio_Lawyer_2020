<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class video extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('video','/');
			$d['video'] = $this->Admin_model->get_video();
			$d['judul'] = 'video';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/video/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('video',base_url().'Xyzpb/video');
			$this->breadcrumb->append_crumb('Add video','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New video';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/video';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['judulx'] = '';
			$d['url'] = '';
			$this->load->view('top');	
			$this->load->view('menu',$d);
			$this->load->view('module/video/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('video',base_url().'Xyzpb/video');
			$this->breadcrumb->append_crumb('Edit video','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("video",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit video';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/video';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['judulx'] = $get_id->judul;
			$d['url'] = $get_id->url;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/video/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");	
			$in['judul'] = $this->input->post('judul');
			$in['url'] = $this->input->post("url");	

			if($tipe == "add") {				
				$this->db->insert("video",$in);			
				redirect("Xyzpb/video");
			} elseif($tipe = 'edit') {
				$this->db->update("video",$in,$id);
				redirect("Xyzpb/video");
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$this->db->delete("video",array('id' => $x));				
			}
			redirect("Xyzpb/video");			
		} else {
			redirect("Xyzpb");
		}
	}
}

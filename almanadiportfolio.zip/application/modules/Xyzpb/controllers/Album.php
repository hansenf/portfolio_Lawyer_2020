<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class album extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('album','/');
			$d['album'] = $this->Admin_model->get_album();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'album';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/album/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('album',base_url().'Xyzpb/album');
			$this->breadcrumb->append_crumb('Add album','/');			

			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New album';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/album';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['nama'] = '';
			$d['keterangan'] = '';			
			$d['gambar'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/album/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('album',base_url().'Xyzpb/album');
			$this->breadcrumb->append_crumb('Edit album','/');

			$where['id_album'] = $id_param;
			$get_id = $this->db->get_where("album",$where)->row();
			
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit album';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/album';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id_album;
			$d['nama'] = $get_id->nama;
			$d['keterangan'] = $get_id->keterangan;
			$d['gambar'] = $get_id->gambar;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/album/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id_album'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/album/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_album")) {
					$data	 	= $this->upload->data();					

					$in['gambar'] = $data['file_name'];
					$in['tgl_upload'] = date('Y-m-d');
					$in['nama'] = $this->input->post("nama");	
					$in['keterangan'] = $this->input->post("keterangan");				
					
					$this->db->insert("album",$in);
					redirect("Xyzpb/album");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['nama'] = $this->input->post("nama");	
				$in['keterangan'] = $this->input->post("keterangan");
				$in['tgl_upload'] = date('Y-m-d');
				
				if(empty($_FILES['gambar_album']['name'])) {
					$this->db->update("album",$in,$id);
					redirect("Xyzpb/album");
				} else {
					$config['upload_path'] = './asset/images/album/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_album")) {
					$data	 	= $this->upload->data();					

					$in['gambar'] = $data['file_name'];

					$this->db->update("album",$in,$id);
					$old_thumb	= "./asset/images/album/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/album");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("album",array('id_album' => $x))->row();
				$get_foto = $this->db->get_where("photo",array('id_album' => $x))->row();
				$path = "./asset/images/album/".$get_id->gambar."";
				
				if(!empty($get_foto->gambar)) {
				$pathx = "./asset/images/photo/".$get_foto->gambar."";
				@unlink($pathx);
				$this->db->delete("photo",array('id_album' => $x));
				}
				
				@unlink($path);						
				$this->db->delete("album",array('id_album' => $x));	
					

			}
			redirect("Xyzpb/album");			
		} else {
			redirect("Xyzpb");
		}
	}
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class data_upload extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('data_upload','/');
			$d['data_upload'] = $this->Admin_model->get_upload();
			$d['judul'] = 'Data Upload';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/data_upload/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}


	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('data_upload',base_url().'Xyzpb/data_upload');
			$this->breadcrumb->append_crumb('Proses Upload','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("upload",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Proses Upload';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/data_upload';
			$d['id_param'] = $get_id->id;
			$d['keterangan'] = $get_id->keterangan;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/data_upload/bg_input');
			$this->load->view('bottom');			
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");			
			$id['id'] = $this->input->post("id_param");
			$in['keterangan'] = $this->input->post('keterangan');
			$in['status'] = $this->input->post('status');
			$in['tgl_konfirmasi'] = date('Y-m-d');
			$in['baca'] = '0';
			
			if($this->input->post('status') == 'Diterima' || $this->input->post('status') == 'Revisi') {
				$iddp = $this->input->post("id_param");
				$get_member = $this->db->query("SELECT id_user FROM upload WHERE id = '$iddp'")->row(); 
				$idx['id'] = $get_member->id_user;
				$inx['tgl_tempo'] = '0';
				$this->db->update("user",$inx,$idx);
			}
			
			$this->db->update("upload",$in,$id);
			
			redirect("Xyzpb/data_upload");
			
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {
					$get_id = $this->db->get_where("upload_detail",array('id' => $x));
					
					foreach($get_id ->result_array() as $y) {
						$path = "./asset/upload/".$y['file']."";
						unlink($path);
						//echo $y['file'];	
					}	
					
					$this->db->delete("upload",array('id' => $x));
                                       $this->db->delete("upload_detail",array('id' => $x));				
				
				
			}
			redirect("Xyzpb/data_upload");		
		
		}
	}

	public function download($id_param) {
		$get_status = $this->db->get_where("upload_detail",array("id_upload_detail"=>$id_param))->row();
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {			
			$nama = $get_status->file;
			$status = base_url()."asset/upload/".$nama;
			$data = file_get_contents($status);
			force_download($nama,$data);
		} else {
			redirect("Xyzpb");			
		}
	}
}

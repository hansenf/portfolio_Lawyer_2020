<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pesan_admin extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$in['baca'] = 'Y';
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('pesan_admin','/');
			$this->db->update("pesan_admin",$in);			
			$d['pesan_admin'] = $this->Admin_model->get_pesan_admin();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'pesan_admin';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/pesan_admin/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$this->db->delete("pesan_admin",array('id' => $x));				
			}
			redirect("Xyzpb/pesan_admin");			
		} else {
			redirect("Xyzpb");
		}
	}
}

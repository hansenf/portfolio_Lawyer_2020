<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class visimisi extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('visimisi','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['visimisi'] = $this->Admin_model->get_visimisi();
			$d['judul'] = 'visimisi';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/visimisi/bg_input',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit() {
		$data['visi']=$this->input->post('visi');
		$data['misi']=$this->input->post('misi');
		if($this->Admin_model->edit_visimisi($data))
		{
		    redirect('Xyzpb/visimisi');
		}
		else {
			redirect("Xyzpb/visimisi");
		}
	}
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class portal extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('portal','/');
			$d['portal'] = $this->Admin_model->get_portal();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'portal';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/portal/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('portal',base_url().'Xyzpb/portal');
			$this->breadcrumb->append_crumb('Add portal','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New portal';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/portal';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['keterangan'] = '';
			$d['url'] = '';
			$d['gambar'] = '';
			$d['aktif'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/portal/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('portal',base_url().'Xyzpb/portal');
			$this->breadcrumb->append_crumb('Edit portal','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("portal",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit portal';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/portal';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['keterangan'] = $get_id->keterangan;
			$d['url'] = $get_id->url;
			$d['gambar'] = $get_id->gambar;
			$d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/portal/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/portal/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_portal")) {
					$data	 	= $this->upload->data();

					/* PATH */
					$source             = "./asset/images/portal/temp/".$data['file_name'] ;
					$destination_thumb	= "./asset/images/portal/" ;			 
						// Permission Configuration
					chmod($source, 0777) ;

					/* Resizing Processing */
						// Configuration Of Image Manipulation :: Static
					$this->load->library('image_lib') ;
					$img['image_library'] = 'GD2';
					$img['create_thumb']  = TRUE;
					$img['maintain_ratio']= TRUE;

						/// Limit Width Resize
					$limit_thumb    = 640 ;

						// Size Image Limit was using (LIMIT TOP)
					$limit_use  = $data['image_width'] > $data['image_height'] ? $data['image_width'] : $data['image_height'] ;

						// Percentase Resize
					if ($limit_use > $limit_thumb) {
						$percent_thumb  = $limit_thumb/$limit_use ;
					}

						//// Making THUMBNAIL ///////
					$img['width']  = $limit_use > $limit_thumb ?  $data['image_width'] * $percent_thumb : $data['image_width'] ;
					$img['height'] = $limit_use > $limit_thumb ?  $data['image_height'] * $percent_thumb : $data['image_height'] ;

						// Configuration Of Image Manipulation :: Dynamic
					$img['thumb_marker'] = '';
					$img['quality']      = '100%' ;
					$img['source_image'] = $source ;
					$img['new_image']    = $destination_thumb ;

						// Do Resizing
					$this->image_lib->initialize($img);
					$this->image_lib->resize();
					$this->image_lib->clear() ;

					$in['gambar'] = $data['file_name'];
					$in['keterangan'] = $this->input->post("keterangan");
					$in['url'] = $this->input->post("url");			
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
					
					$this->db->insert("portal",$in);
					redirect("Xyzpb/portal");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['keterangan'] = $this->input->post("keterangan");
				$in['url'] = $this->input->post("url");
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
				if(empty($_FILES['gambar_portal']['name'])) {
					$this->db->update("portal",$in,$id);
					redirect("Xyzpb/portal");
				} else {
					$config['upload_path'] = './asset/images/portal/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '3000';
				$config['max_width']  	= '3000';
				$config['max_height']  	= '3000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_portal")) {
					$data	 	= $this->upload->data();

					/* PATH */
					$source             = "./asset/images/portal/temp/".$data['file_name'] ;
					$destination_thumb	= "./asset/images/portal/" ;			 
						// Permission Configuration
					chmod($source, 0777) ;

					/* Resizing Processing */
						// Configuration Of Image Manipulation :: Static
					$this->load->library('image_lib') ;
					$img['image_library'] = 'GD2';
					$img['create_thumb']  = TRUE;
					$img['maintain_ratio']= TRUE;

						/// Limit Width Resize
					$limit_thumb    = 640 ;

						// Size Image Limit was using (LIMIT TOP)
					$limit_use  = $data['image_width'] > $data['image_height'] ? $data['image_width'] : $data['image_height'] ;

						// Percentase Resize
					if ($limit_use > $limit_thumb) {
						$percent_thumb  = $limit_thumb/$limit_use ;
					}

						//// Making THUMBNAIL ///////
					$img['width']  = $limit_use > $limit_thumb ?  $data['image_width'] * $percent_thumb : $data['image_width'] ;
					$img['height'] = $limit_use > $limit_thumb ?  $data['image_height'] * $percent_thumb : $data['image_height'] ;

						// Configuration Of Image Manipulation :: Dynamic
					$img['thumb_marker'] = '';
					$img['quality']      = '100%' ;
					$img['source_image'] = $source ;
					$img['new_image']    = $destination_thumb ;

						// Do Resizing
					$this->image_lib->initialize($img);
					$this->image_lib->resize();
					$this->image_lib->clear() ;	

					$in['gambar'] = $data['file_name'];

					$this->db->update("portal",$in,$id);
					$old_thumb	= "./asset/images/portal/".$this->input->post("gambar")."" ;
					unlink($old_thumb);
					unlink($source);
					redirect("Xyzpb/portal");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("portal",array('id' => $x))->row();
				$path = "./asset/images/portal/".$get_id->gambar."";
				unlink($path);		
				$this->db->delete("portal",array('id' => $x));				
			}
			redirect("Xyzpb/portal");			
		} else {
			redirect("Xyzpb");
		}
	}
}

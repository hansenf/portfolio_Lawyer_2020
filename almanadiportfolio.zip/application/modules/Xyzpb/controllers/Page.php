<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class page extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('page','/');
			$d['page'] = $this->Admin_model->get_page();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'page';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/page/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('page',base_url().'Xyzpb/page');
			$this->breadcrumb->append_crumb('Add page','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New page';	
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/page';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['judulx'] = '';
			$d['isi'] = '';		
			$d['keterangan_file'] = '';
                        $d['thefile'] = '';			
			$this->load->view('top');	
			$this->load->view('menu',$d);
			$this->load->view('module/page/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('page',base_url().'Xyzpb/page');
			$this->breadcrumb->append_crumb('Edit page','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("page",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit page';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/page';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['judulx'] = $get_id->judul;
			$d['isi'] = $get_id->isi;
			$d['keterangan_file'] = $get_id->keterangan_file;
			$d['thefile'] = $get_id->file;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/page/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");	
			$in['judul'] = $this->input->post('judul');
			$in['isi'] = $this->input->post("isi");
			$in['tgl_posting'] = date('Y-m-d');	
			$in['author'] = $this->session->userdata('nama');	
			$in['keterangan_file'] = $this->input->post("keterangan_file");		
			if($tipe == "add") {
                           if(empty($_FILES['gambar_page']['name'])) {
                                $this->db->insert("page",$in);
			        redirect("Xyzpb/page");
                           } else {

				$config['upload_path'] = './asset/file/';
				$config['allowed_types']= '*';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_page")) {
					$data	 	= $this->upload->data();					
					$in['file'] = $data['file_name'];
					$this->db->insert("page",$in);
					
					redirect("Xyzpb/page");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
                           }
			} elseif($tipe = 'edit') {
				
				if(empty($_FILES['gambar_page']['name'])) {
					$this->db->update("page",$in,$id);
					redirect("Xyzpb/page");
				} else {
					$config['upload_path'] = './asset/file/';
					$config['allowed_types']= '*';
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;	
					$config['max_size']     = '0';
					$config['max_width']  	= '30000';
					$config['max_height']  	= '30000';
	
					$this->load->library('upload', $config);
	
					if ($this->upload->do_upload("gambar_page")) {
						$data	 	= $this->upload->data();					
						$in['file'] = $data['file_name'];
						$this->db->update("page",$in,$id);
						$old_thumb	= "./asset/file/".$this->input->post("thefile")."" ;
					        @unlink($old_thumb);
						
						redirect("Xyzpb/page");
					} else {
						echo $this->upload->display_errors('<p>','</p>');
					}
					
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("page",array('id' => $x))->row();
				$path = "./asset/file/".$get_id->file."";
				@unlink($path);		
				$this->db->delete("page",array('id' => $x));				
			}
			redirect("Xyzpb/page");			
		} else {
			redirect("Xyzpb");
		}
	}
}

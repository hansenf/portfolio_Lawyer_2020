<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class informasi extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('informasi','/');
			$d['informasi'] = $this->Admin_model->get_informasi();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'informasi';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/informasi/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('informasi',base_url().'Xyzpb/informasi');
			$this->breadcrumb->append_crumb('Add informasi','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New informasi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/informasi';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['judulx'] = '';
			$d['isi'] = '';			
			$d['gambar'] = '';	
			$d['combo_kategori_informasi'] = $this->Admin_model_detail->get_combo_kategori_informasi();
		
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/informasi/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('informasi',base_url().'Xyzpb/informasi');
			$this->breadcrumb->append_crumb('Edit informasi','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("informasi",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit informasi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/informasi';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['id_kategori'] = $get_id->id_kategori;
			$d['judulx'] = $get_id->judul;
			$d['isi'] = $get_id->isi;
			$d['gambar'] = $get_id->gambar;
			$d['author'] = $get_id->author;
			$d['combo_kategori_informasi'] = $this->Admin_model_detail->get_combo_kategori_informasi($d['id_kategori']);

			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/informasi/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/informasi/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_informasi")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];
					$in['judul'] = $this->input->post("judul");
					$in['isi'] = $this->input->post("isi");
					$in['id_kategori'] = $this->input->post("kategori");
					$in['tgl_posting'] = date('Y-m-d');	
					$in['author'] = $this->session->userdata('nama');
					$in['visited'] = "0";		
					
					$this->db->insert("informasi",$in);
					
					redirect("Xyzpb/informasi");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['judul'] = $this->input->post("judul");
				$in['isi'] = $this->input->post("isi");
				$in['id_kategori'] = $this->input->post("kategori");				
				
				if(empty($_FILES['gambar_informasi']['name'])) {
					$this->db->update("informasi",$in,$id);
					redirect("Xyzpb/informasi");
				} else {
					$config['upload_path'] = './asset/images/informasi/';
					$config['allowed_types']= 'gif|jpg|png|jpeg';
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;	
					$config['max_size']     = '3000';
					$config['max_width']  	= '3000';
					$config['max_height']  	= '3000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_informasi")) {
					$data	 	= $this->upload->data();					

					$in['gambar'] = $data['file_name'];

					$this->db->update("informasi",$in,$id);
					$old_thumb	= "./asset/images/informasi/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/informasi");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("informasi",array('id' => $x))->row();
				$path = "./asset/images/informasi/".$get_id->gambar."";
				@unlink($path);		
				$this->db->delete("informasi",array('id' => $x));				
			}
			redirect("Xyzpb/informasi");			
		} else {
			redirect("Xyzpb");
		}
	}
}

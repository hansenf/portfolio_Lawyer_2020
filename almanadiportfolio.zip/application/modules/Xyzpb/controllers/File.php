<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class file extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('file','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['file'] = $this->Admin_model->get_file();
			$d['judul'] = 'file';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/file/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('file',base_url().'Xyzpb/file');
			$this->breadcrumb->append_crumb('Add file','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New file';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/file';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['nama'] = '';
			$d['keterangan'] = '';
			$d['thefile'] = '';
			$d['combo_kategori_file'] = $this->Admin_model_detail->get_combo_kategori_file();


			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/file/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('file',base_url().'Xyzpb/file');
			$this->breadcrumb->append_crumb('Edit file','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("file",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit file';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/file';
			$d['tipe'] = 'edit';
			$d['id_kategori'] = $get_id->id_kategori;
			$d['id_param'] = $get_id->id;
			$d['keterangan'] = $get_id->keterangan;
			$d['nama'] = $get_id->nama;
			$d['thefile'] = $get_id->lokasi;
			$d['combo_kategori_file'] = $this->Admin_model_detail->get_combo_kategori_file($d['id_kategori']);

			//$d['kategori'] = $get_id->kategori;			
			
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/file/bg_input',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/file/';				
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;		
				$config['allowed_types']= '*';	
$config['max_size'] = '0';	
			

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("file_upload")) {
					$data	 	= $this->upload->data();					

					$in['lokasi'] = $data['file_name'];
					$in['keterangan'] = $this->input->post("keterangan");
					$in['nama'] = $this->input->post("nama");
					$in['tgl_upload'] = date('Y-m-d');
					$in['id_kategori'] = $this->input->post("kategori");		
					
					
					$this->db->insert("file",$in);
					redirect("Xyzpb/file");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {			
				$in['keterangan'] = $this->input->post("keterangan");
				$in['nama'] = $this->input->post("nama");
				$in['id_kategori'] = $this->input->post("kategori");
				$in['tgl_upload'] = date('Y-m-d');

				if(empty($_FILES['file_upload']['name'])) {
					$this->db->update("file",$in,$id);
					redirect("Xyzpb/file");
				} else {
					$config['upload_path'] = './asset/file/';				
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;		
					$config['allowed_types']= '*';		

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("file_upload")) {
					$data	 	= $this->upload->data();					

					$in['lokasi'] = $data['file_name'];

					$this->db->update("file",$in,$id);
					$old_thumb	= "./asset/file/".$this->input->post("thefile")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/file");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			}
			}
		}else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("file",array('id' => $x))->row();
				$path = "./asset/file/".$get_id->lokasi."";
				@unlink($path);		
				$this->db->delete("file",array('id' => $x));				
			}
			redirect("Xyzpb/file");			
		}else {
			redirect("Xyzpb");
		}
	}

	public function download($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$get_file = $this->db->get_where("file",array("id"=>$id_param))->row();
			$nama = $get_file->lokasi;
			$file = base_url()."asset/file/".$nama;
			$data = file_get_contents($file);
			force_download($nama,$data);
		}else {
			redirect("Xyzpb");
		}
	}
}

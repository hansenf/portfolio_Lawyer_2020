<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kategori_informasi extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('kategori_informasi','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['kategori_informasi'] = $this->Admin_model->get_kategori_informasi();
			$d['judul'] = 'kategori_informasi';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_informasi/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('kategori_informasi',base_url().'Xyzpb/kategori_informasi');
			$this->breadcrumb->append_crumb('Add kategori_informasi','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New kategori_informasi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/kategori_informasi';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['kategori_informasi'] = '';
			$this->load->view('top');	
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_informasi/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('kategori_informasi',base_url().'Xyzpb/kategori_informasi');
			$this->breadcrumb->append_crumb('Edit kategori_informasi','/');

			$where['id_kategori'] = $id_param;
			$get_id = $this->db->get_where("kategori_informasi",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit kategori_informasi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/kategori_informasi';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id_kategori;
			$d['kategori_informasi'] = $get_id->kategori_informasi;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_informasi/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id_kategori'] = $this->input->post("id_param");	
			$in['kategori_informasi'] = $this->input->post('kategori_informasi');
			
			if($tipe == "add") {				
				$this->db->insert("kategori_informasi",$in);			
				redirect("Xyzpb/kategori_informasi");
			} elseif($tipe = 'edit') {
				$this->db->update("kategori_informasi",$in,$id);
				redirect("Xyzpb/kategori_informasi");
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$this->db->delete("kategori_informasi",array('id_kategori' => $x));				
			}
			redirect("Xyzpb/kategori_informasi");			
		} else {
			redirect("Xyzpb");
		}
	}
}

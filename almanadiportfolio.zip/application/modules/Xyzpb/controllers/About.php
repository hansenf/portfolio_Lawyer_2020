<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class about extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('about','/');

			$where['id'] = "1";
			$get_id = $this->db->get_where("about",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'About';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/dashboard';			
			$d['id_param'] = $get_id->id;
			$d['judul_website'] = $get_id->judul_web;
			$d['author'] = $get_id->author;
			$d['meta_deskripsi'] = $get_id->meta_deskripsi;
			$d['meta_keyword'] = $get_id->meta_keyword;
			$d['nama'] = $get_id->nama;
                        $d['pesan_pembuka'] = $get_id->pesan_pembuka;
			$d['tentang'] = $get_id->tentang;
			$d['alamat'] = $get_id->alamat;
			$d['email'] = $get_id->email;
			$d['telpon'] = $get_id->telpon;
			$d['gambar'] = $get_id->gambar;
			$d['favicon'] = $get_id->favicon;
			$d['facebook'] = $get_id->facebook;
			$d['twitter'] = $get_id->twitter;
			$d['google'] = $get_id->google;
			$d['youtube'] = $get_id->youtube;
			$d['bbm'] = $get_id->bbm;
			$d['wa'] = $get_id->wa;
			$d['line'] = $get_id->line;
			$d['instagram'] = $get_id->instagram;
			$d['fanspage'] = $get_id->fanspage;
			$d['map'] = $get_id->map;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/about/bg_input',$d);
			$this->load->view('bottom');			
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");	
			$in['author'] = $this->input->post('author');
			$in['judul_web'] = $this->input->post('judul_website');
			$in['meta_deskripsi'] = $this->input->post('meta_deskripsi');
			$in['meta_keyword'] = $this->input->post('meta_keyword');
			$in['nama'] = $this->input->post('nama');
                        $in['pesan_pembuka'] = $this->input->post('pesan_pembuka');
			$in['tentang'] = $this->input->post('tentang');
			$in['alamat'] = $this->input->post("alamat");	
			$in['email'] = $this->input->post("email");		
			$in['telpon'] = $this->input->post("telpon");		
			$in['facebook'] = $this->input->post("facebook");		
			$in['twitter'] = $this->input->post("twitter");		
			$in['google'] = $this->input->post("google");		
			$in['youtube'] = $this->input->post("youtube");	
			$in['bbm'] = $this->input->post("bbm");	
			$in['wa'] = $this->input->post("wa");	
			$in['line'] = $this->input->post("line");	
			$in['instagram'] = $this->input->post("instagram");
			$in['fanspage'] = $this->input->post("fanspage");	
			$in['map'] = $this->input->post("map");	
			

			if(empty($_FILES['gambar_banner']['name']) && empty($_FILES['gambar_favicon']['name'])) {
				$this->db->update("about",$in,$id);
				redirect("Xyzpb/about");
			} else {
					
					$config['upload_path'] = './asset/images/banner/';
					$config['allowed_types']= 'gif|jpg|png|jpeg';
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;	
					$config['max_size']     = '0';
					$config['max_width']  	= '30000';
					$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_banner")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];

					$this->db->update("about",$in,$id);
					$old_thumb	= "./asset/images/banner/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/about");
				} else if ($this->upload->do_upload("gambar_favicon")) {
					$data	 	= $this->upload->data();
					

					$in['favicon'] = $data['file_name'];

					$this->db->update("about",$in,$id);
					$old_thumb	= "./asset/images/banner/".$this->input->post("favicon")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/about");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			}	
			
		} else {
			redirect("Xyzpb");
		}
	}

}

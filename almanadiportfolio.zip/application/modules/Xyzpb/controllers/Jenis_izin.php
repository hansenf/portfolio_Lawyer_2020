<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class jenis_izin extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('jenis_izin','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['jenis_izin'] = $this->Admin_model->get_jenis_izin();
			$d['judul'] = 'jenis_izin';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/jenis_izin/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('jenis_izin',base_url().'Xyzpb/jenis_izin');
			$this->breadcrumb->append_crumb('Add jenis_izin','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New jenis_izin';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/jenis_izin';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['keterangan'] = '';
			$this->load->view('top');	
			$this->load->view('menu',$d);
			$this->load->view('module/jenis_izin/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('jenis_izin',base_url().'Xyzpb/jenis_izin');
			$this->breadcrumb->append_crumb('Edit jenis_izin','/');

			$where['id_jenis_izin'] = $id_param;
			$get_id = $this->db->get_where("jenis_izin",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit jenis_izin';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/jenis_izin';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id_jenis_izin;
			$d['keterangan'] = $get_id->keterangan;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/jenis_izin/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id_jenis_izin'] = $this->input->post("id_param");	
			$in['keterangan'] = $this->input->post('keterangan');
			
			if($tipe == "add") {				
				$this->db->insert("jenis_izin",$in);			
				redirect("Xyzpb/jenis_izin");
			} elseif($tipe = 'edit') {
				$this->db->update("jenis_izin",$in,$id);
				redirect("Xyzpb/jenis_izin");
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$this->db->delete("jenis_izin",array('id_jenis_izin' => $x));				
			}
			redirect("Xyzpb/jenis_izin");			
		} else {
			redirect("Xyzpb");
		}
	}
}

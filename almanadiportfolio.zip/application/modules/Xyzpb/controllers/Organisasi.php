<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class organisasi extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('organisasi','/');
			$d['organisasi'] = $this->Admin_model->get_organisasi();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'organisasi';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/organisasi/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('organisasi',base_url().'Xyzpb/organisasi');
			$this->breadcrumb->append_crumb('Add organisasi','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New organisasi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/organisasi';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['nama'] = '';	
			$d['keterangan'] = '';			
			$d['gambar'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/organisasi/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('organisasi',base_url().'Xyzpb/organisasi');
			$this->breadcrumb->append_crumb('Edit organisasi','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("organisasi",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit organisasi';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/organisasi';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['nama'] = $get_id->nama;
			$d['keterangan'] = $get_id->keterangan;
			$d['gambar'] = $get_id->gambar;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/organisasi/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/organisasi/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_organisasi")) {
					$data	 	= $this->upload->data();

					/* PATH */
					$source             = "./asset/images/organisasi/temp/".$data['file_name'] ;
					$destination_thumb	= "./asset/images/organisasi/" ;			 
						// Permission Configuration
					chmod($source, 0777) ;

					/* Resizing Processing */
						// Configuration Of Image Manipulation :: Static
					$this->load->library('image_lib') ;
					$img['image_library'] = 'GD2';
					$img['create_thumb']  = TRUE;
					$img['maintain_ratio']= TRUE;

						/// Limit Width Resize
					$limit_thumb    = 640 ;

						// Size Image Limit was using (LIMIT TOP)
					$limit_use  = $data['image_width'] > $data['image_height'] ? $data['image_width'] : $data['image_height'] ;

						// Percentase Resize
					if ($limit_use > $limit_thumb) {
						$percent_thumb  = $limit_thumb/$limit_use ;
					}

						//// Making THUMBNAIL ///////
					$img['width']  = $limit_use > $limit_thumb ?  $data['image_width'] * $percent_thumb : $data['image_width'] ;
					$img['height'] = $limit_use > $limit_thumb ?  $data['image_height'] * $percent_thumb : $data['image_height'] ;

						// Configuration Of Image Manipulation :: Dynamic
					$img['thumb_marker'] = '';
					$img['quality']      = '100%' ;
					$img['source_image'] = $source ;
					$img['new_image']    = $destination_thumb ;

						// Do Resizing
					$this->image_lib->initialize($img);
					$this->image_lib->resize();
					$this->image_lib->clear() ;

					$in['gambar'] = $data['file_name'];
					$in['nama'] =$this->input->post("nama");				
					$in['keterangan'] = $this->input->post("keterangan");				
					
					$this->db->insert("organisasi",$in);
					redirect("Xyzpb/organisasi");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['keterangan'] = $this->input->post("keterangan");
				$in['nama'] = $this->input->post("nama");
				
				if(empty($_FILES['gambar_organisasi']['name'])) {
					$this->db->update("organisasi",$in,$id);
					redirect("Xyzpb/organisasi");
				} else {
					$config['upload_path'] = './asset/images/organisasi/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_organisasi")) {
					$data	 	= $this->upload->data();

					/* PATH */
					$source             = "./asset/images/organisasi/temp/".$data['file_name'] ;
					$destination_thumb	= "./asset/images/organisasi/" ;			 
						// Permission Configuration
					chmod($source, 0777) ;

					/* Resizing Processing */
						// Configuration Of Image Manipulation :: Static
					$this->load->library('image_lib') ;
					$img['image_library'] = 'GD2';
					$img['create_thumb']  = TRUE;
					$img['maintain_ratio']= TRUE;

						/// Limit Width Resize
					$limit_thumb    = 640 ;

						// Size Image Limit was using (LIMIT TOP)
					$limit_use  = $data['image_width'] > $data['image_height'] ? $data['image_width'] : $data['image_height'] ;

						// Percentase Resize
					if ($limit_use > $limit_thumb) {
						$percent_thumb  = $limit_thumb/$limit_use ;
					}

						//// Making THUMBNAIL ///////
					$img['width']  = $limit_use > $limit_thumb ?  $data['image_width'] * $percent_thumb : $data['image_width'] ;
					$img['height'] = $limit_use > $limit_thumb ?  $data['image_height'] * $percent_thumb : $data['image_height'] ;

						// Configuration Of Image Manipulation :: Dynamic
					$img['thumb_marker'] = '';
					$img['quality']      = '100%' ;
					$img['source_image'] = $source ;
					$img['new_image']    = $destination_thumb ;

						// Do Resizing
					$this->image_lib->initialize($img);
					$this->image_lib->resize();
					$this->image_lib->clear() ;	

					$in['gambar'] = $data['file_name'];

					$this->db->update("organisasi",$in,$id);
					$old_thumb	= "./asset/images/organisasi/".$this->input->post("gambar")."" ;
					unlink($old_thumb);
					unlink($source);
					redirect("Xyzpb/organisasi");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("organisasi",array('id' => $x))->row();
				$path = "./asset/images/organisasi/".$get_id->gambar."";
				unlink($path);		
				$this->db->delete("organisasi",array('id' => $x));				
			}
			redirect("Xyzpb/organisasi");			
		} else {
			redirect("Xyzpb");
		}
	}
}

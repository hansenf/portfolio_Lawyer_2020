<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class user extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('user','/');
			$d['user'] = $this->Admin_model->get_user();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'user';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/user/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

        public function detail($id_param) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('user','/');
			$d['user_detail'] = $this->Admin_model->get_user_by_id($id_param);
                        $d['file_user'] = $this->Admin_model->get_file_user($id_param);
                        $d['perizinan'] = $this->Admin_model->get_perizinan($id_param);
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'User Detail';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/user/bg_detail',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('user',base_url().'Xyzpb/user');
			$this->breadcrumb->append_crumb('Add user','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New user';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/user';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
                        $d['nama_perusahaan'] = '';
			$d['username'] = '';
                        $d['password'] = '123456';
			$d['gambar'] = '';
			$d['aktif'] = '';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/user/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('user',base_url().'Xyzpb/user');
			$this->breadcrumb->append_crumb('Edit user','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("user",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit user';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/user';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
                        $d['nama_perusahaan'] = $get_id->nama_perusahaan;
			$d['username'] = $get_id->username;
			$d['password'] = base64_decode($get_id->password);
			$d['gambar'] = $get_id->gambar;
			$d['aktif'] = $get_id->aktif;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/user/bg_input',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Xyzpb");
		}
	}
	
	
	public function filep($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('Member',base_url().'Xyzpb/user');

			
			$get_id = $this->db->query("SELECT * FROM filep WHERE id='$id_param'")->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Kirim File';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/member';
			if(!empty($get_id->id)) {
				$d['id_param'] = $id_param;
				$d['keterangan'] = $get_id->keterangan;
				$d['thefile'] = $get_id->lokasi;
			} else {
				$d['id_param'] = $id_param;
				$d['keterangan'] = "";
				$d['thefile'] = "";
			}
			
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/user/bg_filep',$d);
			$this->load->view('bottom');			
		}else {
			redirect("Xyzpb");
		}
	}

	public function save_file() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {		
			
			$config['upload_path'] = './asset/file/';
				$config['allowed_types']= '*';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("file_upload")) {
					$data	 	= $this->upload->data();						
					$id['id'] = $this->input->post("id_param");	
					$in['lokasi'] = $data['file_name'];
					$in['id'] = $this->input->post("id_param");
					$in['keterangan'] = $this->input->post("keterangan");
					$this->db->delete("filep",$id);
					$this->db->insert("filep",$in);
					$old_thumb	= "./asset/file/".$this->input->post("thefile")."" ;
					@unlink($old_thumb);
					
					echo "<script>
				                 alert('File Terkirim');
				                 window.location.href='../user';
				              </script>";
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}			
		}else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {
                        $in['nama_perusahaan'] = $this->input->post("nama_perusahaan");
			$in['username'] = $this->input->post("username");
			$in['level'] = 'user';	                        
			$in['password'] = base64_encode('123456');
                        $in['tgl_tempo'] = '0';			
			if($this->input->post("aktif") != "") {
				$in['aktif'] = 'Y';
			} else {
				$in['aktif'] = 'N';
			}
 				if(empty($_FILES['gambar_user']['name'])) {
					$this->db->insert("user",$in);
					redirect("Xyzpb/user");
				} else {
				$config['upload_path'] = './asset/images/akun/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_user")) {
					$data	 	= $this->upload->data();					

					$in['gambar'] = $data['file_name'];					
					
					$this->db->insert("user",$in);
					redirect("Xyzpb/user");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			 }
			} elseif($tipe = 'edit') {
                                        $in['nama_perusahaan'] = $this->input->post("nama_perusahaan");
					$in['username'] = $this->input->post("username");	
					$in['password'] = base64_encode($this->input->post("password"));	
					$in['level'] = 'user';		
					if($this->input->post("aktif") != "") {
						$in['aktif'] = 'Y';
					} else {
						$in['aktif'] = 'N';
					}
				if(empty($_FILES['gambar_user']['name'])) {
					$this->db->update("user",$in,$id);
					redirect("Xyzpb/user");
				} else {
					$config['upload_path'] = './asset/images/akun/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_user")) {
					$data	 	= $this->upload->data();						

					$in['gambar'] = $data['file_name'];

					$this->db->update("user",$in,$id);
					$old_thumb	= "./asset/images/akun/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/user");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		}else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("user",array('id' => $x))->row();
				$path = "./asset/images/akun/".$get_id->gambar."";
				@unlink($path);		
				$this->db->delete("user",array('id' => $x));				
			}
			redirect("Xyzpb/user");			
		} else {
			redirect("Xyzpb");
		}
	}

        public function download($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$get_upload = $this->db->get_where("user",array("id"=>$id_param))->row();
			$nama = $get_upload->surat_izin;
			$upload = base_url()."asset/images/akun/".$nama;
			$data = file_get_contents($upload);
			force_download($nama,$data);
		}
	}

       public function download_lampiran($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$get_upload = $this->db->get_where("upload",array("id"=>$id_param))->row();
			$nama = $get_upload->file;
			$upload = base_url()."asset/upload/".$nama;
			$data = file_get_contents($upload);
			force_download($nama,$data);
		}
	}
	
	public function download_izin($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$get_upload = $this->db->get_where("perizinan",array("id"=>$id_param))->row();
			$nama = $get_upload->lokasi;
			$upload = base_url()."asset/file/".$nama;
			$data = file_get_contents($upload);
			force_download($nama,$data);
		}
	}
	
	public function tgl_tempo($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('user',base_url().'Xyzpb/user');
			$this->breadcrumb->append_crumb('Tgl Tempo','/');
			$get_user = $this->db->query("SELECT tgl_tempo,keterangan FROM user WHERE id='$id_param'")->row();
                        if($get_user->tgl_tempo == '0') {
                         $tgl_tempo = '0';
                        } elseif($get_user->tgl_tempo == '1') {
                          $tgl_tempo = '1';
                         }else {
                         $explode = explode("-",$get_user->tgl_tempo);
                         $tgl_tempo = $explode[1].'/'.$explode[2].'/'.$explode[0];
                        }
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Tanggal Jatuh Tempo Member';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/user';
			$d['tipe'] = 'add';
			$d['id_param'] = $id_param;
                        $d['tgl_tempo'] = $tgl_tempo;
			$d['keterangan'] = $get_user->keterangan;  			 
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/user/bg_tempo');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}
	
	public function save_tgl() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$explode = explode("/",$this->input->post("tgl_tempo"));
			$tgl_tempo = $explode[2].'-'.$explode[0].'-'.$explode[1];
			$id['id'] = $this->input->post("id_param");	
			$in['keterangan'] = $this->input->post('keterangan');
			$in['tgl_tempo'] = $tgl_tempo;
			$in['jenis_izin_pelaporan'] = $this->input->post('jenis_izin_pelaporan');                     
			
			$this->db->update("user",$in,$id);
			redirect("Xyzpb/user");
			
		} else {
			redirect("Xyzpb");
		}
	}
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class dashboard extends CI_Controller {

	 
	function index()
	{
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin")
		{
			$d['judul'] = 'Dashboard';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/dashboard/bg_home');
			$this->load->view('bottom');
		}
		else
		{
			redirect("Xyzpb");
		}
	}
}

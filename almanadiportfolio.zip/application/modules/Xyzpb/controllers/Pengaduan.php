<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pengaduan extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$in['baca'] = 'Y';
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('pengaduan','/');
			$this->db->update("pengaduan",$in);			
			$d['pengaduan'] = $this->Admin_model->get_pengaduan();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'pengaduan';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/pengaduan/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$this->db->delete("pengaduan",array('id' => $x));				
			}
			redirect("Xyzpb/pengaduan");			
		} else {
			redirect("Xyzpb");
		}
	}

       public function download($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$get_upload = $this->db->get_where("pengaduan",array("id"=>$id_param))->row();
			$nama = $get_upload->gambar;
			$upload = base_url()."asset/images/pengaduan/".$nama;
			$data = file_get_contents($upload);
			force_download($nama,$data);
		}
	}
}

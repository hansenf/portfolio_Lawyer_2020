<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class post extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('post','/');
			$d['post'] = $this->Admin_model->get_post();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'post';
			$d['active'] = 'active';
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/post/bg_home');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('post',base_url().'Xyzpb/post');
			$this->breadcrumb->append_crumb('Add post','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New post';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/post';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['judulx'] = '';
			$d['isi'] = '';			
			$d['gambar'] = '';	
			$d['combo_kategori_post'] = $this->Admin_model_detail->get_combo_kategori_post();
		
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/post/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('post',base_url().'Xyzpb/post');
			$this->breadcrumb->append_crumb('Edit post','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("post",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit post';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/post';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['id_kategori'] = $get_id->id_kategori;
			$d['judulx'] = $get_id->judul;
			$d['isi'] = $get_id->isi;
			$d['gambar'] = $get_id->gambar;
			$d['author'] = $get_id->author;
			$d['combo_kategori_post'] = $this->Admin_model_detail->get_combo_kategori_post($d['id_kategori']);

			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/post/bg_input',$d);
			$this->load->view('bottom');			
		}  else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/post/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '20000';
				$config['max_height']  	= '20000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_post")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];
					$in['judul'] = $this->input->post("judul");
					$in['visited'] = "0";
					$in['isi'] = $this->input->post("isi");
					$in['id_kategori'] = $this->input->post("kategori");
					$in['tgl_posting'] = date('Y-m-d');	
					$in['author'] = $this->session->userdata('nama');		
					
					$this->db->insert("post",$in);
					
					redirect("Xyzpb/post");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['judul'] = $this->input->post("judul");
				
				$in['isi'] = $this->input->post("isi");
				$in['id_kategori'] = $this->input->post("kategori");
				
				if(empty($_FILES['gambar_post']['name'])) {
					$this->db->update("post",$in,$id);
					redirect("Xyzpb/post");
				} else {
					$config['upload_path'] = './asset/images/post/';
					$config['allowed_types']= 'gif|jpg|png|jpeg';
					$config['encrypt_name']	= TRUE;
					$config['remove_spaces']	= TRUE;	
					$config['max_size']     = '0';
					$config['max_width']  	= '20000';
					$config['max_height']  	= '20000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_post")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];

					$this->db->update("post",$in,$id);
					$old_thumb	= "./asset/images/post/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/post");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("post",array('id' => $x))->row();
				$path = "./asset/images/post/".$get_id->gambar."";
				@unlink($path);		
				$this->db->delete("post",array('id' => $x));				
			}
			redirect("Xyzpb/post");			
		} else {
			redirect("Xyzpb");
		}
	}
}

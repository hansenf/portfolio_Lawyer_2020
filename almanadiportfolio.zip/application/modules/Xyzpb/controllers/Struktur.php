<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Struktur extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('struktur','/');
			$d['struktur'] = $this->Admin_model->get_struktur();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'struktur';
			$d['active'] = 'active';
			$d['gambar'] = $this->Admin_model->gambar_struktur();
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/struktur/bg_input',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('struktur',base_url().'Xyzpb/struktur');
			$this->breadcrumb->append_crumb('Add struktur','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New struktur';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/struktur';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['keterangan'] = '';			
			$d['gambar'] = '';
			$d['combo_album'] = $this->Admin_model_detail->get_combo_album();

			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/struktur/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('struktur',base_url().'Xyzpb/struktur');
			$this->breadcrumb->append_crumb('Edit struktur','/');

			$where['id'] = $id_param;
			$get_id = $this->db->get_where("struktur",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit struktur';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/struktur';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id;
			$d['id_album'] = $get_id->id_album;
			$d['keterangan'] = $get_id->keterangan;
			$d['gambar'] = $get_id->gambar;
			$d['combo_album'] = $this->Admin_model_detail->get_combo_album($d['id_album']);

			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/struktur/bg_input');
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id'] = $this->input->post("id_param");			
			if($tipe == "add") {

				$config['upload_path'] = './asset/images/struktur/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_struktur")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];
					$in['tgl_upload'] = date('Y-m-d');
					$in['keterangan'] = $this->input->post("keterangan");		
					$in['id_album'] = $this->input->post("album");						
					
					$this->db->insert("struktur",$in);
					redirect("Xyzpb/struktur");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			} elseif($tipe = 'edit') {
				$in['keterangan'] = $this->input->post("keterangan");
				$in['tgl_upload'] = date('Y-m-d');
				$in['id_album'] = $this->input->post("album");	
				
				if(empty($_FILES['gambar_struktur']['name'])) {
					$this->db->update("struktur",$in,$id);
					redirect("Xyzpb/struktur");
				} else {
					$config['upload_path'] = './asset/images/struktur/';
				$config['allowed_types']= 'gif|jpg|png|jpeg';
				$config['encrypt_name']	= TRUE;
				$config['remove_spaces']	= TRUE;	
				$config['max_size']     = '0';
				$config['max_width']  	= '30000';
				$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_struktur")) {
					$data	 	= $this->upload->data();
					

					$in['gambar'] = $data['file_name'];

					$this->db->update("struktur",$in,$id);
					$old_thumb	= "./asset/images/struktur/".$this->input->post("gambar")."" ;
					@unlink($old_thumb);
					
					redirect("Xyzpb/struktur");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
				}
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$get_id = $this->db->get_where("struktur",array('id' => $x))->row();
				$path = "./asset/images/struktur/".$get_id->gambar."";
				@unlink($path);		
				$this->db->delete("struktur",array('id' => $x));				
			}
			redirect("Xyzpb/struktur");			
		} else {
			redirect("Xyzpb");
		}
	}
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kategori_post extends MX_Controller {
	 
	public function index($uri=0) {
		if($this->session->userdata('logged_in')!="" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('kategori_post','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['kategori_post'] = $this->Admin_model->get_kategori_post();
			$d['judul'] = 'kategori_post';
			$d['active'] = 'active';
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_post/bg_home',$d);
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function add() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('kategori_post',base_url().'Xyzpb/kategori_post');
			$this->breadcrumb->append_crumb('Add kategori_post','/');
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'New kategori_post';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/kategori_post';
			$d['tipe'] = 'add';
			$d['id_param'] = '';
			$d['kategori_post'] = '';
			$this->load->view('top');	
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_post/bg_input');
			$this->load->view('bottom');
		}
		else {
			redirect("Xyzpb");
		}
	}

	public function edit($id_param) {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$this->breadcrumb->append_crumb('Dashboard',base_url().'Xyzpb');
			$this->breadcrumb->append_crumb('kategori_post',base_url().'Xyzpb/kategori_post');
			$this->breadcrumb->append_crumb('Edit kategori_post','/');

			$where['id_kategori'] = $id_param;
			$get_id = $this->db->get_where("kategori_post",$where)->row();
			$d['count_pesan'] = $this->Admin_model->get_count_pesan();
			$d['judul'] = 'Edit kategori_post';
			$d['active'] = 'active';
			$d['back'] = base_url().'Xyzpb/kategori_post';
			$d['tipe'] = 'edit';
			$d['id_param'] = $get_id->id_kategori;
			$d['kategori_post'] = $get_id->kategori_post;
			$this->load->view('top');
			$this->load->view('menu',$d);
			$this->load->view('module/kategori_post/bg_input',$d);
			$this->load->view('bottom');			
		} else {
			redirect("Xyzpb");
		}
	}


	public function save() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$tipe = $this->input->post("tipe");
			$id['id_kategori'] = $this->input->post("id_param");	
			$in['kategori_post'] = $this->input->post('kategori_post');
			
			if($tipe == "add") {				
				$this->db->insert("kategori_post",$in);			
				redirect("Xyzpb/kategori_post");
			} elseif($tipe = 'edit') {
				$this->db->update("kategori_post",$in,$id);
				redirect("Xyzpb/kategori_post");
			}
		} else {
			redirect("Xyzpb");
		}
	}

	public function delete() {
		if($this->session->userdata('logged_in') != "" && $this->session->userdata('level') == "admin") {
			$id = $this->input->post("id");
			foreach($id as $x) {		
				$this->db->delete("kategori_post",array('id_kategori' => $x));				
			}
			redirect("Xyzpb/kategori_post");			
		} else {
			redirect("Xyzpb");
		}
	}
}

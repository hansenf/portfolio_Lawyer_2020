<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class staff extends CI_Controller {

	function index($uri=0) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();
		$d['staff'] = $this->Web_model->get_staff(5,$uri);

		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);
$d['fanspage'] = $this->Web_model->get_fanspage();
		$this->load->view('theme/header',$d);
		$this->load->view('theme/staff/bg_home');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom');
	}
}

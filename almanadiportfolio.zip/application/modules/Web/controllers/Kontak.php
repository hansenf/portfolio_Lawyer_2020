<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kontak extends CI_Controller {


	function index($uri=0) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();	
		$d['kontak'] = $this->Web_model->get_kontak();
		$d['social'] = $this->Web_model->get_social();

		$this->load->view('theme/header',$d);
		$this->load->view('theme/kontak/bg_input');
		$this->load->view('theme/bottom');
			
	}

	function kirim() {
		$nama = $this->input->post("nama");
		$email = $this->input->post("email");
		$subjek = $this->input->post("subjek");
		$message = $this->input->post("message");
		if($nama != "" && $email != "" && $message != ""){
			$in['baca'] = "N";
			$in['nama'] = $nama;
			$in['email'] = $email;
			$in['subjek'] = $subjek;
			$in['message'] = $message;
			$in['tgl_kirim'] = date('Y-m-d');
			$this->db->insert("pesan_admin",$in);
			echo "<script>
				alert('Pesan Berhasil Dikirim');
				window.location.href='../kontak';
				</script>";
		}
		else {
			redirect(base_url());
		}	
	}
}
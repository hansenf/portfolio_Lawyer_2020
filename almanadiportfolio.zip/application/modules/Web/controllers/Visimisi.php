<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class visimisi extends CI_Controller {


	function index($uri=0) 
	{
	    $d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();	
		$d['kontak'] = $this->Web_model->get_kontak();
		$d['social'] = $this->Web_model->get_social();

		$d['visi'] = $this->Web_model->get_visi();
        $d['misi'] = $this->Web_model->get_misi();
        
		$this->load->view('theme/header',$d);
		$this->load->view('theme/visimisi/bg_input');
		$this->load->view('theme/bottom');
	}
}
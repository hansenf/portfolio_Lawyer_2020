<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class about extends CI_Controller {


	function index() {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();
		$d['about_detail'] = $this->Web_model->get_about_detail();
		$d['fanspage'] = $this->Web_model->get_fanspage();
		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);

		$this->load->view('theme/header',$d);
		$this->load->view('theme/about/bg_detail');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom');
	}

}
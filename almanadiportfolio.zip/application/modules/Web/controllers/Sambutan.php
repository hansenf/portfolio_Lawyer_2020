<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class sambutan extends CI_Controller {


	function index($uri=0) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();	
		$d['sambutan_poto'] = $this->Web_model->get_sambutan_poto();
		$d['sambutan_detail'] = $this->Web_model->get_sambutan_detail();

		$this->load->view('theme/header',$d);
		$this->load->view('theme/sambutan/bg_detail');
		$this->load->view('theme/sambutan/bg_sidebar');
		$this->load->view('theme/bottom');
			
	}

}
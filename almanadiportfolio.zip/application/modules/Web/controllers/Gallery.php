<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class gallery extends CI_Controller {

	public function index() {
		redirect(base_url());
	}

	public function album($uri=0) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();
		$d['album'] = $this->Web_model->get_album(5,$uri);
$d['fanspage'] = $this->Web_model->get_fanspage();
		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);

		$this->load->view('theme/header',$d);
		$this->load->view('theme/gallery/bg_home');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom');
	}

	public function video($uri=0) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();
		$d['video'] = $this->Web_model->get_video(5,$uri);
$d['fanspage'] = $this->Web_model->get_fanspage();
		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);

		$this->load->view('theme/header',$d);
		$this->load->view('theme/gallery/bg_home-v');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom');
	}

	public function photo($id_param) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();
		$d['album_title'] = $this->Web_model->get_album_title($id_param);
		$d['photo_main'] = $this->Web_model->get_photo_main($id_param);
		$d['photo_bullet'] = $this->Web_model->get_photo_bullet($id_param);
		$d['photo_modal'] = $this->Web_model->get_photo_modal($id_param);
$d['fanspage'] = $this->Web_model->get_fanspage();
		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);

		$this->load->view('theme/header',$d);
		$this->load->view('theme/gallery/bg_detail');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom');
	}
}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class page extends CI_Controller {


	function index($uri=0) {
		redirect(base_url());			
	}

	function detail($id_param) {
		$where['id'] = $id_param;
		$get_data = $this->db->get_where("page",$where);
		if($get_data->num_rows() > 0) {
			$d['logo_website'] = $this->Web_model->get_logo();
			$d['top_informasi'] = $this->Web_model->get_top_informasi();
			$d['navbar'] = $this->Web_model->get_navbar();
			$d['page_detail'] = $this->Web_model->get_page_detail($id_param);
$d['fanspage'] = $this->Web_model->get_fanspage();
			$d['sambutan'] = $this->Web_model->get_sambutan();
			$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
			$d['banner'] = $this->Web_model->get_banner(5);
			$d['link_terkait'] = $this->Web_model->get_link(5);

			$this->load->view('theme/header',$d);
			$this->load->view('theme/page/bg_detail');
			$this->load->view('theme/sidebar');
			$this->load->view('theme/bottom');
		} else {
			redirect(base_url());
		}
	}

        public function download($id_param) {
		if($this->session->userdata('logged_in') != "") {
			$get_file = $this->db->get_where("page",array("id"=>$id_param))->row();
			$nama = $get_file->file;
			$file = base_url()."asset/file/".$nama;
			$data = file_get_contents($file);
			force_download($nama,$data);
		}
	}
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class konsultasi extends CI_Controller {


	function index($uri=0) {
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();	
                $d['social'] = $this->Web_model->get_social();

		$this->load->view('theme/header',$d);
		$this->load->view('theme/konsultasi/bg_input');
		$this->load->view('theme/bottom');
			
	}

	function kirim() {
		$nik_ktp= $this->input->post("nik_ktp");
		$nama = $this->input->post("nama");
		$alamat= $this->input->post("alamat");
		$no_hp= $this->input->post("no_hp");
		$pesan= $this->input->post("pesan");
		if($nama != "" && $nik_ktp!= "" && $alamat!= "" && $pesan!= "" && $no_hp!= ""){
		
		$config['upload_path'] = './asset/images/konsultasi/';
		$config['allowed_types']= 'gif|jpg|png|jpeg';
		$config['encrypt_name']	= TRUE;
		$config['remove_spaces']	= TRUE;	
		$config['max_size']     = '0';
		$config['max_width']  	= '30000';
		$config['max_height']  	= '30000';

				$this->load->library('upload', $config);

				if ($this->upload->do_upload("gambar_konsultasi")) {
					$data	 	= $this->upload->data();
					

					$in['baca'] = "N";
					$in['nik_ktp'] = $nik_ktp;
					$in['gambar'] = $data['file_name'];
					$in['nama'] = $nama;
					$in['alamat'] = $alamat;
					$in['no_hp'] = $no_hp;
					$in['pesan'] = $pesan;
					$in['tgl_konsultasi '] = date('Y-m-d');
					$this->db->insert("konsultasi",$in);
					$this->session->set_flashdata("msg_konsultasi","Pesan konsultasi Berhasil Dikirim");
		                        redirect("Web/konsultasi/");
				} else {
					echo $this->upload->display_errors('<p>','</p>');
				}
			
			
		}
		else {
			echo "<script>
				alert('Pesan konsultasi Gagal Dikirim, Periksa Kembali');
				window.location.href='../konsultasi';
				</script>";
		}	
	}
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Web extends CI_Controller {

	function index() {
	
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();
		$d['slideshow'] = $this->Web_model->get_slideshow(10);
		$d['berita_col1'] = $this->Web_model->get_berita_col1(0,2);
		$d['berita_col2'] = $this->Web_model->get_berita_col2(2,2);
		$d['informasi'] = $this->Web_model->get_informasi(8);

		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['fanspage'] = $this->Web_model->get_fanspage();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);
		
		$d['foot_kontak'] = $this->Web_model->get_foot_kontak();
		$d['foot_album'] = $this->Web_model->get_foot_album(4);
		$d['foot_video'] = $this->Web_model->get_foot_video(1);
		$d['foot_map'] = $this->Web_model->get_foot_map();

		$this->load->view('theme/header',$d);
		$this->load->view('theme/main-slideshow');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom-col');
	}
}

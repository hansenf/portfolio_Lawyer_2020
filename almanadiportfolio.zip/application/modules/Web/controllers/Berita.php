<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class berita extends CI_Controller {


	public function index($uri=0) {		
		$d['logo_website'] = $this->Web_model->get_logo();
		$d['top_informasi'] = $this->Web_model->get_top_informasi();
		$d['navbar'] = $this->Web_model->get_navbar();		
		$d['berita_all'] = $this->Web_model->get_berita_all(8,$uri);
$d['fanspage'] = $this->Web_model->get_fanspage();
		$d['sambutan'] = $this->Web_model->get_sambutan();
		$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
		$d['banner'] = $this->Web_model->get_banner(5);
		$d['link_terkait'] = $this->Web_model->get_link(5);

		$this->load->view('theme/header',$d);
		$this->load->view('theme/berita/bg_home');
		$this->load->view('theme/sidebar');
		$this->load->view('theme/bottom');
			
	}

	public function detail($id_param) {
		$where['id'] = $id_param;
		$get_data = $this->db->get_where("post",$where);
		if($get_data->num_rows() > 0) {
			$d['logo_website'] = $this->Web_model->get_logo();
			$d['top_informasi'] = $this->Web_model->get_top_informasi();
			$d['navbar'] = $this->Web_model->get_navbar();		
			$d['berita_detail'] = $this->Web_model->get_berita_detail($id_param);
			$d['berita_recent_detail'] = $this->Web_model->get_berita_detail_recent(4);
$d['fanspage'] = $this->Web_model->get_fanspage();
			$d['sambutan'] = $this->Web_model->get_sambutan();
			$d['berita_recent'] = $this->Web_model->get_berita_recent(6);
			$d['banner'] = $this->Web_model->get_banner(5);
			$d['link_terkait'] = $this->Web_model->get_link(5);


			$this->load->view('theme/header',$d);
			$this->load->view('theme/berita/bg_detail');
			$this->load->view('theme/sidebar');
			$this->load->view('theme/bottom');
		} else {
			redirect(base_url());
		}
	}

	public function kategori($id_kategori) {
		$where['id_kategori'] = $id_kategori;
		$get_data = $this->db->get_where("post",$where);
		if($get_data->num_rows() > 0) {
			$d['logo_website'] = $this->Web_model->get_logo();
			$d['top_informasi'] = $this->Web_model->get_top_informasi();
			$d['navbar'] = $this->Web_model->get_navbar();		
			$d['berita_detail'] = $this->Web_model->get_berita_detail($id_param);
		$d['fanspage'] = $this->Web_model->get_fanspage();	
			$d['sambutan'] = $this->Web_model->get_sambutan();
			$d['berita_recent_detail'] = $this->Web_model->get_berita_detail_recent(6);
			$d['banner'] = $this->Web_model->get_banner(5);
			$d['link_terkait'] = $this->Web_model->get_link(5);	
			$this->load->view('theme/header',$d);
			$this->load->view('theme/menu');
			$this->load->view('theme/berita/bg_home');
			$this->load->view('theme/sidebar');
			$this->load->view('theme/footer');
		} else {
			redirect(base_url());
		}
	}

}